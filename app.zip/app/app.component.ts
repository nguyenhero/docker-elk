import {Component, OnInit} from '@angular/core';
import {LangChangeEvent, TranslateService} from '@ngx-translate/core';
import {DeviceDetectorService} from 'ngx-device-detector';
import {HopscotchService} from '@visc/ngx-hopscotch';
import {Router} from '@angular/router';
import hopscotch from 'hopscotch';
import {changeLangLHC} from '@common/utils';
import {CookieService} from "ngx-cookie";
import {ClientPermService} from "@common/services";

// import {_} from './utils';

@Component({
  selector: 'app-root',
  template: `<ng-progress></ng-progress>
  <div class="{{ deviceService.browser }}">
    <router-outlet></router-outlet>
   </div>
   `,
})
export class AppComponent implements OnInit {
  private lang: any;


  public static getTourSteps(router, hs, translate) {
    return [
      {
        stepIndex: 0,
        stepDef: {
          target: 'pricelist',
          placement: 'bottom',
          content: translate.instant("Vào màn hình Bảng giá"),
          title: translate.instant("Bước 1"),
        }
      },
      {
        stepIndex: 1,
        stepDef: {
          target: 'dangkyngay0',
          placement: 'left',
          content: translate.instant("Chọn dịch vụ rồi nhấn nút Đăng ký ngay"),
          title: translate.instant("Bước 2"),
          multipage: true,
          yOffset: -45,
          arrowOffset: 50,
          onPrev: () => {
          },
          onNext: () => {
            let selectedList = "5af67c830106082b7365e5c2,5af67c890106082b7365f590";
            const q = {services: selectedList, substep: 2};
            router.navigate(['/c/tourpayflow'], {queryParams: q}).then(() => {
              setTimeout(() => {
                hs.step(1);
                hs.step(2);
              }, 400);
            });
          }
        }
      },
      {
        stepIndex: 2,
        stepDef: {
          target: 'goidichvu',
          placement: 'left',
          content: translate.instant("Chọn gói dịch vụ"),
          title: translate.instant("Bước 3"),
          multipage: true,
          onPrev: () => {
            router.navigate(['/c/tourpayflow']).then(() => {
              setTimeout(() => {
                hs.step(2);
                hs.step(1);
              }, 300);
            });
          },
          onNext: () => {
            hs.step(3);
          }
        }
      },
      {
        stepIndex: 3,
        stepDef: {
          target: 'soluongdomain',
          placement: 'left',
          content: translate.instant("Chọn số lượng tên miền"),
          title: translate.instant("Bước 4"),
          onPrev: () => {
            setTimeout(() => {
              hs.step(3);
              hs.step(2);
            }, 200);
          },
        }
      },
      {
        stepIndex: 4,
        stepDef: {
          target: 'thoigiansudung',
          placement: 'left',
          content: translate.instant("Chọn thời gian sử dụng"),
          title: translate.instant("Bước 5"),
          // multipage: true
        }
      },
      {
        stepIndex: 5,
        stepDef: {
          target: 'nhapmagiamgia',
          placement: 'left',
          content: translate.instant("Nhập mã giảm giá nếu có "),
          title: translate.instant("Bước 6"),
          // multipage: true
        }
      },
      {
        stepIndex: 6,
        stepDef: {
          target: 'muathemdichvu',
          placement: 'left',
          content: translate.instant("Chọn mua thêm dịch vụ nếu bạn muốn mua dịch vụ khác nữa "),
          title: translate.instant("Bước 7"),
          yOffset: -20,
          arrowOffset: 0,
          // multipage: true
        }
      },
      {
        stepIndex: 7,
        stepDef: {
          target: 'taodonhang',
          placement: 'left',
          content: translate.instant("Nhấn nút Tạo đơn hàng để tiến hành thanh toán "),
          title: translate.instant("Bước 8"),
          yOffset: -10,
          arrowOffset: 10,
          multipage: true,
          onNext: () => {
            const q = {step: 2, order_id: "5b22068901060841ccc33e32"};
            router.navigate(['/c/tourpayflow'], {queryParams: q}).then(() => {
              setTimeout(() => {
                hs.step(7);
                hs.step(8);
              }, 900);
            });
          }
        }
      },
      {
        stepIndex: 8,
        stepDef: {
          target: 'thongtindonhang',
          placement: 'top',
          content: translate.instant("Nhập thông tin đơn hàng "),
          title: translate.instant("Bước 9"),
          multipage: true,
          onPrev: () => {
            let selectedList = "5af67c830106082b7365e5c2,5af67c890106082b7365f590";
            const q = {services: selectedList, substep: 2};
            router.navigate(['/c/tourpayflow'], {queryParams: q}).then(() => {
              setTimeout(() => {
                hs.step(8);
                hs.step(7);
              }, 500);
            });
          },
          onNext: () => {
            setTimeout(() => {
              hs.step(8);
              hs.step(9);
            }, 300);
          }
        }
      },
      {
        stepIndex: 9,
        stepDef: {
          target: 'hinhthucthanhtoan',
          placement: 'top',
          content: translate.instant("Chọn hình thức thanh toán "),
          title: translate.instant("Bước 10 "),
          multipage: true,
        }
      },
      {
        stepIndex: 10,
        stepDef: {
          target: 'xuathoadon',
          placement: 'top',
          content: translate.instant("Nhập thông tin xuất hóa đơn nếu bạn cần xuất hóa đơn "),
          title: translate.instant("Bước 11 "),
          multipage: true
        }
      },
      {
        stepIndex: 11,
        stepDef: {
          target: 'thanhtoan',
          placement: 'top',
          content: translate.instant("Nhấn nút Thanh toán, bạn sẽ được chuyển hướng đến cổng thanh toán tương ứng để thực hiện thanh toán "),
          title: translate.instant("Bước 12"),
          multipage: true,
        }
      },
      {
        stepIndex: 12,
        stepDef: {
          target: 'paypal1',
          placement: 'left',
          content: translate.instant("Đăng nhập vào tài khoản Paypal của bạn "),
          title: translate.instant("Bước 13 "),
          multipage: true
        }
      },
      {
        stepIndex: 13,
        stepDef: {
          target: 'paypal2',
          placement: 'left',
          content: translate.instant("Thực hiện lệnh mua "),
          title: translate.instant("Bước 14"),
          multipage: true
        }
      },
      {
        stepIndex: 14,
        stepDef: {
          target: 'nganluong',
          placement: 'top',
          content: translate.instant("Chọn hình thức tạm giữ"),
          title: translate.instant("Bước 13"),
          // multipage: true
        }
      },
      {
        stepIndex: 15,
        stepDef: {
          target: 'nganluong-the',
          placement: 'top',
          content: translate.instant("Nhập thông tin thẻ thanh toán "),
          title: translate.instant("Bước 14"),
          // multipage: true
        }
      },
      {
        stepIndex: 16,
        stepDef: {
          target: 'nganluong-thanhtoan',
          placement: 'top',
          content: translate.instant("Nhập mã bảo mật rồi nhấn nút Thanh toán"),
          title: translate.instant("Bước 15"),
          multipage: true,
        }
      },
      {
        stepIndex: 17,
        stepDef: {
          target: 'quanlyhoadon',
          placement: 'bottom',
          content: translate.instant("Bạn có thể xem trạng thái đơn hàng tại màn hình này!"),
          title: translate.instant("Hoàn thành mua dịch vụ"),
          multipage: true,
          xOffset: 280,
          // showPrevButton: false,
          onNext: () => {
            hs.end();
            // console.log('done tour to dashboard');
            router.navigate(['/c/dashboard']);
          }
        }
      },
      // ANOTHER TOUR: without this we dont have onNext called
      {
        stepIndex: 18,
        stepDef: {
          target: 'pricelist',
          placement: 'bottom',
          content: "Tour 2 use different stepIndex",
          title: "Tour 2",
          showPrevButton: false,
        }
      },
      {
        stepIndex: 19,
        stepDef: {
          target: 'giaiphap',
          placement: 'bottom',
          content: "Tour 2 use different stepIndex",
          title: "Tour 2",
        }
      },
    ];
  }


  constructor(protected translate: TranslateService,
              public deviceService: DeviceDetectorService,
              private router: Router,
              private hs: HopscotchService,
              private cookieService: CookieService,
              private clientPerm: ClientPermService,
  ) {
    // save translate instance for use in swal2
    window['SWAL2_TRANSLATOR'] = translate;

    translate.addLangs(['en', 'vi']);
    translate.setDefaultLang('vi');

    this.lang = localStorage.getItem('language');

    // prefer lang from cookie, use this for sync language between CAS <-> CP
    let cookieLang = this.cookieService.get('cp_lang');
    if (cookieLang) {
      this.lang =  cookieLang;
    }

    if (this.lang) {
      translate.use(this.lang);
    } else {
      this.lang = 'vi';
      localStorage.setItem('language', 'vi');
      translate.use('vi');
    }
    changeLangLHC(this.lang);
    this.clientPerm.setCasLang(this.lang);

    // TODO uncomment this
    window['hasPackage'] = true;

    //add browser to app-root
    this.translate.onLangChange
      .subscribe((event: LangChangeEvent) => {
        this.lang = event.lang;
        // if in a tour page
        if (this.router.url.startsWith('/c/tour')) {
          this.configTour();
          this.router.navigate(['/c/tourpayflow']).then(() => {
            this.hs.end();
            this.hs.step(0);
          });
        }
      });
    this.lang = translate.currentLang;
  }

  public ngOnInit(): void {
    // for testing
    window['hopscotch'] = hopscotch;
    window['hs'] = this.hs;

    this.configTour();
  }

  protected configTour() {
    // console.log('configure tour again');
    this.hs.setLang(this.lang);
    this.hs.end();
    // this.hs.setLang(this.lang);
    //this.hs.step(0);
    //this.hs.setLang(this.lang);

    this.hs.configure(AppComponent.getTourSteps(this.router, this.hs, this.translate));
  }
}
