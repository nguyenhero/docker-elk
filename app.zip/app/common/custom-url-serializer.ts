import {UrlSerializer, UrlTree, DefaultUrlSerializer} from '@angular/router';

export class CustomUrlSerializer implements UrlSerializer {
  private dus = new DefaultUrlSerializer();

  parse(url: any): UrlTree {
    let [root, query] = url.split('?');
    if (query) {
      query = query.replace(/\+/g, ' '); // replace + by space
      url = root + '?' + query;
    }
    return this.dus.parse(url);
  }

  serialize(tree: UrlTree): any {
    return this.dus.serialize(tree);
  }
}