import { latinise } from '@common/utils';

/**
 * Fast UUID generator, RFC4122 version 4 compliant.
 * @author Jeff Ward (jcward.com).
 * @license MIT license
 * @link http://stackoverflow.com/questions/105034/how-to-create-a-guid-uuid-in-javascript/21963136#21963136
 **/
var UUID: any = (function () {
  var self: any = {};
  var lut = []; for (var i = 0; i < 256; i++) { lut[ i ] = (i < 16 ? '0' : '') + (i).toString(16); }
  self.generate = function () {
    var d0 = Math.random() * 0xffffffff | 0;
    var d1 = Math.random() * 0xffffffff | 0;
    var d2 = Math.random() * 0xffffffff | 0;
    var d3 = Math.random() * 0xffffffff | 0;
    return lut[ d0 & 0xff ] + lut[ d0 >> 8 & 0xff ] + lut[ d0 >> 16 & 0xff ] + lut[ d0 >> 24 & 0xff ] + '-' +
      lut[ d1 & 0xff ] + lut[ d1 >> 8 & 0xff ] + '-' + lut[ d1 >> 16 & 0x0f | 0x40 ] + lut[ d1 >> 24 & 0xff ] + '-' +
      lut[ d2 & 0x3f | 0x80 ] + lut[ d2 >> 8 & 0xff ] + '-' + lut[ d2 >> 16 & 0xff ] + lut[ d2 >> 24 & 0xff ] +
      lut[ d3 & 0xff ] + lut[ d3 >> 8 & 0xff ] + lut[ d3 >> 16 & 0xff ] + lut[ d3 >> 24 & 0xff ];
  }
  return self;
})();

export class Field {
  constructor(public prop = '',
    public label = '',
    public control: any = {},
    public column: any = {},
    public trackId?) {
    let id = prop + '_' + label;
    id = latinise(id).toLowerCase();

    control.type = control.type || 'input';
    control.placeholder = control.placeholder || label;
    control.class = control.class || '';

    control.width = control.width || '100%';
    control.id = 'search_' + id;

    column.type = column.type || 'label';
    column.name = column.name || label;
    column.position = column.position || 'content';
    column.id = 'col_' + id;
    column.title = true;
    column.label_translate = !!column.label_translate;

    if (!('sortable' in column)) {
      column.sortable = true;
    }

    this.trackId = this.trackId || UUID.generate();
  }

  /**
   * Filter view detail only
   */
  filterActionViewDetail(ref, label) {
    let field: any = new Field('', label, new HiddenControl(), {
      ref: ref,
      type: 'actions',
      sortable: false,
      actions: (this.column.actions || []).filter(o => o.icon == 'info_outline'),
      minWidth: 100,
      maxwidth: 100
    });
    return field;
  }
}

export function compareStrLower(x, y) {
  x = x.trim().toLowerCase();
  y = y.trim().toLowerCase();
  return (x > y) ? 1 : (x < y) ? -1 : 0;
}

export function compareViStrLower(x, y){
  x = x.trim().toLowerCase();
  y = y.trim().toLowerCase();
}

export class CardField extends Field {
  constructor(public prop = '',
    public label = '',
    public control: any = {},
    public column: any = {},
    public condition: any = {}) {
    super(prop, label, control, column);
  }
}

export class HiddenControl {
  constructor(public hidden = true) {
  }
}

export class LabelControl {
  constructor() {
  }
}


export class Select {
  value: any;
  label: any;

  constructor(value, label) {
    this.value = value;
    this.label = label;
  }
}
