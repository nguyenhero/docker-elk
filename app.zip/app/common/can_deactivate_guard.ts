import { Injectable } from '@angular/core';
import { CanDeactivate } from "@angular/router";
import { Observable } from 'rxjs/Observable';
import {TranslateService} from "@ngx-translate/core";

export interface ComponentCanDeactivate {
    canDeactivate: () => boolean | Observable<boolean>;
}

@Injectable()
export class CanDeactivateGuard implements CanDeactivate<ComponentCanDeactivate> {

    constructor(
        public translate: TranslateService
    ) {}

    canDeactivate(component: ComponentCanDeactivate): boolean | Observable<boolean> {
        return component.canDeactivate() ? true : confirm(this.translate.instant('DEACTIVATE_CONFIRM_MSG'));
    }
}
