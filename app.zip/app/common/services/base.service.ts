import {HttpClient} from '@angular/common/http';
import {API_BASE_URL} from '@customer/config';
import {Observable} from 'rxjs/Observable';
import {Injectable} from '@angular/core';

@Injectable()
export class BaseService {
  root_path = '';

  constructor(protected http: HttpClient) {
  }

  make_resp(body) {
    return Observable.of(body);
  }

  make_queryparams(body) {
    body = body || {};
    return Object.keys(body).map(k => k + '=' + body[k]).join('&');
  }

  make_url(path, body?) {
    const queryParams = this.make_queryparams(body);
    return `${API_BASE_URL}/${this.root_path}/${path}?${queryParams}`;
  }

  public http_get(path, body?) {
    return this.http.get(this.make_url(path, body));
  }

  public http_del(path) {
    return this.http.delete(this.make_url(path));
  }

  public http_put(path, body) {
    return this.http.put(this.make_url(path), body);
  }

  public http_post(path, body = {}) {
    return this.http.post(this.make_url(path), body);
  }

  public list(body?) {
    return this.http_get('', body);
  }

  public get(id) {
    return this.http_get(`${id}`);
  }

  public del(id) {
    return this.http_del(`${id}`);
  }

  public post(body) {
    return this.http_post('', body);
  }

  public put(id, body) {
    return this.http_put(`${id}`, body);
  }
}
