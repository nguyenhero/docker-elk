import { Injectable } from '@angular/core';

import { Subject } from 'rxjs';


@Injectable( )
export class GlobalService {
  private notify = new Subject<any>();
  private storage = {};
  /**
   * Observable string streams
   */
  notifyObservable$ = this.notify.asObservable();

  constructor() { }
  //#region Storage Common
  /**
   * clear
   */
  public clear() {
    this.storage = {};
  }
  /**
   * setItem
   */
  public setItem(key: string, value: string) {
    if (localStorage) {
      localStorage.setItem(key, value);
    } else {
      this.storage[key] = value;
    }
  }
  /**
   * getItem
   */
  public getItem(key: string) {
    if (localStorage) {
      return localStorage.getItem(key);
    } else {
      return this.storage[key];
    }
  }
  /**
   * removeItem
   */
  public removeItem(key: string) {
    if (localStorage) {
      localStorage.removeItem(key);
    } else {
      this.storage[key] = null;
    }
  }

  //#endregion

  public notifyOther(data: any) {
    if (data) {
      this.notify.next(data);
    }
    this.setItem("CLOUDRITY_CONST", JSON.stringify(data));
  }
}
