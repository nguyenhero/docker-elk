import {Injectable} from '@angular/core';
import {ClientPermService} from "@customer/common";
import {Router} from "@angular/router";
import {API_BASE_URL} from "@customer/config";
import {HttpClient} from "@angular/common/http";

@Injectable()
export class QuickConfigHelperService {
  isBoughtWP;
  isBoughtDDoS;
  isConfiguredWP;
  isConfiguredDDoS;

  get isBought() {
    return this.isBoughtWP || this.isBoughtDDoS;
  }

  get isConfigured() {
    // don't show start now for ddosl4
    let isConfigured = this.isConfiguredWP || this.isConfiguredDDoS;
    if (!isConfigured) {
      if (!this.isBoughtWP && this.isBoughtDDoS) {
        isConfigured = true;
      }
    }
    return isConfigured;
  }

  constructor(public router: Router,
              public http: HttpClient,
              public clientPerm: ClientPermService) {
  }

  checkForStatus() {
    let url = API_BASE_URL + '/quick_config/resource/status/';
    return this.http.get(url).map((resp: any) => {
      let oldBought = this.isBought;
      this.updateStatus(resp.data);

      // force reload when any package is paid
      if (oldBought === false && this.isBought) {
        setTimeout(() => window.location.reload(true), 100);
      } else if (oldBought && !this.isBought) {
        history.pushState({}, 'Cloudrity', '#/c/dashboard');
        setTimeout(() => window.location.reload(true), 100);
      }
      return resp;
    });
  }

  updateStatus(data) {
    const wp: any = data['WebProtection'];
    this.isBoughtWP = wp.is_bought;
    this.isConfiguredWP = wp.is_configured;

    const ddos: any = data['AntiDDoS Layer 4'];
    this.isBoughtDDoS = ddos.is_bought;
    this.isConfiguredDDoS = ddos.is_configured;
  }

  redirect() {
    // force reload
    let q = {url: '/c/manage-services/waf'};
    this.router.navigate(['/redirect'], {queryParams: q})
  }
}