import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import {BaseService} from './base.service';

@Injectable()
export class AuthService__ extends BaseService {
  root_path = 'auth';

  public login(body) {
    return this.http_post('login', body);
  }

  public validateOTP(body) {
    return this.http_post('verify', body);
  }

  public createOTP() {
    return this.http_post('first_otp');
  }

  public isLoggedIn() {
    return this.http_get('logged_in').catch(err => {
      return Observable.of({code: 403});
    });
  }

  public signOut() {
    return this.http_post('logout');
  }

  /* 2FA */
  public check_password(password) {
    const body = {password};
    return this.http_post('check_password', body);
  }

  /* 2FA */
  public check_otp(otp) {
    const body = {otp};
    return this.http_post('check_otp', body);
  }
}

@Injectable()
export class AuthAPI extends BaseService {
  root_path = 'auth';

  public login(body) {
    const resp = {
      data: {
        num_otps: 0
      }
    };
    return this.make_resp(resp);
  }

  public validateOTP(body) {
    const resp = {
      data: {}
    };
    return this.make_resp(resp);
  }

  public createOTP() {
    const resp = {
      data: {
        code: '123'
      }
    };
    return this.make_resp(resp);
  }

  public isLoggedIn() {
    const resp = {
      data: {
        code: 200
      }
    };
    return this.make_resp(resp);
  }

  public signOut() {
    return this.http_post('logout');
  }

  /* 2FA */
  public check_password(password) {
    const body = {password};
    return this.http_post('check_password', body);
  }

  /* 2FA */
  public check_otp(otp) {
    const body = {otp};
    return this.http_post('check_otp', body);
  }
}