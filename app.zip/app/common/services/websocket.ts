import {Injectable} from "@angular/core";

@Injectable()
export class WebsocketService {
  constructor() {

  }

  connect() {

  }

  register(event, cb) {

  }

  close() {

  }
}