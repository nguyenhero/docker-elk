import {Injectable} from '@angular/core';
import {BaseService} from './base.service';

const PERMS = [];

@Injectable()
export class OTPService extends BaseService {
  root_path = 'token';

  public deleteOTP(username) {
    return this.http_post('delete', {username: username});
  }

  public enrollOTP(username) {
    return this.http_post('update', {username: username});
  }

  public verify(username, basevalue, code) {
    return this.http_post('verify', {username, basevalue, code});
  }
}
