import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PermService } from "../swagger-services";
import {TranslateService} from "@ngx-translate/core";
import {CookieService} from "ngx-cookie";
// import {BaseService} from './base.service';
// import {isIgnoreLogin} from '@common/utils';


// TODO: remove this
export const VIEW_ACCOUNT = 'view_account';
export const EDIT_ACCOUNT = 'edit_account';
export const LOCK_ACCOUNT = 'lock_account';
export const EDIT_TOKEN = 'edit_token';
export const EDIT_ALL_TOKEN = 'edit_all_token';
export const VIEW_USER = 'view_user';
export const EDIT_USER = 'edit_user';
export const EDIT_ALL_USER = 'edit_all_user';
export const VIEW_WHITELIST = 'view_whitelist';
export const EDIT_WHITELIST = 'edit_whitelist';

const ACCESS_PAGES = {
  '/': true,
  '/orders': 'access_order',
  '/customers': 'access_customer',
  '/customer-service': 'access_customer_service',
  '/promotions': 'access_promotion',
  '/helpdesk': 'access_ticket',
  '/prices': 'access_package',
  '/statistic': 'access_statistic',
  '/admins': 'access_admin',
  '/cluster': 'access_cluster',
  '/services': 'access_service',
  '/profile': true,
  '/403': true,
  '/error': true,
  '/service-management': 'access_service_management',
  // '/c/dashboard': 'access_customer_dashboard',
  '/c/manage-services/waf': '__customer_config_service_wp',
  '/c/manage-services/antiddos': '__customer_config_service_ddosl4',
  '/c/manage-services/web-analytics/domain-manager': '__customer_config_service_wp',
  '/c/manage-services/web-analytics/all-page': '__customer_config_service_wp',
  '/c/manage-services/web-analytics/exit-page': '__customer_config_service_wp',
  '/c/manage-services/web-analytics/entry-page': '__customer_config_service_wp',
  '/c/manage-services/web-analytics/user-info': '__customer_config_service_wp',
  '/c/manage-services/web-analytics/realtime': '__customer_config_service_wp',
  // '/c/manage-services/web-analytics': '__customer_config_service_wp',


  '/c/manage-services/web-analytics': '__customer_config_service_wp',
  '/c/manage-services/dns': '__customer_config_service_dns',
  '/c/configure-services': 'access_customer_dashboard',
  '/c/helpdesk': 'access_ticket',
  '/c/customer/dashboard/events': 'access_customer_dashboard',
  '/c/customer/dashboard/warnings': 'access_customer_dashboard',
  '/c/dashboard/alerts': 'access_customer_dashboard',
  '/c/profile': 'access_customer_personal',
  '/c/orders': 'access_order',
  '/c/promotion': 'access_promotion',
  '/c/tourpayflow': 'access_customer_personal',

  //#region new navigation
  '/c/dashboard': true,
  '/c/overview': true,
  '/c/attack-map': true,
  '/c/ssl': true,
  '/c/caching/monitor': true,
  '/c/caching/config': true,
  '/c/custompage': true,
  '/c/network': true,
  '/c/traffic': true,
  '/c/manage-services/waf/attack-mon': true,
  '/c/manage-services/waf/attack-log': true,
  '/c/manage-services/waf/attack-ruleset': true,
  '/c/manage-services/waf/custom-waf-rule': true,
  //#endregion
};

const ACCESSABLE_PAGES = [
  '/orders',
  '/customers',
  '/customer-service',
  '/promotions',
  '/helpdesk',
  '/prices',
  '/statistic',
  '/admins',
  '/cluster',
  '/services',
  '/profile',
  '/service-management'
];


interface IService {
  _id: string,
  name: string,
}


@Injectable()
export class ClientPermService {
  public current_user: any = {
    user_id: "",
    isCustomer: true,
    roles: [],
    perms: [],
    dist_id: "",
    username: "",
    fullname: "",
    can: {},
    serviceList: [], // save temp buy service list
    used_free_trial: false,
    services: []
  };
  current_dist: any = {};
  distributors = [];

  /**
   * Cached current service list
   */
  public serviceList: IService[] = [];

  constructor(protected permAPI: PermService,
              protected translate: TranslateService,
              protected cookie: CookieService) {
  }

  /**
   * This is the method you want to call at bootstrap
   * Important: It should return a Promise
   */
  load(raiseError = true): Promise<any> {

    return this.permAPI.getPermList().toPromise().then((resp: any) => {
      this.loadData(resp.data);
    }, (reason: any) => {
      if (raiseError) {
        setTimeout(() => { throw reason; }, 0);
      }
    });
  }

  /**
   * Load perm for current user
   */
  loadData(data) {
    const cu = data.current_user;
    Object.assign(this.current_user, cu);

    Object.keys(cu.perms).map(perm => {
      let scope = cu.perms[ perm ];

      // set flag permission, eg: cu.can.edit_admin == true
      this.current_user.can[ perm ] = true;

      // set flag permission_scop, eg: cu.can.edit_admin_sys == true
      const scope_list = [ 'sys', 'dist', 'sale', 'owner' ];
      const idx = scope_list.indexOf(scope);

      for (let i = idx; i < scope_list.length; i++) {
        this.current_user.can[ perm + '_' + scope_list[ i ] ] = true;
      }
    });

    (this.current_user.services || []).map(s => {
      let perm = `__customer_config_service_${s}`;
      this.current_user.can[ perm ] = true;
    });

    this.current_user.isCustomer = this.current_user.roles.indexOf('customer') != -1;
    let user = {
      'id': cu[ 'user_id' ],
      'username': cu[ 'username' ],
      'full_name': cu[ 'fullname' ],
      'distributor_id': cu[ 'dist_id' ],
      'distributor_name': cu[ 'dist_name' ],
      'distributor_default': cu[ 'dist_default' ],
      'email': cu[ 'email' ]
    };
    window[ 'cp_user' ] = user;

    // console.log(this.current_user);
  }

  /**
   * Extrac root path from url
   */
  url2path(url) {
    return url.split('?')[ 0 ];
  }

  /**
   * Check if user can access this url
   */
  canAccessUrl(url) {
    url = this.url2path(url);
    const perms = ACCESS_PAGES[ url ];
    if (typeof perms === 'boolean') return perms;
    else if (typeof perms == 'string') return this.current_user.can[ perms ];
    return false;
  }

  /**
   * Get url user can navigate if possible, else return /403
   */
  getUrlAccessable() {
    for (const url of ACCESSABLE_PAGES) {
      if (this.canAccessUrl(url)) {
        return url;
      }
    }
    return '/403';
  }

  setDistributor(dist) {
    this.current_dist = dist;
  }

  isEnableWebProtection() {
    return this.current_user.services.indexOf("wp") >= 0;
  }

  isEnableDDoSL4() {
    return this.current_user.services.indexOf("ddosl4") >= 0;
  }

  isLoggedIn() {
    return Boolean(this.current_user.user_id);
  }

  /**
   * Set language for CAS.
   * This should be called when Cloud portal change language.
   */
  setCasLang(lang?) {
    if (!lang) {
      lang = this.translate.currentLang;
    }
    this.cookie.put('cp_lang', lang, {path: '/'});
  }
}
