import { Injector, Injectable } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import {OrderService, PriceService, PublicService, ShopCartService} from "@common/swagger-services";
import { _, castArray, swalNotiSuccess, swalShowConfirmHtml, swalShowHtml, swalShowSuccess, swalShowWarn } from "@common/utils";
import { TranslateService } from "@ngx-translate/core";
import { ClientPermService } from "@common/services";
import { Service } from '@customer/cpanel-pages/payflow/components/select-options/payflow-new-package.component';


@Injectable()
export class SelectPackageHelper {
  protected router: Router;
  protected priceService: PriceService;
  protected translate: TranslateService;
  protected selectedList: string[] = [];
  protected orderService: OrderService;
  serviceList = [];
  servicePackageMap = [];

  constructor(
      protected injector: Injector,
      protected clientPerm: ClientPermService,
      private publicService: PublicService,
      protected packageService: PriceService,
      protected shopCartService: ShopCartService,
  ) {
    this.router = injector.get(Router);
    this.priceService = injector.get(PriceService);
    this.translate = injector.get(TranslateService);
    this.orderService = injector.get(OrderService);
    this.onCardSelected = this.onCardSelected.bind(this);
    this.onClickTrial = this.onClickTrial.bind(this);
    this.onClickAddToCart = this.onClickAddToCart.bind(this);
  }

  onCardSelected(sv, pkg, step?, url?) {
    if (!this.clientPerm.current_user.user_id) {
      // if it have not register yet
      // TODO pass selected packages to cart
      localStorage.setItem('buyPkg', pkg._id);
      localStorage.setItem('buyPkgUser', '');
      url = url || this.router.url;
      this.router.navigate(['/popup'], {queryParams: {'type': 'signup', 'url': url}});
      return;
    }

    this.priceService.getBuyPackage(pkg._id, sv._id).subscribe(resp => {
      const data = resp.data || {};
      if (data.type == 'warning') {
        let t = this.translate.instant(data.message, data.message_params);
        swalShowHtml(data.title, t, data.type);
        return;
      } else if (data.type == 'confirm') {
        let t = this.translate.instant(data.message, data.message_params);
        swalShowConfirmHtml(data.title, t, () => this._buyPackageExt(step, sv, pkg, data.action, data.cs_id));
      } else {
        this._buyPackageExt(step, sv, pkg, data.action, data.cs_id);
      }
    });
  }

  onClickTrial(sv, pkg, url?) {
    if (this._requireLogin(url)) return;

    const model: any = {
      type: 'trial',
      customer_id: '',
      amount: pkg.price,
      payment_status: 'unpaid',
      status: 'processing',
      packages: [ pkg._id ],
    };
    this.orderService.postOrderList(model).subscribe((resp: any) => {
      if (resp.status) {
        this.navigate([ '/c/orders' ]);
        setTimeout(() => swalShowSuccess('Success', 'Đã tạo đơn hàng dùng thử. Vui lòng chờ trong khi quản trị viên duyệt đơn hàng.'), 300);
      } else {
        swalShowWarn('Warn', resp.message);
      }
    }, err => {
      err = err || {};
      if (err.status == 422) {
        swalShowWarn('Warn', (err.error || {}).message || 'Unexpected Error');
      }
    });
  }

  onClickAddToCart(sv, pkg, url?) {
    if (this.publicService.isProdVersion()) {
      swalShowWarn(_("Thông báo"), _("Chức năng sẽ sớm ra mắt trong thời gian tới"));
      return;
    }

    if (this._requireLogin(url)) return;

    let services = [ sv[ '_id' ], pkg[ '_id' ] ].join();
    this.parseServicePackageMap(services);
    this.getServiceData(this.servicePackageMap.map(v => v[ 1 ]));
  }

  parseServicePackageMap(services) {
    services = castArray(services);
    this.servicePackageMap = services.map(v => v.split(','));
  }

  getServiceData(serviceList) {
    const u = void 0;
    this.packageService.getPriceList(u, u, u, u, u, u, u, u, u, u, serviceList)
      .subscribe((resp: any) => {
        this.parseServiceData(resp.data.rows, serviceList);
      });
  }

  parseServiceData(serviceList, services, cb?) {
    this.serviceList = serviceList.map(v => {
      v = new Service(v);
      v.setCurPackage(services[ 0 ]);
      return v;
    });
    let service = JSON.parse(JSON.stringify(this.serviceList[ 0 ]));
    service.packageList = [ JSON.parse(JSON.stringify(service.curPackage)) ];
    service.stt = "stt_" + new Date().getUTCMilliseconds();
    const cur_user = this.clientPerm.current_user;
    let sp = castArray(services)[ 0 ];
    let [ sid, pid ] = sp.split(',');
    this.shopCartService.getShopCart(cur_user.user_id).subscribe(res => {
        if (res.data) {
            let user_cache = {
                customer_id: cur_user.user_id,
                services: res.data.services,
                serviceList: res.data.serviceList
            };
            let cart_ids = user_cache.serviceList.map(v => v.curPackage._id);
            this.packageService.getAddtoCart(service.curPackage._id, cart_ids).subscribe(resp => {
                const data = resp.data || {};
                if (resp.data.valid) {
                    user_cache.services.push([ sid, pid ]);
                    user_cache.serviceList.push(service);
                    this.shopCartService.postShopCart(user_cache).subscribe(res3 => {
                        swalNotiSuccess('Giỏ hàng', this.translate.instant('Đã thêm vào giỏ'));
                        if (cb) cb();
                    });
                } else {
                    swalShowWarn('Warn', data.message);
                }
            });
        } else {
            let user_cache = {
                customer_id: cur_user.user_id,
                services: [ [ sid, pid ] ],
                serviceList: [ service ]
            };
            this.shopCartService.postShopCart(user_cache).subscribe(res2 => {
                swalNotiSuccess('Giỏ hàng', this.translate.instant('Đã thêm vào giỏ'));
                if (cb) cb();
            });
        }
    });
  }

  /**
   * If not login then redirect to /api/login, also add ?from= to url
   * to allow CAS return to this url incase user close login popup.
   */
  _requireLogin(url?) {
    if (!this.clientPerm.current_user.user_id) {
      url = url || this.router.url;
      url = encodeURIComponent(url);
      let lang = this.translate.currentLang;
      window.location.href = `${window.location.origin}/api/login?from=${url}&lang=${lang}`;
      return true;
    }
    return false;
  }

  _buyPackageExt(step, sv, pkg, action, csId?) {
    const q = {};
    if (action == 'upgrade') {
      q[ 'csId' ] = csId;
      q[ 'substep' ] = 2;
      q[ 'services' ] = pkg._id;
      q[ 'action' ] = action;
    } else if (action == 'renew') {
      q[ 'csId' ] = csId;
      q[ 'substep' ] = 2;
      q[ 'action' ] = action;
    } else if (action == 'defer') {
      q[ 'services' ] = pkg._id;
      q[ 'substep' ] = 2;
      q[ 'action' ] = action;
    } else {
      const pid = pkg._id;
      q[ 'services' ] = this.selectedList.concat(pid);
      q[ 'substep' ] = 2;
      q[ 'action' ] = action;
      // cannot use step i have to use _step
      q[ '_step' ] = step;
    }
    this.navigate([ '/c/payflow' ], { queryParams: q });
  }

  navigate(url, opt?) {
    setTimeout(() => this.router.navigate(url, opt), 100);
  }
}
