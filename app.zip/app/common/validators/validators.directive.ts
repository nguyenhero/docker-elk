import {Directive, forwardRef} from '@angular/core';
import {NG_VALIDATORS, AbstractControl, ValidatorFn, Validator, FormControl} from '@angular/forms';

import {
    DomainValidator,
    Ip46Validator,
    IpValidatorFn,
    IpPortValidatorFn,
    PositiveIntValidator,
    DomainPortValidator,
    DomainValidatorFn
} from './validators';

// @Directive({
//     selector: '[juriName][ngModel]',
//     providers: [
//         { provide: NG_VALIDATORS, useExisting: JuriNameValidator, multi: true }
//     ]
// })
export class BaseValidatorDirective implements Validator {
    validator: ValidatorFn;

    validate(c: FormControl) {
        return this.validator(c);
    }
}

// @Directive({
//     selector: '[percentNumber][ngModel]',
//     providers: [
//         { provide: NG_VALIDATORS, useExisting: PercentageValidator, multi: true }
//     ]
// })
// export class PercentageValidatorDirective extends BaseValidatorDirective {
//     validator = PercentageValidator;
// }

@Directive({
    selector: '[domainValidate][ngModel]',
    providers: [
        {provide: NG_VALIDATORS, useExisting: DomainValidatorDirective, multi: true}
    ]
})
export class DomainValidatorDirective extends BaseValidatorDirective {
    validator = DomainValidator;
}

@Directive({
    selector: '[ipv46Validate][ngModel]',
    providers: [
        {provide: NG_VALIDATORS, useExisting: Ip46ValidatorDirective, multi: true}
    ]
})
export class Ip46ValidatorDirective extends BaseValidatorDirective {
    validator = Ip46Validator;
}

@Directive({
    selector: '[ipv46MultiValidate][ngModel]',
    providers: [
        {provide: NG_VALIDATORS, useExisting: Ipv46MultiValidatorDirective, multi: true}
    ]
})
export class Ipv46MultiValidatorDirective extends BaseValidatorDirective {
    validate(c: FormControl) {
        if (!c.value) {
            return null;
        }
        let ips = c.value.split(',');
        for (let ip of ips) {
            if (!IpValidatorFn(ip)) {
                return {
                    'ip': {
                        valid: false
                    }
                };
            }
        }
    }
}

@Directive({
    selector: '[portValidate][ngModel]',
    providers: [
        {provide: NG_VALIDATORS, useExisting: PortValidatorDirective, multi: true}
    ]
})
export class PortValidatorDirective extends BaseValidatorDirective {
    validator = DomainPortValidator;
}

@Directive({
    selector: '[ipPortMultiValidate][ngModel]',
    providers: [
        {provide: NG_VALIDATORS, useExisting: IpPortMultiValidatorDirective, multi: true}
    ]
})
export class IpPortMultiValidatorDirective extends BaseValidatorDirective {
    validate(c: FormControl) {
        if (!c.value) {
            return null;
        }
        let ips = c.value.split(',');
        for (let ip of ips) {
            if (!IpPortValidatorFn(ip)) {
                return {
                    'ip': {
                        valid: false
                    }
                };
            }
        }
    }
}

@Directive({
    selector: '[websiteBackendValidate][ngModel]',
    providers: [
        {provide: NG_VALIDATORS, useExisting: WebsiteBackendValidatorDirective, multi: true}
    ]
})
export class WebsiteBackendValidatorDirective extends BaseValidatorDirective {
    validate(c: FormControl) {
        if (!c.value) {
            return null;
        }
        if (DomainValidatorFn(c.value)) {
            return;
        }
        let ips = c.value.split(',');
        for (let ip of ips) {
            if (!IpPortValidatorFn(ip)) {
                return {
                    'backend': {
                        valid: false
                    }
                };
            }
        }
    }
}

export function validateBackendsGetError(value, blacklist?) {
    if (value == null || value == undefined) return null;
    if(blacklist && new Set(blacklist).has(value)){
        return {'backend': true}
    }
    if (DomainValidatorFn(value)) {
        return;
    }
    let ips = value.split(',');
    for (let ip of ips) {
        if (!IpPortValidatorFn(ip)) {
            return {
                'backend': true
            };
        }
    }
}
