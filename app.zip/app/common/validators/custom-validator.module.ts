import {NgModule} from '@angular/core';

import {
  FOSEC_VALIDATORS
} from '.';

import {
  VISC_VALIDATOR_DIRECTIVES
} from '.'

@NgModule({
  imports: [],
  declarations: [
    ...FOSEC_VALIDATORS,
    ...VISC_VALIDATOR_DIRECTIVES
  ],
  exports: [
    ...FOSEC_VALIDATORS,
    ...VISC_VALIDATOR_DIRECTIVES
  ]
})
export class PortalCustomValidatorModule {
}

