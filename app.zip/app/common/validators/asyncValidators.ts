import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import {Observable} from "rxjs/Observable";

export function asyncAccountValidator(c: FormControl, setError) {
    this.sub02 = c.valueChanges.map(v => {
      this.errors.loading = true;
      return v;
    }).debounceTime(400).switchMap((v: any) => {
      let isNull = (!v || !v.trim());
      if(isNull){
        return Observable.of('value_empty');
      }
      if (!v || c.errors) return Observable.of(null);
      const body: any = {username: c.value};
      return this.publicService.postValidate(body);
    }).subscribe((resp: any) => {
      this.errors.loading = false;
      if (!resp) return;
      if(resp === 'value_empty'){
        this.errors.name = setError('FIELD_REQUIRED');
      }
      if(resp !== 'value_empty'){
        if (!resp.data.valid) {
          this.errors.name = setError(resp.data.error || 'INVALID_VALID');
        } else {
          this.errors.name = setError();
        }
      }
    }, err => {   
      this.errors.loading = false;
    });
}

/*
* Avoid input serie of space characters => return field required error
*/
export function asyncSpaceNullValidator(c: FormControl, setError) {
    this.sub02 = c.valueChanges.map(v => {
      this.errors.loading = true;
      return v;
    }).debounceTime(400).switchMap(v => {
      if (!v || c.errors) return Observable.of(null);
      return Observable.of(v);
    }).subscribe((v: any) => {
      this.errors.loading = false;
      if(v === null) return;
      let isNull = (!v || !v.trim());
      if(isNull){
        this.errors.name = setError('FIELD_REQUIRED')
      }else{
        this.errors.name = setError();
      }
    }, err => {   
      this.errors.loading = false;
    });
  }