import {
  Password2Validator,
  Content2Validator,
  Name2Validator,
  Title2Validator,
  Fullname2Validator,
  CpEmail2Validator
} from './whiltelist';

import {
  DomainValidatorDirective,
  Ip46ValidatorDirective,
  Ipv46MultiValidatorDirective,
  IpPortMultiValidatorDirective,
  WebsiteBackendValidatorDirective,
  PortValidatorDirective
} from './validators.directive';

export const FOSEC_VALIDATORS = [
  Password2Validator,
  Content2Validator,
  Fullname2Validator,
  Name2Validator,
  Title2Validator,
  CpEmail2Validator
];

export const VISC_VALIDATOR_DIRECTIVES = [
  DomainValidatorDirective,
  Ip46ValidatorDirective,
  Ipv46MultiValidatorDirective,
  IpPortMultiValidatorDirective,
  WebsiteBackendValidatorDirective,
  PortValidatorDirective
];
