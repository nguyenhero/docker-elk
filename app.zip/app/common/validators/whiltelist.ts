import {Directive, forwardRef} from '@angular/core';
import {NG_VALIDATORS, Validator, AbstractControl} from '@angular/forms';
import {Validators, ValidatorFn} from '@angular/forms';

export function isPresent(obj: any): boolean {
  return obj !== undefined && obj !== null;
}

const TITLE_REGEX = /^[abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểếẾỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸýửữựỳỵỷỹ\ \~\!\@\#\$\%\^\&\*\(\)\_\+\{\}\:\"\<\>\?\`\-\=\[\]\\\;\'\,\.\/]{0,1024}$/;
const CONTENT_REGEX = /^[abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểếẾỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸýửữựỳỵỷỹ\ \~\!\@\#\$\%\^\&\*\(\)\_\+\{\}\:\"\<\>\?\`\-\=\[\]\\\;\'\,\.\/\r\n]{0,10000}$/;
const NAME_REGEX = /^[a-z0-9\_\-]{0,1024}$/;
const FULLNAME_REGEX = /^[abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểếẾỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳýỵỷỹ\ 0-9]{0,1024}$/;

//const PASSWORD_REGEX = /^(?=.*\d)(?=.*[\~\!\@\#\$\%\^\&\*\(\)\_\+\{\}\:\"\<\>\?\`\-\=\[\]\\\;\'\,\.\/\|])(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9\~\!\@\#\$\%\^\&\*\(\)\_\+\{\}\:\"\<\>\?\`\-\=\[\]\\\;\'\,\.\/\|]{8,32}$/;

function regexEscape(s) {
    return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
}

const SPECIAL_CHARS = '-=`~!@#$%^&*()_+{}[];,\./\\<>?:"|';  // without ' as it include in PASSWORD_REGEX
export const PASSWORD_REGEX = new RegExp('^(?=.*\\d)(?=.*[\'' + regexEscape(SPECIAL_CHARS) + '])(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9\'' + regexEscape(SPECIAL_CHARS) + ']{8,32}$');

/*
 * title
 */
export const titleValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
  if (isPresent(Validators.required(control))) return null;

  let v: string = control.value;
  return TITLE_REGEX.test(v) ? null : {titleValidate: 'INVALID_VALUE'};
};

const TITLE_VALIDATOR: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => Title2Validator),
  multi: true
};

@Directive({
  selector: '[titleValidate][ngModel]',
  providers: [TITLE_VALIDATOR]
})
export class Title2Validator implements Validator {
  validate(c: AbstractControl): { [key: string]: any } {
    return titleValidator(c);
  }
}

/*
 * content
 */
export const contentValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
  if (isPresent(Validators.required(control))) return null;

  let v: string = control.value;
  return CONTENT_REGEX.test(v) ? null : {contentValidate: 'INVALID_VALUE'};
};

const CONTENT_VALIDATOR: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => Content2Validator),
  multi: true
};

@Directive({
  selector: '[contentValidate][ngModel]',
  providers: [CONTENT_VALIDATOR]
})
export class Content2Validator implements Validator {
  validate(c: AbstractControl): { [key: string]: any } {
    return contentValidator(c);
  }
}

/*
 * name
 */
export const nameValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
  if (isPresent(Validators.required(control))) return null;

  let v: string = control.value;
  return NAME_REGEX.test(v) ? null : {nameValidate: 'INVALID_VALUE'};
};

const NAME_VALIDATOR: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => Name2Validator),
  multi: true
};

@Directive({
  selector: '[nameValidate][ngModel]',
  providers: [NAME_VALIDATOR]
})
export class Name2Validator implements Validator {
  validate(c: AbstractControl): { [key: string]: any } {
    return nameValidator(c);
  }
}

/*
 * fullname
 */
export const fullnameValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
  if (isPresent(Validators.required(control))) return null;

  let v: string = control.value;
  return FULLNAME_REGEX.test(v) ? null : {fullnameValidate: 'PATTERN_FULLNAME_ERROR'};
};

const FULLNAME_VALIDATOR: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => Fullname2Validator),
  multi: true
};

@Directive({
  selector: '[fullnameValidate][ngModel]',
  providers: [FULLNAME_VALIDATOR]
})
export class Fullname2Validator implements Validator {
  validate(c: AbstractControl): { [key: string]: any } {
    return fullnameValidator(c);
  }
}

/*
 * pwd
 */
export const passwordValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
  if (isPresent(Validators.required(control))) return null;

  let v: string = control.value;
  return PASSWORD_REGEX.test(v) ? null : {passwordValidate: 'INVALID_PASSWORD'};
};

const PWD_VALIDATOR: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => Password2Validator),
  multi: true
};

@Directive({
  selector: '[passwordValidate][ngModel]',
  providers: [PWD_VALIDATOR]
})
export class Password2Validator implements Validator {
  validate(c: AbstractControl): { [key: string]: any } {
    return passwordValidator(c);
  }
}

/*
 * cpemail
 */
export const cpemailValidator: ValidatorFn = (control: AbstractControl): { [key: string]: any } => {
  if (isPresent(Validators.required(control))) return null;

  let v: string = control.value.trim();
  if (!v) return null; // ignore all whitespace
  return /^[a-zA-Z0-9.!#$%&’*+\/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(v) ? null : {'cpemail': true};
  // return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(v) ? null : {'cpemail': true};
};

const CPEMAIL_VALIDATOR: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => CpEmail2Validator),
  multi: true
};

@Directive({
  selector: '[cpemail][formControlName],[cpemail][formControl],[cpemail][ngModel]',
  providers: [CPEMAIL_VALIDATOR]
})
export class CpEmail2Validator implements Validator {
  validate(c: AbstractControl): { [key: string]: any } {
    return cpemailValidator(c);
  }
}