export const aup_content = {
    main_title: "Acceptable Use Policy",
    desc_highlight: "THIS ACCEPTABLE USE POLICY (“AUP”)",
    desc_normal: "is incorporated into the CLOUDRITY Service Agreement (“SA”) and describes acceptable use of and access to the Services offered by Cloudrity Corporation (“CLOUDRITY”). BY ACCESSING OR USING THE SERVICES, YOU AGREE TO THE TERMS OF THIS AUP. If Customer (or “You”) violates this AUP or authorize or help others to do so, CLOUDRITY may suspend or terminate your use of the Services in accordance with the terms of the SA. Unless otherwise defined herein, all capitalized terms used within this AUP have the same meaning as ascribed to such terms in the SA.",
    body:[
        {
            title: "PROHIBITED USE",
            sub_content:[
                {text:"Customer may not use the Services in a manner that CLOUDRITY believes:",level: 1},
                {text:"aaaa",level: 2},
                {text:"aaaa",level: 2},
                {text:"aaaa",level: 2},
                {text:"aaaa",level: 2},
                {text:"aaaa",level: 2},
                {text:"aaaa",level: 2},
                {text:"aaaa",level: 2},
                {text:"aaaa",level: 2},
            ]
        }
    ]
} 