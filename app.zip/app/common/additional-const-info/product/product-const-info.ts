export const productsFix = [
    {
        "_id": "5a6f04b4da0d1e47f8d15e34",
        "name": "WAF",
        "title": "Web Protection",
        "desc": "Web_Protection_desc"
    },
    {
        "_id": "5a6f04fada0d1e47f8d15e35",
        "name": "DDOS",
        "title": "DDoS Protection",
        "desc": "DDoS_Protection_desc"
    },
    // {
    //     "_id": "5d941a89779a1b46208fef1f",
    //     "name": "WA",
    //     "title": "Web Analytics",
    //     "desc": "Web_Analytic_desc"
    // },
    // {
    //     "_id": "5a6f0554da0d1e47f8d15e37",
    //     "name": "EMAIL",
    //     "title": "Email Protection",
    //     "desc": ""
    // }
];
