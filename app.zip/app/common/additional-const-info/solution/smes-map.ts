export var smes_map = [
    // {
    //     "name":"anhhv41",
    //     "title": "Anh Ho",
    //     "lat": "10",
    //     "log": "50",
    //     "text_postion": "right"
    // },
    // {
    //     "name":"anhhv",
    //     "title": "Anh Dz",
    //     "lat": "50",
    //     "log": "50",
    //     "text_postion": "left"
    // },

    // 
    {
        "name":"peru",
        "title": "Peru",
        "lat": "67",
        "log": "32",
        "text_postion": "left"
    },
    {
        "name":"haiti",
        "title": "Haiti",
        "lat": "51",
        "log": "32.5",
        "text_postion": "right"
    },
    {
        "name":"tanzania",
        "title": "Tanzania",
        "lat": "66",
        "log": "54.5",
        "text_postion": "right"
    },
    {
        "name":"burundi",
        "title": "Burundi",
        "lat": "61",
        "log": "53",
        "text_postion": "left"
    },
    {
        "name":"mozambique",
        "title": "Mozambique",
        "lat": "75.7",
        "log": "54",
        "text_postion": "left"
    },
    {
        "name":"myanmar",
        "title": "Myanmar",
        "lat": "49",
        "log": "66.7",
        "text_postion": "above"
    },
    {
        "name":"laos",
        "title": "Laos",
        "lat": "52",
        "log": "68",
        "text_postion": "left"
    },
    {
        "name":"cambodia",
        "title": "Cambodia",
        "lat": "55.5",
        "log": "68.5",
        "text_postion": "left"
    },
    {
        "name":"vietnam",
        "title": "Viet Nam",
        "lat": "51",
        "log": "69",
        "text_postion": "right"
    },
    {
        "name":"timoleste",
        "title": "Timo Leste",
        "lat": "69",
        "log": "73",
        "text_postion": "right"
    }
]