
export const faqsGeneral = [
  {
    id: "payment",
    title: "Payment FAQs",
    content:[
      {
        expanded: false,
        q: 'fqas_gen_payment_q_1',
        a: 'fqas_gen_payment_a_1',
        ul: false
      },
      {
        expanded: false,
        q: 'fqas_gen_payment_q_2',
        a: 'fqas_gen_payment_a_2',
        ul: false
      },
      {
        expanded: false,
        q: 'fqas_gen_payment_q_3',
        a: 'fqas_gen_payment_a_3',
        ul: false
      },
    ]
  },
  {
    id: "servicesetup",
    title: "Service Setup FAQs",
    content: [
      {
        expanded: false,
        q: "fqas_gen_servicesetup_q_1",
        a: "fqas_gen_servicesetup_a_1",
        ul: false
      },
      {
        expanded: false,
        q: "fqas_gen_servicesetup_q_2",
        a: "fqas_gen_servicesetup_a_2",
        ul: false
      }
    ]
  },
  {
    id: "planandpricing",
    title: "Plans & Pricing FAQs",
    content: [
      {
        expanded: false,
        q: "fqas_gen_plan&pricing_q_1",
        a: "fqas_gen_plan&pricing_a_1",
        ul: false
      },
      {
        expanded: false,
        q: "fqas_gen_plan&pricing_q_2",
        a: "fqas_gen_plan&pricing_a_2",
        ul: false
      }
    ]
  },
  {
    id: "general",
    title: "General Sub FAQs",
    content: [
      {
        expanded: false,
        q: "fqas_gen_general_q_1",
        a: "fqas_gen_general_a_1",
        ul: false
      },
      {
        expanded: false,
        q: "fqas_gen_general_q_2",
        a: "fqas_gen_general_a_2",
        ul: true,
        u_list: [
          "fqas_gen_general_a_2_li_1",
          "fqas_gen_general_a_2_li_2",
          "fqas_gen_general_a_2_li_3",
          "fqas_gen_general_a_2_li_4",
          "fqas_gen_general_a_2_li_5",
        ]
      }
    ]
  }
]

export const faqsWAF = [
    {
      expanded: false,
      q: 'fqas_waf_q_1',
      a: 'fqas_waf_a_1',
      ul: false
    },
    {
      expanded: false,
      q: 'fqas_waf_q_2',
      a: 'fqas_waf_a_2',
      ul: false
    },
    {
      expanded: false,
      q: 'fqas_waf_q_3',
      a: 'fqas_waf_a_3',
      ul: true,
      u_list:["fqas_waf_a_3_li_1","fqas_waf_a_3_li_2"]
    },
  ]

  export const faqsDDoS = [
    {
      expanded: false,
      q: 'fqas_ddos_q_1',
      a: 'fqas_ddos_a_1',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_2',
      a: 'fqas_ddos_a_2',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_3',
      a: 'fqas_ddos_a_3',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_4',
      a: 'fqas_ddos_a_4',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_5',
      a: 'fqas_ddos_a_5',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_6',
      a: 'fqas_ddos_a_6',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_7',
      a: ['fqas_ddos_a_7_1','fqas_ddos_a_7_2','fqas_ddos_a_7_3'],
      multi_graph: true
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_8',
      a: 'fqas_ddos_a_8',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_9',
      a: 'fqas_ddos_a_9',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_10',
      a: 'fqas_ddos_a_10',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_11',
      a: 'fqas_ddos_a_11',
      multi_graph: false
    },
    {
      expanded: false,
      q: 'fqas_ddos_q_12',
      a: 'fqas_ddos_a_12',
      multi_graph: false
    },
  ]

  export const faqsEmail = [
    {
      expanded: false,
      q: 'faq_email_a_1',
      a: 'faq_email_q_1',
    },
    {
      expanded: false,
      q: 'faq_email_a_2',
      a: 'faq_email_q_2',
    },
    {
      expanded: false,
      q: 'faq_email_a_3',
      a: 'faq_email_q_3',
    },
    {
      expanded: false,
      q: 'faq_email_a_4',
      a: 'faq_email_q_4',
    },
  ];