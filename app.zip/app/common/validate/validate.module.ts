import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {
  IpValidator,
  UriValidator,
  UrlValidator,
  PortValidator
} from './directives';
import {IpRangeValidator} from "./validators/iprange";
import {IpDomainValidator} from "./validators/ipdomain";
import {NoFullWSValidator} from "./validators/nofullws";
import {AsyncUniqueCustomerEmailValidator} from "./validators/customer_email";
import {AsyncUniqueCustomerCmtValidator} from "./validators/async_unique_customer_cmt";
import {AsyncUniqueCustomerMstValidator} from "./validators/async_unique_customer_mst";
import {RequiredFullValidator} from "./my_directives";

@NgModule({
  declarations: [
    IpValidator,
    UriValidator,
    UrlValidator,
    PortValidator,
    IpRangeValidator,
    IpDomainValidator,
    NoFullWSValidator,
    AsyncUniqueCustomerEmailValidator,
    AsyncUniqueCustomerCmtValidator,
    AsyncUniqueCustomerMstValidator,
    RequiredFullValidator,
  ],
  exports: [
    IpValidator,
    UriValidator,
    UrlValidator,
    PortValidator,
    IpRangeValidator,
    IpDomainValidator,
    NoFullWSValidator,
    AsyncUniqueCustomerEmailValidator,
    AsyncUniqueCustomerCmtValidator,
    AsyncUniqueCustomerMstValidator,
    RequiredFullValidator,
  ]
})
export class MyValidateModule {
}