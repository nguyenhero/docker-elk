import {ChangeDetectorRef, Directive, forwardRef} from "@angular/core";
import {NG_ASYNC_VALIDATORS, Validator, AbstractControl} from "@angular/forms";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs/Rx";
import {API_BASE_URL} from "@customer/config";

@Directive({
  selector: "[asyncUniqueCustomerCmt][formControlName], [asyncUniqueCustomerCmt][ngModel]",
  providers: [
    {
      provide: NG_ASYNC_VALIDATORS,
      useExisting: forwardRef(() => AsyncUniqueCustomerCmtValidator), multi: true
    }
  ]
})

export class AsyncUniqueCustomerCmtValidator implements Validator {
  constructor(private http: HttpClient,
              private cd: ChangeDetectorRef) {

  }

  validate(c: AbstractControl): Observable<{ [key: string]: any }> {
    let url = API_BASE_URL + '/profile/validate/';
    let body = {id_number: c.value.trim()};
    return this.http.post(url, body).map((resp: any) => {
      let err = resp.data.valid ? null : {exist: true};

      // force change immediately
      c.setErrors(err);
      this.cd.detectChanges();

      return err;
    });
  }
}