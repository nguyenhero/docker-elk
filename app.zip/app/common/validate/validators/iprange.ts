import {AbstractControl, NG_VALIDATORS} from "@angular/forms";
import {Directive, forwardRef} from "@angular/core";
import {MyValidators} from "@common/validate/validators/my_validators";

@Directive({
  selector: '[iprangeValidate]',
  providers: [{provide: NG_VALIDATORS, useExisting: forwardRef(() => IpRangeValidator), multi: true}]
})
export class IpRangeValidator {
  validate(c: AbstractControl): { [key: string]: any } {
    return MyValidators.iprange(c);
  }
}