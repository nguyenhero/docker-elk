import {Directive, forwardRef} from "@angular/core";
import {AbstractControl, NG_VALIDATORS, Validator} from "@angular/forms";

const VALIDATOR: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => NoFullWSValidator),
  multi: true
};


@Directive({
  selector: '[noFullWS][formControlName],[noFullWS][formControl],[noFullWS][ngModel]',
  providers: [VALIDATOR]
})
export class NoFullWSValidator implements Validator {
  validate(c: AbstractControl): { [key: string]: any } {
    if (!c.value) return null;
    if (c.value.trim()) {
      return null;
    }
    return {'noFullWS': 'INVALID_VALUE'};
  }
}