import {AbstractControl, NG_VALIDATORS} from "@angular/forms";
import {Directive, forwardRef} from "@angular/core";
import {MyValidators} from "@common/validate/validators/my_validators";


@Directive({
  selector: '[ipDomainValidate]',
  providers: [{provide: NG_VALIDATORS, useExisting: forwardRef(() => IpDomainValidator), multi: true}]
})
export class IpDomainValidator {
  validate(c: AbstractControl): { [key: string]: any } {
    return MyValidators.ipdomain(c);
  }
}
