import {AbstractControl} from "@angular/forms/src/model";
import {ValidationErrors} from "@angular/forms/src/directives/validators";
import {Validators} from "@angular/forms";
import {ip46Regex} from "@common/validate/directives";
import {domainRegex} from "@common/validators/validators";
import {PASSWORD_REGEX} from "@common/validators/whiltelist";

export class MyValidators {
  /**
   * Validator that requires controls to have a non-empty value or no full whitespace.
   */
  static requiredfull(control: AbstractControl): ValidationErrors | null {
    if (control.value != null && (control.value + '').trim()) {
      return null;
    }
    return {required: true};
  }

  static required = MyValidators.requiredfull;

  /**
   * Validator that validate for domain name.
   */
  static domain(c: AbstractControl): ValidationErrors | null {
    const DOMAINREGEX = /^\s*([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+([A-Za-z]{2,6})\s*$/;

    // ignore empty or full whitespace (aka NULL ???), in most test case
    if (MyValidators.required(c)) {
      return null;
    }
    if (DOMAINREGEX.test(c.value)) {
      return null;
    }
    return {domain: true};
  }

  /**
   * Validator that validate for port number.
   */
  static port(c: AbstractControl): ValidationErrors | null {
    // ignore empty or full whitespace (aka NULL ???), in most test case
    if (MyValidators.required(c)) {
      return null;
    }

    let value = ('' + c.value).trim();
    let num = parseInt(value);
    if (num === NaN || num < 0 || num > 65535 || ("" + value).length != ("" + num).length) {
      return {'port': true};
    }
  }

  /**
   * Validator that validate for ip range.
   */
  static iprange(c: AbstractControl): ValidationErrors | null {
    // ignore empty or full whitespace (aka NULL ???), in most test case
    if (MyValidators.required(c)) {
      return null;
    }

    const ipRangeRegex = /^([0-9]{1,3}\.){3}[0-9]{1,3}(\/([0-9]|[1-2][0-9]|3[0-2]))?$/;
    let ips = c.value.trim().split(',').map(v => v.trim());
    for (let ip of ips) {
      if (!ipRangeRegex.test(ip)) {
        return {'iprange': true};
      }
    }
    return null;
  }

  /**
   * Validator that validate for ip or domain list.
   */
  static ipdomain(c: AbstractControl): ValidationErrors | null {
    // ignore empty or full whitespace (aka NULL ???), in most test case
    if (MyValidators.required(c)) {
      return null;
    }

    let ips = c.value.trim().split(',').map(v => v.trim());
    // console.log(ips);
    for (let ip of ips) {
      if (!ip46Regex.test(ip) && !domainRegex.test(ip)) {
        return {'ipdomain': true};
      }
    }
    return null;
  }

  /**
   * Validator that validate for email.
   */
  static email(c: AbstractControl): ValidationErrors | null {
    // ignore empty or full whitespace (aka NULL ???), in most test case
    if (MyValidators.requiredfull(c)) {
      return null;
    }

    const regex = /^\s*[a-zA-Z0-9\.\-_]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+\s*$/;
    if (Validators.pattern(regex)(c)) {
      return {'email': true};
    }
    return null;
  }

  /**
   * Validator that validate for password.
   */
  static password(c: AbstractControl): ValidationErrors | null {
    if (Validators.required(c)) {
      return null;
    }

    if (Validators.pattern(PASSWORD_REGEX)(c)) {
      return {'password': true};
    }
    return null;
  }

  /**
   * Validator that validate for password.
   */
  static username(c: AbstractControl): ValidationErrors | null {
    // ignore empty or full whitespace (aka NULL ???), in most test case
    if (MyValidators.requiredfull(c)) {
      return null;
    }

    const REGEX = /^\s*[a-z0-9\_]{6,32}\s*$/;
    if (Validators.pattern(REGEX)(c)) {
      return {'username': true};
    }
    return null;
  }
}