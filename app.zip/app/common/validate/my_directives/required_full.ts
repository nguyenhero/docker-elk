import {Directive, forwardRef} from "@angular/core";
import {AbstractControl, NG_VALIDATORS, Validator} from "@angular/forms";
import {MyValidators} from "../validators/my_validators";

const PROVIDER: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => RequiredFullValidator),
  multi: true
};


@Directive({
  selector: '[requiredfull][formControlName],[requiredfull][formControl],[requiredfull][ngModel]',
  providers: [PROVIDER]
})
export class RequiredFullValidator implements Validator {
  validate(c: AbstractControl): { [key: string]: any } {
    return MyValidators.requiredfull(c);
  }
}
