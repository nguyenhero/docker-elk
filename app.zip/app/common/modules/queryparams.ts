const DEFAULT_PAGE_NUMBER = 0;
const DEFAULT_PAGE_LIMIT = 10;


function format(v, type) {
  if (v == null) {
    return v;
  }
  v = decodeURIComponent(v);
  if (type === 'date') {
    v = new Date(v);
  } else if (type == 'multiselect') {
    v = v ? v.split(',') : null;
  }
  return v;
}

export class QueryParams {
  constructor(private model: any,
              private page: any,
              private sorts: any) {
  }

  /**
   * Convert search params to query params
   */
  _toParams(model): any {
    let params = {};
    for (let k of Object.getOwnPropertyNames(model)) {
      let v = model[k];
      if (v && v != '*') {
        if (v instanceof Array && v.length == 0) {
          continue;
        }
        else if (v == 'Invalid Date'){
          v = 'Invalid Date';
        }
        else if (v instanceof Date) {
          v = v.getFullYear() + '-' + (v.getMonth() + 1) + '-' + v.getDate();
        }
        params[k] = encodeURIComponent(v);
      }
    }
    return params;
  }

  /**
   * Generate query params from current search params
   */
  public generate() {
    let params = this._toParams(this.model);
    params.offset = this.page.pageNumber === DEFAULT_PAGE_NUMBER ? null : this.page.pageNumber;
    params.limit = this.page.size === DEFAULT_PAGE_LIMIT ? null : this.page.size;

    if (this.sorts[0]) {
      params.sortKey = this.sorts[0].prop;
      params.sortValue = this.sorts[0].dir;
    }
    /* add random string to force reload url even params is the same */
    params._r = (new Date()).getTime();
    return params;
  }

  /**
   * Parse query params to get search params
   */
  public parse(params, fields) {
    let model = params,
      offset = parseInt(params.offset) || DEFAULT_PAGE_NUMBER,
      limit = parseInt(params.limit) || DEFAULT_PAGE_LIMIT,
      sort = null;
    if (params.sortKey && params.sortValue) {
      sort = {
        key: params.sortKey,
        value: params.sortValue
      };
    }

    /* update parsed data to interface */
    this.page.pageNumber = offset;
    this.page.size = limit;
    for (let field of fields) {
      if (field.control) {
        this.model[field.prop] = format(params[field.prop], field.control.type);
      }
    }
    /* update interface datatable sorting */
    if (sort) {
      this.sorts[0] = {prop: sort.key, dir: sort.value};
    } else {
      this.sorts.length = 0;
    }
  }

  /**
   * Return params parsed from url
   */
  public getParams() {
    let sort = this.sorts[0];
    sort = sort ? {key: sort.prop, value: sort.dir == 'asc' ? 1 : -1} : {};
    return [
      this.model,
      this.page,
      sort
    ];
  }
}
