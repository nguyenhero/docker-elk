export class TooltipDef {
  constructor(public tooltip = '',
              public disabled = true,
              public position = 'above',
              public showDelay = 300) {
  }
}

export class TOOLTIP {
  static VIEW_DETAIL = new TooltipDef('Xem chi tiết', false);
  static EDIT = new TooltipDef('Sửa', false);
  static DELETE = new TooltipDef('Xóa', false);
  static VIEW_CUSTOMER_HELP = new TooltipDef('Xem hỗ trợ khách hàng', false);
  static VIEW_CUSTOMER_SUM = new TooltipDef('Xem thống kê khách hàng', false);
  static VIEW_CUSTOMER_SERVICE = new TooltipDef('Xem thống kê dịch vụ khách hàng', false);
  static NEW_ORDER = new TooltipDef('Tạo đơn hàng mới', false);
  static ACCEPT_ORDER = new TooltipDef('Chấp nhận', false);
  static CANCEL_ORDER = new TooltipDef('Từ chối', false);
  static DEL_OTP = new TooltipDef('Click để xóa mã OTP', false);
  static NEW_OTP = new TooltipDef('Tạo mới mã OTP', false);
  static DOUBLE_CLICK_EDIT = new TooltipDef('Bấm hai lần để chỉnh sửa', false);
  static DOWNLOAD = new TooltipDef('Tải về', false);
  static REPLY = new TooltipDef('Trả lời', false);
  static VIEW_TICKET = new TooltipDef('Xem ticket', false);
}
