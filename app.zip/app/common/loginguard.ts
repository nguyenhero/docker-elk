import {
  ActivatedRouteSnapshot, CanActivate, Router,
  RouterStateSnapshot
} from '@angular/router';
import { Injectable } from '@angular/core';
// import {SigninService} from '../session';
import { AuthAPI, ClientPermService } from './services';

@Injectable()
export class LoginRouteGuard implements CanActivate {

  constructor(private permService: ClientPermService,
    private router: Router) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    // only logged in user can access pages
    if (!this.permService.isLoggedIn()) {
      window.location.href = '/api/login';
      return false;
    }

    if (this.permService.canAccessUrl(state.url)) {
      return this.goPage(state.url);
    } else {
      this.router.navigate(['/403']);
      return false;
    }
  }

  goPage(url) {
    // if (url === '/') {
    //   url = this.permService.getUrlAccessable();
    //   this.router.navigate([url]);
    //   return false;
    // } else if (!this.permService.canAccess(url)) {
    //   this.router.navigate(['/403']);
    //   return false;
    // }
    return true;
  }

  goLogin() {
    this.router.navigate(['/session/signin']);
    return false;
  }
}


@Injectable()
export class IgnoreLoginRouteGuard implements CanActivate {

  constructor(private authAPI: AuthAPI,
    private router: Router) {
  }

  canActivate() {
    // return this.authAPI.isLoggedIn().map((resp: any) => {
    //   if (resp.code !== 200) {
    //     return true;
    //   } else {
    //     this.router.navigate(['/']);
    //     return false;
    //   }
    // });
    return true;
  }
}