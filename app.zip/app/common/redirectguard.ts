import {
  ActivatedRouteSnapshot, CanActivate, Router,
  RouterStateSnapshot
} from '@angular/router';

import {redirectBuyPackage} from '@customer/cpanel-pages/payflow/utils';

import {Injectable} from '@angular/core';
// import {SigninService} from '../session';
import {AuthAPI, ClientPermService} from './services';

@Injectable()
export class RedirectGuard implements CanActivate {
  constructor(private permService: ClientPermService,
              private router: Router) {
  }

  checkBuyPkg() {
    let key = 'buyPkg';
    let userKey = 'buyPkgUser';
    try{
        let buyPkgId = localStorage.getItem(key);
        let buyPkgUser = localStorage.getItem(userKey);
        if (buyPkgId && buyPkgUser == this.permService.current_user.username && buyPkgUser != '' && buyPkgUser != undefined) {
          localStorage.removeItem(key);
          localStorage.removeItem(userKey);
          redirectBuyPackage(this.router, buyPkgId);
          return 'buyPkgHits';
        }
    }catch(e){

    }

  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    let checkList = [this.checkBuyPkg.bind(this)];
    for (let fn of checkList) {
      let rl = fn();
      if (rl) {
        return false;
      }
    }
    return true;
    //   if (this.permService.canAccessUrl(state.url)) {
    //     return this.goPage(state.url);
    //   } else {
    //     this.router.navigate(['/403']);
    //     return false;
    //   }
  }
}