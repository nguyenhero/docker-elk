import { NgModule, ModuleWithProviders, SkipSelf, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Configuration } from './configuration';

import { AlertsMonitorService } from './api/alertsMonitor.service';
import { AttackMapService } from './api/attackMap.service';
import { AttackMonitorService } from './api/attackMonitor.service';
import { CusMonitorService } from './api/cusMonitor.service';
import { CustomerSelfServiceService } from './api/customerSelfService.service';
import { CustomerWafRulesService } from './api/customerWafRules.service';
import { DnsService } from './api/dns.service';
import { ResMonitorService } from './api/resMonitor.service';
import { WafSystemService } from './api/wafSystem.service';
import { WafWebsitesService } from './api/wafWebsites.service';
import { WebAnalyticsService } from './api/webAnalytics.service';

@NgModule({
  imports:      [ CommonModule, HttpClientModule ],
  declarations: [],
  exports:      [],
  providers: [
    AlertsMonitorService,
    AttackMapService,
    AttackMonitorService,
    CusMonitorService,
    CustomerSelfServiceService,
    CustomerWafRulesService,
    DnsService,
    ResMonitorService,
    WafSystemService,
    WafWebsitesService,
    WebAnalyticsService ]
})
export class ApiModule {
    public static forRoot(configurationFactory: () => Configuration): ModuleWithProviders {
        return {
            ngModule: ApiModule,
            providers: [ { provide: Configuration, useFactory: configurationFactory } ]
        }
    }

    constructor( @Optional() @SkipSelf() parentModule: ApiModule) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import your base AppModule only.');
        }
    }
}
