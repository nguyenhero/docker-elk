export let innerWidthMobile = 767;
export let innerWidthTablet = 1024;
export let innerWidthLaptop = 1366;

export function isMobileExtension() {
  // console.log('isMobileExtension', window.innerWidth <= innerWidthMobile);
  return window.innerWidth <= innerWidthMobile;
}

export function isTabletExtension() {
  // console.log('isTabletExtension');
  return window.innerWidth > innerWidthMobile && window.innerWidth <= innerWidthTablet;
}

export function isLaptopExtension() {
  return window.innerWidth > innerWidthTablet && window.innerWidth <= innerWidthLaptop;
}

export function isExtraLargeExtension() {
  return window.innerWidth > innerWidthLaptop;
}
