import {registerLocaleData} from "@angular/common";
import localeVi from "@angular/common/locales/vi";

/**
 * Fix vi locale and register it
 */
export function registerLocaleVi() {
  const localeVi_ = localeVi.slice();
  localeVi_[14][2] = '#,##0.00 ¤';
  registerLocaleData(localeVi_, 'vi');
}
