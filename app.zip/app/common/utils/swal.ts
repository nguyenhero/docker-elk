// import swal from 'sweetalert2';
import swal2 from './swal2';
import {getErrMsg} from './error-msg';
import {_} from "@common/utils/translate";

/**
 * Require password and OTP for lock or delete phone
 */
export function permissionSwal(callback?, options?) {
    const defaults = {password: true, otp: true};
    options = Object.assign({}, defaults, options);
    const requirePass = options.password;
    const requireOtp = options.otp;
    const confirmOTP: any = {
        title: 'Nhập mã OTP',
        input: 'text',
        showLoaderOnConfirm: true,
        showCancelButton: true,
        preConfirm: (text) => {
            if (text == '') {
                return swal2.showValidationError('Hãy nhập mã OTP');
            }
            return new Promise((resolve) => {
                setTimeout(() => {
                    if (callback) callback(resolve); else resolve();
                }, 1000);
            });
        },
        allowOutsideClick: false,
    };
    const confirmPassword: any = {
        title: 'Nhập mật khẩu quản trị',
        input: 'password',
        showCancelButton: true,
        showLoaderOnConfirm: true,
        preConfirm: (password) => {
            if (password == '') {
                return swal2.showValidationError('Hãy nhập mật khẩu quản trị');
            }
            if (!requireOtp) {
                return;
            }
            return new Promise((resolve) => {
                setTimeout(() => {
                    swal2.insertQueueStep(confirmOTP);
                    resolve();
                }, 1000);
            });
        },
        allowOutsideClick: false,
    };

    if (requirePass)
        return confirmPassword;
    return confirmOTP;
}

/**
 * Make success dialog for swal
 */
export function successSwal(title, text): any {
    return {
        title: title,
        text: text,
        type: 'success',
    };
}

/**
 * Make error dialog for swal
 */
export function errorSwal(title, text): any {
    return {
        title: title,
        text: text,
        type: 'error',
    };
}

/**
 * Make confirm dialog for swal
 */
export function confirmSwal(title, text): any {
    return {
        title: title,
        text: text,
        type: 'question',
        showCancelButton: true,
        focusCancel: true,
        cancelButtonText: "Hủy",
    };
}

/**
 * Wrapper swal display error message
 */
export function swalShowError(title, text) {
    return swal2(errorSwal(title, text));
}

/**
 * Wrapper swal display warning
 */
export function swalShowWarn(title, text) {
    return swal2({
        title: title,
        text: text,
        type: 'warning',
    });
}

/**
 * Wrapper swal display
 */
export function swalShowHtml(title, text, type?) {
    return swal2({
        title: title,
        html: text,
        type: type || 'info',
    });
}

/**
 * Display success message
 */
export function swalShowSuccess(title, text) {
    return swal2(successSwal(title, text));
}

/**
 * Display success message
 */
export function swalNotiSuccess(title, message, extras: any = {}) {
    const options: any = {
        title: title,
        text: message,
        toast: true,
        position: extras.position || 'top',
        timer: extras.timer || 4000,
        showConfirmButton: false,
        type: extras.type || 'success',
        background: extras.background || 'aliceblue',
    };
    return swalShow(options);
}

/**
 * Display info message
 */
export function swalShowInfo(title, message, extras: any = {}) {
    return swal2({
        title: title,
        text: message,
        type: 'success',
    });
}

/**
 * Display confirm message
 */
export function swalShowConfirm(title, text, callback?) {
    return swal2(confirmSwal(title, text)).then(result => {
        if (result.value) {
            callback();
        }
    });
}

/**
 * Display confirm message
 */
export function swalShowConfirmHtml(title, text, callback?) {
    return swal2({
        title: title,
        html: text,
        type: 'question',
        showCancelButton: true,
        focusCancel: true,
    }).then(result => {
        if (result.value) {
            callback();
        }
    });
}

/**
 * Wrapper swal display
 */
export function swalShow(modal) {
    return swal2(modal);
}

/**
 * Wrapper queue steps into swal
 */
export function swalQueue(steps) {
    return swal2.queue(steps);
}

/**
 * Wrapper insert step into swal queue
 */
export function swalInsertQueueStep(step) {
    return swal2.insertQueueStep(step);
}

/**
 * Make OTP require swal
 */
export function swalOTP(authAPI) {
    const confirmOTP: any = {
        title: 'Nhập mã OTP',
        input: 'text',
        showLoaderOnConfirm: true,
        showCancelButton: true,
        preConfirm: (text) => {
            if (text === '') {
                return swal2.showValidationError('Hãy nhập mã OTP');
            }
            return new Promise((resolve) => {
                authAPI.check_otp(text).subscribe(
                    resp => resolve(),
                    err => {
                        swal2.showValidationError(getErrMsg(err));
                        resolve();
                    });
            });
        },
        allowOutsideClick: false,
    };
    return confirmOTP;
}

/**
 * Make password require swal
 */
export function swalPassword(authAPI, nextStep = null) {
    const confirmPassword: any = {
        title: 'Nhập mật khẩu quản trị',
        input: 'password',
        showCancelButton: true,
        showLoaderOnConfirm: true,
        preConfirm: (password) => {
            if (password === '') {
                return swal2.showValidationError('Hãy nhập mật khẩu quản trị');
            }
            return new Promise((resolve) => {
                authAPI.check_password(password).subscribe(
                    resp => {
                        nextStep && swal2.insertQueueStep(nextStep);
                        resolve();
                    }, err => {
                        swal2.showValidationError(getErrMsg(err));
                        resolve();
                    });
            });
        },
        allowOutsideClick: false,
    };
    return confirmPassword;
}

/**
 * Require permission password & otp
 */
export function require2FA(authAPI, callback?, options?) {
    const saOTP = swalOTP(authAPI);
    const saPassword = swalPassword(authAPI, saOTP);

    return swalQueue([saPassword]).then(result => {
        result.value && callback && callback(result);
    });
}

/**
 * Confirm and require 2FA
 */
export function confirmW2FA(confirm, authAPI, callback?, options?) {
    swal2(confirm).then(result => {
        if (result.value) {
            require2FA(authAPI, callback, options);
        }
    });
}


/**
 * Display options for edit OTP
 */
export function swalRadio(title, inputOptions, inputValue = null) {
    return swal2({
        title: title,
        input: 'radio',
        inputValue: inputValue,
        inputOptions: inputOptions,
        inputValidator: (value) => {
            return !value && 'Hãy chọn một tùy chọn';
        }
    });
}

/**
 * Wrapper swal input view
 */
export function swalInput(title, input, placeholder, errorText) {
    return swal2({
        title: title,
        input: input,
        inputPlaceholder: placeholder,
        showCancelButton: true,
        inputValidator: (value) => {
            return !value && errorText;
        }
    });
}

/**
 * Export order as PDF/Excel file
 */
export function swalOrderExportFile(cb?) {
    return swal2({
        title: 'Chọn kiểu tập tin để xuất',
        input: 'select',
        inputOptions: {
            'excel': 'Excel',
            'pdf': 'PDF'
        },
        inputPlaceholder: 'Chọn kiểu tập tin',
        showCancelButton: true,
        inputValidator: (value) => {
            return new Promise((resolve) => {
                if (value) {
                    resolve()
                } else {
                    resolve('Hãy chọn kiểu tập tin');
                }
            })
        }
    }).then(result => {
        if (result.value) {
            cb && cb(result.value);
        }
    });
}

/**
 * confirm before cancel order
 */
export function swalCancelOrder(info?) {
    return swal2({
        title: 'Hủy đơn hàng',
        type: 'question',
        text: `${info}`,
        input: 'text',
        inputPlaceholder: 'Lý do hủy đơn hàng?',
        inputValidator: (value) => {
            return !value && 'Vui lòng nhập lý do hủy đơn hàng!';
        },
        showCancelButton: true,
        focusCancel: true,
    });
}

/**
 * payment
 */
export function swalSuccessPayment() {
    return swal2({
        // title: 'Thanh toán',
        // type: 'question',
        width: 520,
        padding: 120,
        background: 'url(/assets/images/ngan_luong.png)',
    });
}

export function swalShowLoading(title = '', text = '') {
    return swal2({
        title: title,
        text: text,
        allowOutsideClick: false,
        onBeforeOpen: () => swal2.showLoading(),
    });
}

export function swalHideLoading() {
    return swal2.hideLoading();
}

export function swalClose() {
    return swal2.close();
}

export function swalCurrentPassword(authAPI) {
    return swal2({
        title: _('Nhập mật khẩu hiện tại'),
        input: 'password',
        showCancelButton: true,
        showLoaderOnConfirm: true,
        preConfirm: (password) => {
            if (password === '') {
                return swal2.showValidationError(_('Hãy nhập mật khẩu hiện tại'));
            }
            return new Promise((resolve) => {
                authAPI.postValidatePassword({password}).subscribe(
                    resp => {
                        if (resp.data.valid) {
                            resolve();
                        } else {
                            swal2.showValidationError('Mật khẩu hiện tại không đúng');
                            resolve();
                        }
                    }, err => {
                        swal2.showValidationError('Mật khẩu hiện tại không đúng');
                        resolve();
                    });
            });
        },
        allowOutsideClick: false,
    });
}

export function swalConfirmDelete(title, text, valueValidate) {
    return swal2({
        title: title,
        text: text,
        input: 'text',
        showCancelButton: true,
        showLoaderOnConfirm: true,
        preConfirm: (inputText) => {
            if (inputText === '' || inputText !== valueValidate) {
                return swal2.showValidationError(_('Chuỗi nhập vào không đúng'));
            }
            return new Promise((resolve) => {
                resolve();
            });
        },
        allowOutsideClick: false,
    });
}

export function swalInputUniqueName(title, input, placeholder, blacklist, errorText) {
    return swal2({
        title: title,
        input: input,
        inputPlaceholder: placeholder,
        showCancelButton: true,
        inputValidator: (value) => {
            return !value && blacklist.find(x => x == value) && errorText;
        }
    });
}

/**
 * select options
 */
export function swalSelect(title, text, options, inputValue?, placeholder?, error?) {
    return swal2({
        title: _(title),
        type: 'question',
        text: _(text),
        input: 'select',
        inputOptions: options,
        inputValue: inputValue || '',
        inputPlaceholder: _(placeholder),
        inputValidator: (value) => {
            return !value && _(error);
        },
        showCancelButton: true,
        focusCancel: true,
        cancelButtonText: "Hủy",
    });
}


/**
 * Display confirm message
 */
export function swalShowConfirmSave(title, text, callback?) {
    return swal2({
        title: title,
        text: text,
        type: 'question',
        showCancelButton: true,
        confirmButtonText: "Close don't save",
        cancelButtonText: "Hủy",
        focusCancel: true,
    }).then(result => {
        if (result.value) {
            callback();
        }
    });
}

/**
 * Display custom info message
 */
export function swalShowCustomInfo(title, text, customSettings, callback?) {
    let defaultSettings = {
        title: title,
        html: text,
        type: 'info',
    };
    return swal2({...defaultSettings, ...customSettings}).then(result => {
        if (result.value) {
            callback();
        }
    });
}

/**
 * Display confirm message
 */
export function swalShowConfirmContinues(title, text, type?, callback?) {
  return swal2({
    title: title,
    text: text,
    type:  type || 'success',
    showCancelButton: true,
    confirmButtonText: "Continue",
    cancelButtonText: "Cancel"
    }).then(result => {
      if (result.value) {
        callback();
      }
    });
}

/**
 * Display confirm message
 */
export function swalShowConfirmEnableContinues(title, text, type?, callback?) {
  return swal2({
    title: title,
    text: text,
    type:  type || 'success',
    showCancelButton: true,
    confirmButtonText: "Continue",
    cancelButtonText: "Cancel"
    }).then(result => {
        callback(result);
    });
}
