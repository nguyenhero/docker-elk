const MSG_EN = {
  'msg1': 'Sai tên người dùng hoặc mật khẩu',
  'msg2': 'Wrong OTP',
  'msg3': 'User not exists',
  'msg4': 'User has been assigned token',
  'msg5': 'Can\'t generate new OTP code',
  'msg6': 'Can\'t get token in cookie or HTTP header',
  'msg7': 'Authentication failure, error during decoding token',
  'msg8': 'Authentication failure, token has expired',
  'msg9': 'Wrong password',
  'Forbidden.': 'You do not have access',
  'msg11': 'Account is not exists',
  'msg12': 'Whitelist is not exist',
  'msg13': 'Phone number is already exists',
  'msg14': 'Whitelist is already exists',
  'msg15': 'User is already exist'
};

const MSG_VI = {
  'msg1': 'Sai tên người dùng hoặc mật khẩu',
  'msg2': 'OTP không hợp lệ',
  'msg3': 'Người dùng không tồn tại',
  'msg4': 'Người dùng đã được gán mã OTP',
  'msg5': 'Không thể tạo mã OTP mới',
  'msg6': 'Không lấy được mã token trong cookie hoặc HTTP header',
  'msg7': 'Xác thực thất bại, lỗi trong quá trình giải mã token',
  'msg8': 'Xác thực thất bại, token đã hết hạn',
  'msg9': 'Mật khẩu không hợp lệ',
  'Forbidden.': 'Bạn không có quyền truy cập',
  'msg11': 'Tài khoản không tồn tại',
  'msg12': 'Whitelist không tồn tại',
  'msg13': 'Số điện thoại đã tồn tại',
  'msg14': 'Whitelist đã tồn tại',
  'msg15': 'Người dùng đã tồn tại',
  'Validation error, re-check your data.': 'Xác thực lỗi, kiểm tra lại dữ liệu của bạn'
};

const MSG = {
  'en': MSG_EN,
  'vi': MSG_VI
};


/**
 * Get error message from error code response
 */
export function getMsg(code) {
  const lang = 'vi';
  return MSG[lang][code];
}


/**
 * Get error for 422 error code
 */
function getError422(err, trans?: any) {
  if (err.status != 422) return 'Unexpected error';
  let messages = err && err.error && (err.error.message || err.error.messages);
  if (typeof messages == 'string') return messages;
  if (trans) {
    // console.log('msg', messages);
    return Object.keys(messages).map(k => trans.instant('Field') + ' ' + trans.instant(k) + ': ' + trans.instant(messages[k][0])).join(' ');
  }
  return Object.keys(messages).map(k => 'Field' + ' ' + k + ': ' + messages[k][0]).join(' ');
}


/**
 * Get error message from error code response
 */
export function getErrMsg(err, trans?: any) {
  const lang = 'vi';
  if (err.status == 422) {
    return getError422(err, trans);
  }
  // avoid show error like Http failure response for <url>
  let msg = (err && err.error && err.error.message) || "";
  msg = (err && err.error && err.error.error && err.error.error.message) || msg;
  if(msg){
    msg = msg.message || msg;
  }
  if (msg === 'Error') { /* TODO: remove this */
    msg = err && err.data;
  }
  return MSG[lang][msg] || msg;
}

/**
 * Get api source from response
 */
export function getApiSourceError(err){
  let s = (err && err.error && err.error.api_source) || "";
  s = (err && err.json && err.json() && err.json().api_source) || s;
  return s;
}
