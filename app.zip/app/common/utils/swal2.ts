import swal from 'sweetalert2';

/**
 * Translate text with params
 *
 * @param key
 * @param params
 * @returns string
 */
export function translate(key, params?) {
    const t = window['SWAL2_TRANSLATOR'];
    return t ? t.instant(key, params) : key;
}

function swal2(settings) {
    if (settings['confirmButtonText'] === null) {
        settings['confirmButtonText'] = 'OK';
    }
    if (settings['cancelButtonText'] === null) {
        settings['cancelButtonText'] = 'Hủy';
    }

    if (settings['inputValidator']) {
        let fn = settings['inputValidator'];
        settings['inputValidator'] = (value) => {
            return !value && translate(fn(value));
        };
    }

    let keys = ['title', 'text', 'inputPlaceholder', 'confirmButtonText', 'cancelButtonText'];
    for (let k of keys) {
        let v = settings[k];
        if (v) {
            let params;
            if (v instanceof Array) {
                params = v[1];
                v = v[0];
            }
            settings[k] = translate(v, params);
        }
    }

    swal.close();  // close any opening swal before open new
    return swal(settings);
}

namespace swal2 {
    export function showValidationError(e) {
        e = translate(e);
        return swal.showValidationError(e);
    }

    export function insertQueueStep(step, index?) {
        return swal.insertQueueStep(step, index)
    }

    export function queue(steps) {
        return swal.queue(steps);
    }

    export function showLoading() {
        return swal.showLoading();
    }

    export function hideLoading() {
        return swal.hideLoading();
    }

    export function close() {
        return swal.close();
    }
}

export default swal2;
