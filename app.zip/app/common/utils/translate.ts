import {RECAPCHA_KEY} from '@customer/config';

const LANG_VI = {
  'unprocessed-order': 'Chờ duyệt',
  'accept-order': 'Đã duyệt',
  'cancel-order': 'Từ chối',
  'paid': 'Đã thanh toán',
  'notpaid': 'Chưa thanh toán',
  'system-admin': 'Quản trị hệ thống',
  'expert-support': 'Chuyên gia hỗ trợ',
  'distributor-admin': 'Quản trị viên phân phối',
  'sale': 'Sale',
  'technical-support': 'Hỗ trợ kĩ thuật',
  'finance': 'Quản lý tài chính',
  'customer-care': 'Chăm sóc khách hàng',
  'price-admin': 'Quản trị giá',
  'active': 'Kích hoạt',
  'deactive': 'Vô hiệu',
  'low': 'Thấp',
  'normal': 'Bình thường',
  'high': 'Cao',
  'urgent': 'Khẩn cấp',
  'pending': 'Chưa tiếp nhận',
  'processing': 'Đang xử lý',
  'done': 'Đã xử lý',
  //delete soon
  'pp1': 'Nhà phân phối 1',
  'pp2': 'Nhà phân phối 1',
  'pp3': 'Nhà phân phối 1',
  'waf': 'WAF',
  'ddosv4': 'AntiDDoS Layer 4',
  'ddosv7': 'AntiDDoS Layer 7',
  'email': 'Email Security Gate',
  'package1': 'Little Packages',
  'package2': 'Basic Packages',
  'package3': 'Advanced Packages',
};

const LANG = {
  'vi': LANG_VI
};

export function translate(text, lang = 'vi') {
  return LANG[lang][text] || text;
}

/* no real translation here. Just a marker to extract */
export function _(key) {
  return key;
}

export function changeLangLHC(lang) {
  if (lang == 'en') {
    lang = 'eng';
  } else {
    lang = 'vnm';
  }
  let iframe = document.getElementById('lhc_iframe');
  if (iframe != null) {
    let iWindow = (<HTMLIFrameElement>iframe).contentWindow;
    let data = {
      from: 'cp_admin_sync_language',
      lang: lang,
      reload: false,
    };
    iWindow.postMessage(data, '*');
  }
  // Change lhc header title language
  let lhc_header_title = document.getElementById('lhc-header-title');
  let lhc_min_ele = document.getElementById('lhc_min');
  let lhc_close_ele = document.getElementById('lhc_close');
  if (lhc_header_title != null) {
    if (lang == 'vnm') {
      lhc_header_title.innerHTML = 'Xin chào! 😀 Rất vui lòng được giúp đỡ bạn! Nếu có câu hỏi nào hãy cho chúng tôi biết.';
      lhc_close_ele.title = "Đóng";
      lhc_min_ele.title = "Thu nhỏ/Khôi phục";
    } else if (lang == 'eng') {
      lhc_header_title.innerHTML = 'Hi there! 😀 Have a look around! Let us know if you have any questions.';
      lhc_close_ele.title = "Close";
      lhc_min_ele.title = "Minimize/Restore";
    }
  }

  // change recaptcha language
  changeLangReCaptcha(lang)
}

export function changeLangReCaptcha(lang) {
  let interval = setInterval(() => {
    let iframe_re = document.getElementsByTagName('iframe');
    if (iframe_re != undefined && iframe_re != null && iframe_re.length > 0) {
      for (var i in iframe_re) {
        var ifr = iframe_re[i];
        if (ifr.src != undefined && ifr.src.includes("recaptcha") && ifr.src.includes("hl=")) {
          if ((lang == 'vnm' || lang == 'vi') && ifr.src.includes("hl=en")) {
            ifr.src = ifr.src.replace('hl=en', "hl=vi");
          } else if ((lang == 'eng' || lang == 'en') && ifr.src.includes("hl=vi")) {
            ifr.src = ifr.src.replace('hl=vi', "hl=en");
          }
          break;
        }
      }
      clearInterval(interval);
    }
  }, 20)
}