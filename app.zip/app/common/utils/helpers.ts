import localeVi from "@angular/common/locales/vi";
import {registerLocaleData} from "@angular/common";
import * as moment from "moment";


function isValidDate(d: any) {
    let d1 = d;
    let d2 = d;
    return d1 instanceof Date && !isNaN(d2);
}


export function isValidDateForSearch(d: any) {
    if (!d) return true;
    let d1 = d;
    let d2 = d;
    return d1 instanceof Date && !isNaN(d2);
}

export function isValidDateRgx(dateString) {
    // First check for the pattern
    if (!/^(\d{2}|\d{1})\/(\d{2}|\d{1})\/\d{4}$/.test(dateString))
        return false;
    // Parse the date parts to integers
    let parts = dateString.split('/');
    let day = parseInt(parts[1], 10);
    let month = parseInt(parts[0], 10);
    let year = parseInt(parts[2], 10);
    // Check the ranges of month and year
    if (year < 1000 || year > 3000 || month == 0 || month > 12)
        return false;
    let monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    // Adjust for leap years
    if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
        monthLength[1] = 29;
    // Check the range of the day
    return day > 0 && day <= monthLength[month - 1];
}

export function format(v, type?, format?) {
    if (!v) return v;
    switch (type) {
        case 'date':
            if (!isValidDate(v)) return v;
            return v.getFullYear() + '-' + (v.getMonth() + 1) + '-' + v.getDate();
    }
    return v;
}

export function utc2local(date) {
  if (!date) return '';
  return moment.utc(date).local().format('YYYY-MM-DD HH:mm:ss');
}

// export function registerLocaleVi() {
//     const localeVi_ = localeVi.slice();
//     localeVi_[14][2] = '#,##0.00 ¤';
//     registerLocaleData(localeVi_, 'vi');
// }

/**
 * Get current distributor id for search
 * Id of system will be replaced by undefined to search all
 */
export function makeDistIdParam(dist: any) {
    return dist._id;
}

import {swalShow} from './swal';


export function notifySuccess(title, message, extras: any = {}) {
    const options: any = {
        title: title,
        text: message,
        // toast: true,
        // position: extras.position || 'top',
        timer: extras.timer || 3000,
        showConfirmButton: false,
        type: extras.type || 'success',
        // background: extras.background || 'aliceblue',
    };
    swalShow(options);
}

export function notifyError(title, message, extras: any = {}) {
    extras.type = 'error';
    notifySuccess(title, message, extras);
}

export function loadVisJsScript(src, async = true) {
    if (window['__external_js_' + src]) {
        return;
    }
    window['__external_js_' + src] = true;

    let script = document.createElement('script');
    script.src = src;
    script.type = 'text/javascript';
    script.async = async;
    script.charset = 'utf-8';
    document.getElementsByTagName('head')[0].appendChild(script);
}


export function loadVisCss(src) {
    if (window['__external_css_' + src]) {
        return;
    }
    window['__external_css_' + src] = true;

    let el = document.createElement('link');
    el.href = src;
    el.rel = 'stylesheet';
    document.getElementsByTagName('head')[0].appendChild(el);
}

/**
 * Cast value as array
 */
export function castArray(val) {
    if (val == null) return val;
    if (val instanceof Array) return val;
    return [val];
}
