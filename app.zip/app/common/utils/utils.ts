export function deepCopy(obj: any){
    if(!obj) return obj;
    return (JSON.parse(JSON.stringify(obj)));
}

export function formatBigNumber(value) {
    if (value >= 1000000000)
        return (Math.round(value / 1000000000)) + " G";
    else if (value >= 1000000)
        return (Math.round(value / 1000000)) + " M";
    else if (value >= 1000)
        return "" + (Math.round(value / 1000)) + " k";
    else
        return value + " ";
}

export function formatBigNumber2(value) {
    if (value >= 1000000000)
        return (value / 1000000000.).toFixed(2) + " G";
    else if (value >= 1000000)
        return (value / 1000000).toFixed(2) + " M";
    else if (value >= 1000)
        return "" + (value / 1000).toFixed(2) + " k";
    else
        return value + " ";
}