import { formatBigNumber, formatBigNumber2 } from "@common/utils/utils";

const critical_label = "critical";
const high_label = "high";
const medium_label = "medium";
const low_label = "low";

const min_critical = 5000000000;
const min_high = 1000000000;
const min_medium = 400000000;

export function formatAlertsL4(alerts) {
    // for(var alert of alerts){
    //   if(alert.inboundBps != undefined && alert.log_category == 'ddosl4'){
    //     alert['severity'] = get_ddosl4_severity(alert.inboundBps);
    //   }
    // }

    for (let alert of alerts) {
        alert.attack_type = alert.attack_type.toUpperCase();
        alert.inboundBps = alert.inbound_bps ? formatBigNumber2(alert.inbound_bps) :
            (alert.inboundBps ? formatBigNumber2(alert.inboundBps) : undefined);
        alert.inboundPps = alert.inbound_pps ? formatBigNumber2(alert.inbound_pps) :
            (alert.inboundPps ? formatBigNumber2(alert.inboundPps) : undefined);
    }
    return alerts;
}

function get_ddosl4_severity(inbound_bps) {
    if (inbound_bps >= min_critical) {
        return critical_label;
    } else if (inbound_bps >= min_high) {
        return high_label;
    } else if (inbound_bps >= min_medium) {
        return medium_label;
    } else {
        return low_label;
    }
}