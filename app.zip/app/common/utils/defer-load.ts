export function initDeferList(arr=[], no){
    for(var i = 0; i < no; i++){
        arr.push(false);
    }
}