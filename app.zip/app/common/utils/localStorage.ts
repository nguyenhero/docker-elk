const IGNORE_LOGIN = 'IGNORE_LOGIN';

export function setIgnoreLogin() {
  return localStorage.setItem(IGNORE_LOGIN, 'true');
}

export function isIgnoreLogin() {
  return localStorage.getItem(IGNORE_LOGIN);
}

export function unsetIgnoreLogin() {
  return localStorage.removeItem(IGNORE_LOGIN);
}

export function clearLocalStorage() {
  return localStorage.clear();
}
