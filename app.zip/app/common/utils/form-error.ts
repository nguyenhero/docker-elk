export class FormError {
  [key: string]: any

  invalid():boolean {
    return Object.keys(this).find(v => this[v]) !== undefined;
  }
}
