export * from './dnsMisc.service';
import { DnsMiscService } from './dnsMisc.service';
export const APIS = [DnsMiscService];
