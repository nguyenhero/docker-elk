export * from './auth.service';
import { AuthService } from './auth.service';
export * from './chatToken.service';
import { ChatTokenService } from './chatToken.service';
export * from './csUnit.service';
import { CsUnitService } from './csUnit.service';
export * from './customer.service';
import { CustomerService } from './customer.service';
export * from './customerLog.service';
import { CustomerLogService } from './customerLog.service';
export * from './customerNotice.service';
import { CustomerNoticeService } from './customerNotice.service';
export * from './customerService.service';
import { CustomerServiceService } from './customerService.service';
export * from './distributor.service';
import { DistributorService } from './distributor.service';
export * from './order.service';
import { OrderService } from './order.service';
export * from './payment.service';
import { PaymentService } from './payment.service';
export * from './perm.service';
import { PermService } from './perm.service';
export * from './price.service';
import { PriceService } from './price.service';
export * from './profile.service';
import { ProfileService } from './profile.service';
export * from './promotion.service';
import { PromotionService } from './promotion.service';
export * from './public.service';
import { PublicService } from './public.service';
export * from './service.service';
import { ServiceService } from './service.service';
export * from './ticket.service';
import { TicketService } from './ticket.service';
export * from './shopCart.service';
import { ShopCartService } from './shopCart.service';
export * from './ssl.service';
import { SslService } from './ssl.service';
export * from './domain.service';
import { DomainService } from './domain.service';
export * from './traffic.service';
import { TrafficService } from './traffic.service';
export const APIS = [
    SslService, DomainService,
    AuthService, ChatTokenService, CsUnitService, CustomerService, CustomerLogService, CustomerNoticeService,
    CustomerServiceService, DistributorService, OrderService, PaymentService, PermService, PriceService,
    ProfileService, PromotionService, PublicService, ServiceService, TicketService, ShopCartService, TrafficService,
];
