import { NgModule, ModuleWithProviders, SkipSelf, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Configuration } from './configuration';

import { AuthService } from './api/auth.service';
import { ChatTokenService } from './api/chatToken.service';
import { CsUnitService } from './api/csUnit.service';
import { CustomerService } from './api/customer.service';
import { CustomerLogService } from './api/customerLog.service';
import { CustomerNoticeService } from './api/customerNotice.service';
import { CustomerServiceService } from './api/customerService.service';
import { DistributorService } from './api/distributor.service';
import { OrderService } from './api/order.service';
import { PaymentService } from './api/payment.service';
import { PermService } from './api/perm.service';
import { PriceService } from './api/price.service';
import { ProfileService } from './api/profile.service';
import { PromotionService } from './api/promotion.service';
import { PublicService } from './api/public.service';
import { ServiceService } from './api/service.service';
import { TicketService } from './api/ticket.service';
import { SslService } from './api/ssl.service';
import { DomainService } from './api/domain.service';
import {ShopCartService} from "@common/swagger-services/api/shopCart.service";
import {MyHttpInterceptor} from "@customer/global.interceptor";
import { NetworkService } from './api/network.service';
import { CustomPageService } from './api/customPage.service';
import { TrafficService } from './api/traffic.service';

@NgModule({
  imports:      [ CommonModule, HttpClientModule ],
  declarations: [],
  exports:      [],
  providers: [
    AuthService,
    ChatTokenService,
    CsUnitService,
    CustomerService,
    CustomerLogService,
    CustomerNoticeService,
    CustomerServiceService,
    DistributorService,
    OrderService,
    PaymentService,
    PermService,
    PriceService,
    ProfileService,
    PromotionService,
    PublicService,
    ServiceService,
    TicketService,
    SslService,
    DomainService,
    ShopCartService,
    NetworkService,
    CustomPageService,
    TrafficService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MyHttpInterceptor,
      multi: true
    },
  ]
})
export class ApiModule {
    public static forRoot(configurationFactory: () => Configuration): ModuleWithProviders {
        return {
            ngModule: ApiModule,
            providers: [ { provide: Configuration, useFactory: configurationFactory } ]
        }
    }

    constructor( @Optional() @SkipSelf() parentModule: ApiModule) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import your base AppModule only.');
        }
    }
}
