import {Component, OnInit, Input, Output, EventEmitter, ElementRef} from '@angular/core';
import {DeviceDetectorService} from "ngx-device-detector";

class Tab {
    constructor(public title: string) {
    }
}

@Component({
    selector: 'app-horizontal-tab',
    templateUrl: './horizontal-tab.component.html',
    styleUrls: ['./horizontal-tab.component.scss']
})
export class HorizontalTabComponent implements OnInit {
    @Input() theme = 'blue';
    @Input() tabs: any[];
    @Input() selectedIndex;
    @Output() selectedIndexChange = new EventEmitter();
    @Output() selectChange = new EventEmitter();
    isMobile: boolean;

    @Input() canSelect = true;
    @Input() confirmMsg;

    constructor(private deviceDetector: DeviceDetectorService, private elRef: ElementRef) {
        this.isMobile = deviceDetector.isMobile();
    }

    ngOnInit() {
    }

    select(idx) {
        if (!this.canSelect && (!this.confirmMsg || !confirm(this.confirmMsg))) {
            return;
        }
        this.selectedIndex = idx;
        this.selectedIndexChange && this.selectedIndexChange.emit(idx);

        let curTab = this.tabs[idx];
        this.selectChange && this.selectChange.emit(curTab);
        const activeElm = this.elRef.nativeElement.querySelector('.mat-tab-label-active');
        if (activeElm) {
            activeElm.scrollIntoView(true);
            const parentElm = this.elRef.nativeElement.querySelector('.mat-tab-label-container');
            parentElm.scrollLeft += activeElm.clientWidth;
        }
    }

}
