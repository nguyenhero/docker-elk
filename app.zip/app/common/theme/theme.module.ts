import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FlexLayoutModule} from '@angular/flex-layout';
import {TranslateModule} from '@ngx-translate/core';

import {HorizontalTabComponent} from './horizontal-tab/horizontal-tab.component';
import {MatTabsModule} from "@angular/material";

@NgModule({
    imports: [
        CommonModule,
        FlexLayoutModule,
        TranslateModule,
        MatTabsModule
    ],
    declarations: [
        HorizontalTabComponent
    ],
    exports: [
        HorizontalTabComponent
    ],
    providers: []
})
export class ThemeModule {
}
