import {innerWidthLaptop, innerWidthTablet, innerWidthMobile} from "@common/utils/mobile";

export function getFixedChartCategoryDateFormat(format?) {
    if (format == 'day') {
        return [
            { "period": "fff", "format": "DD/MM" },
            { "period": "ss", "format": "DD/MM" },
            { "period": "mm", "format": "DD/MM" },
            { "period": "hh", "format": "DD/MM" },
            { "period": "DD", "format": "DD/MM" },
            { "period": "WW", "format": "DD/MM" },
            { "period": "MM", "format": "MM" },
            { "period": "YYYY", "format": "YYYY" }
        ];
    }

    return [
        { "period": "fff", "format": "JJ:NN:SS" },
        { "period": "ss", "format": "JJ:NN:SS" },
        { "period": "mm", "format": "JJ:NN" },
        { "period": "hh", "format": "JJ:NN" },
        { "period": "DD", "format": "DD/MM" },
        { "period": "WW", "format": "DD/MM" },
        { "period": "MM", "format": "DD/MM" },
        { "period": "YYYY", "format": "YYYY" }
    ];
}

export function getChartDateFormat(format) {
    if (format == 'day') {
        return 'DD/MM/YYYY';
    }
    if (format === 'minute') {
        return 'YYYY/MM/DD JJ:NN';
    }
}

export function translateZoomTextConfig(chartConfigJson, translateService) {
    chartConfigJson.addClassNames = true;
    let listeners = chartConfigJson.listeners || [];
    const event = 'zoomed';
    listeners = listeners.filter(it => it.event != event);

    function handleZoom() {
        let elem = document.getElementsByClassName('amcharts-zoom-out-label');
        let text = translateService.instant('Zoom out');
        if (elem) {
            for (let i = 0; i < elem.length; i++) {
                let e = elem[i];
                e.firstElementChild.innerHTML = text;
            }
        }
    }

    listeners.push({
        "event": "zoomed",
        "method": handleZoom
    });

    chartConfigJson.listeners = listeners;

    return chartConfigJson;
}

/**
 * Get minHorizontalGap by width for each device
 */
export function getMinHorizontalGap() {
    if (window.innerWidth <= innerWidthMobile)
        return 25;
    else if (window.innerWidth <= innerWidthLaptop)
        return 35;
    return 55;
}
