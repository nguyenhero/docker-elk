import { Router, ActivatedRoute } from '@angular/router';
import {
  ChangeDetectorRef,
  Component,
  Injector,
  OnInit,
  ViewChild,
  ElementRef,
} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs/Subscription';
import { QueryParams } from '../modules/queryparams';
import { Page } from '../page';
import { ClientPermService } from '../services';
import { _ } from '@common/utils';
import { Field } from "@common/models";

export interface ITableData {
  rowHeight?: number;
  page?: Page;
  setPage?: any;
  columns?: Field[];
  rows?: any[];
  count?: number;
  externalPaging?: boolean;
  externalSorting?: boolean;
  selectAllRowsOnPage?: any;
  rowIdentity?: any;
  showIndexColumn?: boolean;
  totalMessageItem?: any;
  sorts?: any[];
  onSort?: any;
  select?: {
    type: any;
    onSelect: any;
  };
  selected?: any[];
  pageLimit?: number;
  sortsData?: any;
  total?: number;
}

export class BaseAutoUnsubscribe {
  sub01: Subscription;
  sub02: Subscription;
  sub03: Subscription;
  sub04: Subscription;
  sub05: Subscription;
  sub06: Subscription;
  sub07: Subscription;
  sub08: Subscription;
  sub09: Subscription;
  sub10: Subscription;
  sub11: Subscription;
  sub12: Subscription;
  sub13: Subscription;
  sub14: Subscription;
  sub15: Subscription;

  ngOnDestroy() {
  }
}


export class BaseModelComponent extends BaseAutoUnsubscribe {

}

@Component({
  template: ''
})
export class BaseTableComponent extends BaseAutoUnsubscribe implements OnInit {
  FIELDS = [];
  tableData: ITableData;
  cd;

  constructor(public injector: Injector) {
    super();
    this.loadTableData();
    this.cd = this.injector.get(ChangeDetectorRef);
  }
  ngOnInit() {
    this.loadTableData();
  }
  setPage(e) {
  }
  onSort(e) {
  }
  detectChanges() {
    try {
      this.cd.detectChanges();
    } catch (e) {
    }
  }
  updateTableData(resp) {
    this.tableData.rows = resp.data.rows;
    this.tableData.count = resp.count;
    this.tableData.total = resp.total;
    this.tableData = { ...this.tableData };
    this.detectChanges();
  }

  /**
   * Create table data
   */
  loadTableData() {
    this.tableData = {
      page: new Page(),
      setPage: (e) => this.setPage(e),
      columns: this.FIELDS,
      rows: [],
      count: 0,
      total: 0,
      externalPaging: true,
      externalSorting: true,
      sorts: [],
      onSort: (e) => this.onSort(e),
      select: {
        type: undefined,
        onSelect: function (event) {
        },
      },
      selected: []
    };
  }
}


@Component({
  template: ''
})
export class BaseComponent extends BaseAutoUnsubscribe implements OnInit {
  FIELDS = [];
  model: any = {};
  page = new Page();

  DEFAULT_SEARCH = {};

  tableData: ITableData = {
    page: this.page,
    setPage: (e) => this.setPage(e),
    columns: this.FIELDS,
    rows: [],
    count: 0,
    total: 0,
    externalPaging: true,
    externalSorting: true,
    selectAllRowsOnPage: true,
    sorts: [],
    onSort: (e) => this.onSort(e),
    select: {
      type: undefined,
      onSelect: function (event) {
      },
      // selected: undefined
    },
    selected: []
  };

  statService = null;
  infoData = [];

  @ViewChild('cpListing') cpListingRef;
  curDetailModel: any = {};
  curHistoryData = [];
  curDetailFields = [];

  searchData: any = {};
  oldReloadId; // reload when change dist

  private lastNumRowScroll: any = null;
  isLoading: boolean;

  subscription = new Subscription();

  basesub01: Subscription;
  basesub02: Subscription;
  basesub03: Subscription;
  basesub04: Subscription;

  cd: ChangeDetectorRef;

  constructor(public router: Router,
    public activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    public permService: ClientPermService,
    public injector: Injector,
    public el?: ElementRef) {
    super();
    this.cd = this.injector.get(ChangeDetectorRef);
  }

  ngOnInit() {
    this.page.pageNumber = 0;
    this.page.size = 10;
    this.tableData.page = this.page;
    this.tableData.columns = this.FIELDS;

    this.searchData = {
      model: this.model,
      controls: this.FIELDS,
      onSearch: this.search.bind(this),
    };

    if (this.canAddNew()) {
      this.searchData.onNew = this.onNewItem.bind(this);
    }

    this.basesub01 = this.activatedRoute.queryParams.subscribe(params => {
      this.tableData.sorts = []; // for datatable reload sorts
      const queryParams = new QueryParams(this.model, this.page, this.tableData.sorts);
      queryParams.parse(params, this.FIELDS);

      // update default search fields
      for (let k in this.DEFAULT_SEARCH) {
        if (this.model[ k ] === null || this.model[ k ] === undefined) {
          this.model[ k ] = this.DEFAULT_SEARCH[ k ];
          // this func was called everytime click Search
          delete this.DEFAULT_SEARCH[ k ];
        }
      }

      if (params._reload && this.oldReloadId != params._reload) {
        this.reload();
      } else {
        this._search();
      }
    });

    this.getStatistics();

    this.actionsField = this.getActionsField();
    this.onOpenedDetail = this.onOpenedDetail.bind(this);
    this.onClosedDetail = this.onClosedDetail.bind(this);
  }

  ngOnDestroy() {
  }

  /**
   * Add params to url
   */
  search(jumpToFirstPage = true) {
    console.log('originSearch');
    if (jumpToFirstPage) {
      this.page.pageNumber = 0;
    }
    const queryParams = new QueryParams(this.model, this.page, this.tableData.sorts).generate();
    this.router.navigate([ this.router.url.split('?')[ 0 ] ],
      { queryParams: queryParams });
  }

  /**
   * Requesting to server when datatable page was changed
   */
  setPage(pageInfo) {
    this.page.pageNumber = pageInfo.offset;
    this.search(false);
  }

  /**
   * Paging with infinite scrolling
   */
  async onScroll(offsetY, numRows = 0) {
    if (this.isLoading || this.lastNumRowScroll === numRows) {
      return;
    }
    const headerHeight = 40;
    const footerHeight = 40;
    const rowHeight = 40
    // total height of all rows in the viewport
    const viewHeight = this.el.nativeElement.getBoundingClientRect().height - headerHeight - footerHeight;
    // check if we scrolled to the end of the viewport
    if (offsetY + viewHeight >= numRows * rowHeight) {
      this.lastNumRowScroll = numRows;
      this.page.pageNumber = numRows / this.page.size;
      this.isLoading = true;
      await this.search(false);
      this.isLoading = false;
    }
  }

  _search() {
    console.warn('NotImplementError _search method');
  }

  openDialog(component, model = {}) {
    const dialogRef = this.dialog.open(component, {
      autoFocus: false,
      width: '80%',
      maxWidth: '90%',
      height: '80%',
      maxHeight: '90%',
      data: { model: model }
    });
    this.basesub02 = dialogRef.afterClosed().subscribe((result: any) => {
      if (result && result.reload) {
        this.reload();
      }
    });
  }

  openDialog2(component, model = {}, cb?) {
    const dialogRef = this.dialog.open(component, {
      autoFocus: false,
      width: '100%',
      maxWidth: '100%',
      height: '100%',
      maxHeight: '100%',
      data: model
    });
    this.basesub02 = dialogRef.afterClosed().subscribe((result: any) => {
      result && result.reload && cb(result);
    });
  }

  openDialogUrl(type, model) {
    const url = encodeURIComponent(this.router.url);
    const params = Object.assign({ type, url }, model);
    this.router.navigate([ '/c/popup' ], { queryParams: params });
  }

  onSort(e) {
    // console.warn('NotImplementError');
    this.tableData.sorts = e.sorts;
    this.search();
  }

  viewDetail(model: any, title) {
    // console.log("hoaln7");
    this.curDetailModel = model;
    this.cpListingRef.showDetail(title);
    this.curHistoryData = (model.histories || []).slice().reverse();
    this.detectChanges();
  }

  /**
   * Load staticstic
   */
  getStatistics() {
    // let s = this.statService;
    // if (s && s.getStatistics) {
    //   this.basesub04 = s.getStatistics(this.makeDistIdParam()).subscribe((resp: any) => {
    //     this.infoData = resp.data.statistics || [];
    //   });
    // }
  }

  /**
   * Reload statistics and result search
   */
  reload() {
    this.getStatistics();
    this._search();
  }

  get current_user(): any {
    return this.permService.current_user;
  }

  get current_dist(): any {
    return this.permService.current_dist;
  }

  get distributors(): any {
    return this.permService.distributors;
  }

  /**
   * Get current distributor id for search
   * Id of system will be replaced by undefined to search all
   */
  makeDistIdParam() {
    let dist = this.current_dist;
    return dist._id;
  }

  onNewItem() {
    console.warn('NotImplementError: onNewItem');
  }

  canAddNew() {
    return false;
  }

  /**
   * Detect changes
   */
  detectChanges() {
    if (!this.cd[ 'destroyed' ]) {
      this.cd.detectChanges();
    }
    this.resize();
  }

  /**
   * Trigger resize event
   */
  resize() {
    /* remove dispatch resize */
    window.dispatchEvent(new Event('resize'));
  }

  /**
   * Update table data and trigger changes
   */
  updateTableData(resp) {
    this.tableData.rows = resp.data.rows;
    this.tableData.count = resp.count;
    this.tableData.total = resp.total;
    this.tableData = { ...this.tableData };
    this.detectChanges();
  }

  /* --------------------------------- View Detail ---------------------------*/
  actionsField;

  getActionsField() {
    return this.FIELDS.find(f => f.label == _('Action'));
  }

  onOpenedDetail() {
    let idx = this.FIELDS.findIndex(f => f.label == _('Action'));
    this.FIELDS[ idx ] = this.actionsField && this.actionsField.filterActionViewDetail(this, _('Action'));
  }

  onClosedDetail() {
    let idx = this.FIELDS.findIndex(f => f.label == _('Action'));
    this.FIELDS[ idx ] = this.actionsField;
  }

  /**
   * Default track by *ngFor with _id atttribute
   */
  trackByFn(index, item) {
    return item._id;
  }
}