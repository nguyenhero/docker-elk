import {Component, OnDestroy} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";

@AutoUnsubscribe()
@Component({
  selector: 'app-redirect',
  template: '',
})
export class RedirectComponent implements OnDestroy {
  constructor(public activateRoute: ActivatedRoute,
              public router: Router) {
    let m = this.activateRoute.snapshot.queryParamMap;
    let url = m.get('url');
    let q = {};

    try {
      q = JSON.parse(decodeURIComponent(m.get('q'))) || {};
    } catch (e) {
      q = {};
    }

    if (url) {
      this.router.navigate([url], {queryParams: q, replaceUrl: true});
    }
  }

  ngOnDestroy() {

  }
}