import {Router, ActivatedRoute} from '@angular/router';
import {
  ChangeDetectorRef,
  Component,
  Injector,
  OnInit,
  ViewChild,
  Input, SimpleChanges
} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {Subscription} from 'rxjs/Subscription';
import {QueryParams} from '../modules/queryparams';
import {Page} from '../page';
import {ClientPermService} from '../services';
import {_} from '@common/utils';

import { BaseModelComponent } from './base.component';

@Component({
  template: ''
})
export class DasboardBaseComponent extends BaseModelComponent implements OnInit {
  domainId: string;

  cd: ChangeDetectorRef;

  sub: Subscription;

  constructor(public router: Router,
              public activatedRoute: ActivatedRoute,
              public dialog: MatDialog,
              public permService: ClientPermService,
              public injector: Injector) {
    super();
    this.cd = this.injector.get(ChangeDetectorRef);
  }

  ngOnInit(){
    this.sub = this.activatedRoute.queryParams.subscribe(params => {
      if(params.cc == '__all_domain') return;
      // // console.log(this.domainId);
      if(this.domainId != params.cc){
        this.domainId = params.cc;   
        this.onChangeRoute();
      }
    });
  }

  onChangeRoute(){
    if(this.domainId){
      this.reload();
    }
  }

  reload(){
    // console.log('reload');
  }
}

@Component({
  template: ''
})
export class DasboardTabPanelComponent extends DasboardBaseComponent implements OnInit {
  @Input() viewing: boolean = false;
  isInit: boolean = true;

  ngOnChanges(change: SimpleChanges){
    if(!change.viewing){
        return;
    }
    if(this.viewing){
      if(!this.isInit){
        this.reload();
      }
      this.isInit = false;
    }
  }

  onChangeRoute(){
    if(this.viewing){
      if(!this.isInit){
        this.reload();
      }
      this.isInit = false;
    }
  }
}
