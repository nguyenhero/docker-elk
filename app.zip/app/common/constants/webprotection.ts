export const WP_WEBSITE_FRAMEWORK = [
    {value: 'wordpress', label: 'fw_wordpress'},
    {value: 'drupal', label: 'fw_drupal'},
    {value: 'joomla', label: 'fw_joomla'},
    {value: 'django', label: 'fw_django'},
    {value: 'laravel', label: 'fw_laravel'},
    {value: 'asp_dot_net_webform', label: 'fw_asp_net_webform'},
    {value: 'asp_dot_net_mvc', label: 'fw_asp_net_mvc'},
    {value: 'spring', label: 'fw_spring_framework'},
    {value: 'yii', label: 'fw_yii_framework'},
    {value: 'magento', label: 'fw_magento'},
    {value: 'zend', label: 'fw_zend'},
];