export const PLOT_AREA_BORDER_ALPHA = 0.66;

export const COLORS = {
  input: '#43B4D4',
  totalInput: '#3c64fa',
  totalOutput: '#DD8439',
  cleanedOutput: '#8F7AB8',
  warn: '#ffd139',
  blackList: '#f44242',
  whiteList: '#81C340',
  allow: '#009900',
  deny: '#203cfa',
};
