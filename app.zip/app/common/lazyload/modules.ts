import {CommonModule} from '@angular/common';
import {ErrorHandler, NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import {CustomFormsModule} from 'ng2-validation';
import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import { ThemeModule } from '../theme/theme.module';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';

import {
  MatSidenavModule,
  MatCardModule,
  MatMenuModule,
  MatCheckboxModule,
  MatIconModule,
  MatButtonModule,
  MatToolbarModule,
  MatTabsModule,
  MatListModule,
  MatSlideToggleModule,
  MatSelectModule,
  MatProgressBarModule,
  MatInputModule,
  MatDialogModule,
  MatChipsModule,
  MatProgressSpinnerModule,
  MatAutocompleteModule,
  MatGridListModule,
  MatRadioModule,
  MatTooltipModule,
  MatDatepickerModule,
  MatNativeDateModule
} from '@angular/material';
import {FlexLayoutModule} from '@angular/flex-layout';
import {ReactiveFormsModule} from '@angular/forms';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';

// fosec customer templates
import {FosecTemplateCustomerModule} from '@fosec/fosec-template-customer';
import {SharedModule} from '@customer/shared/shared.module';

import {Http, Response, HttpModule} from '@angular/http';
import {ViscTemplateModule} from '@visc/visc-template';
import {PortalCustomValidatorModule} from '../validators/custom-validator.module';

import { MyValidateModule } from '../validate/validate.module';
import {PopoverModule} from "@fosec/fosec-template-customer";

export const COMMON_MODULES = [
  CommonModule,
  SharedModule,
  PortalCustomValidatorModule,
  FormsModule,
  ReactiveFormsModule,
  CustomFormsModule,
  NgxDatatableModule,
  HttpClientModule,
  TranslateModule,
  MatSidenavModule,
  MatCardModule,
  MatMenuModule,
  MatCheckboxModule,
  MatRadioModule,
  MatIconModule,
  MatButtonModule,
  MatToolbarModule,
  MatTabsModule,
  MatListModule,
  MatSlideToggleModule,
  MatSelectModule,
  MatProgressBarModule,
  MatAutocompleteModule,
  MatGridListModule,
  FlexLayoutModule,
  MatInputModule,
  MatDialogModule,
  MatChipsModule,
  MatProgressSpinnerModule,
  MatTooltipModule,
  FosecTemplateCustomerModule,
  ViscTemplateModule,
  HttpModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MyValidateModule,
  PopoverModule,
  NgxDaterangepickerMd.forRoot(),
  ThemeModule,
];
