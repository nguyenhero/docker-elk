export const API_BASE_URL = '/api/v1';
export const API_BASE_WAF_URL = '/waf/api/v1';
export const API_BASE_DNS_URL = '/dns/api/v1';
export const DDoS_l4_HOST = "";

// export const API_BASE_URL = 'http://localhost:7200/api/v1';
// export const API_BASE_WAF_URL = 'http://localhost:7200/waf/api/v1';
// export const DDoS_l4_HOST = "http://localhost:7200";

// TODO: config me in `https://www.google.com/recaptcha/admin`
export const RECAPCHA_KEY = '6LcMjmwUAAAAAOIFKF_sX1KyTHg1eufnBTIqgmc8';
export const MAX_RANGE_SUMMERIES = 3 * 30; // date diff between start date and now
export const WINDOW_RANGE_SUMMERIES = 3 * 30; // date diff between start date & end date

export const WAF_ID = "5a6f04b4da0d1e47f8d15e34";
export const DDOS_ID = "5a6f04fada0d1e47f8d15e35";
export const WEBPROTECTION_ALIAS = "wp";
export const WEB_ANALYTICS_ALIAS = "wa";
export const WAF_SERVICE_NAME = 'WAF';

export const WA_SERVICE_NAME = 'WA';

export const WEBPROTECTION_SERIVCE_NAME = 'Web Protection';

export const AntiDDOSL4_SERVICE_NAME = 'AntiDDoS Layer 4';

export const WAF_ALIAS = "waf";
export const DDOSL7_ALIAS = "ddosl7";
export const DDOSL4_ALIAS = "ddosl4";

export const DNS_SERVICE_NAME = 'DNS';
export const DNS_ALIAS = "dns";

export const SERIVCE_NAME_WEBPROTECTION = 'WebProtection';

export const MAX_CERT_KEY_SIZE = 1024 * 1024;

export const MAX_PROCESSING_ORDERS = 2;

export function getServiceNames(services) {
    let ls = [];
    for (let s of services) {
        if (s == WAF_ID)
            ls.push(WEBPROTECTION_SERIVCE_NAME);
        else if (s == DDOS_ID)
            ls.push(AntiDDOSL4_SERVICE_NAME);
    }
    return ls;
}

export const FEATURE_CWP_RULE_FRAMEWORK = "FEATURE_CWP_RULE_FRAMEWORK";
