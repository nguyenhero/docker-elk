import { Component, OnInit, Input, OnChanges, SimpleChange } from '@angular/core';
import { Http } from '@angular/http';
import { AmChartsService } from '@amcharts/amcharts3-angular';
import {TranslateService, LangChangeEvent} from '@ngx-translate/core';
import { TopChartIP } from './chart.model';

@Component({
	selector: 'app-chart-ip',
	templateUrl: './chart-ip.component.html',
	styleUrls: ['./chart-ip.component.scss']
})
export class ChartIPComponent implements OnInit, OnChanges {
	@Input() topchart: TopChartIP;
	@Input() chartHeight = 200;
	@Input() rotate = false;
	@Input() color = '#FA6900';

	model = {};
	chartData: any;
	isEmpty: number = 0;
	chartName = "";

	public chartOP: any;
	constructor(
		public amCharts: AmChartsService,
		public http: Http,
		public trans: TranslateService) {
	}

	ngOnChanges(changes: { [propTopChart: string]: SimpleChange }): void {
		this.isEmpty = 0;
		if (!this.topchart || !this.topchart.topData) {
			this.isEmpty = 0;
		} else {
			this.chartData = this.topchart.topData;
			this.chartName = this.topchart.chart_id;
			if (this.chartData.length == 0) {
				this.isEmpty = 1;
			} else {
				this.isEmpty = 2;
				setTimeout(() => {
					this.callChart();
				}, 0);
			}
		}

		this.trans.onLangChange.subscribe((event: LangChangeEvent) => {
			if(this.topchart != undefined)
				this.callChart();
		});
	}

	ngOnInit() {
		if (this.topchart) {
			this.chartData = this.topchart?this.topchart.topData:[];
			this.isEmpty = 2;
			this.callChart();
		}
	}

	callChart() {
		let cfg = {
			"type": "serial",
			"theme": "light",
			"categoryField": this.topchart.name,
			"rotate": this.rotate,
			"startDuration": 1,
			color: '#FA6900',
			fontFamily: 'SourceSansPro',
			marginTop: 0,
			marginBottom: 0,
			marginRight: 0,
			marginLeft: 0,
			"categoryAxis": {
				"labelRotation": 45,
				"position": "top",
				"axisAlpha": 0,
				"axisColor": "#fff",
        		"gridAlpha": 0,
				"gridColor": "#fff",
				'axisThickness': 0,
				"labelsEnabled": false,
				"inside": true,
				"startOnAxis": true,
				"enabled": false,
				"ignoreAxisWidth": true,
			},
			"trendLines": [],
			"graphs": [
				{
					"columnWidth": 0.5,
					"fixedColumnWidth": 5,
					"lineColor": this.color,
					"fillAlphas": 1,
					"id": "AmGraph-1",
					"lineAlpha": 0,
					"title": "Income",
					"type": "column",
                    "valueField": this.topchart.value,
                    "cornerRadiusTop": 4,
				}
			],
			"balloon": {
				"enabled": false,
			},
			"guides": [],
			"valueAxes": [
				{
					"id": "ValueAxis-1",
					"position": "top",
					"axisAlpha": 0,
					"axisColor": "transparent",
					"gridAlpha": 0,
					"gridColor": "transparent",
					"enabled": false,
					"axisThickness": 0,
					"ignoreAxisWidth": true,
					"labelFrequency": 0,
					"offset": 10,
					"labelsEnabled": false,
					"inside": true,
					"autoGridCount": false,
					"gridCount": 40,
				}
			],
			"allLabels": [],
			"titles": [],
			"dataProvider": this.chartData,
		};
		this.chartOP = this.amCharts.makeChart(this.topchart.chart_id, cfg);
	}
}
