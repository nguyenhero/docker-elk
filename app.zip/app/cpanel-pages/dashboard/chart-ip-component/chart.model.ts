export class TopChartIP {
    constructor(
      public topData: any,
      public name: string,
      public value: string,
      public field: string,
      public chart_id: string,
      public reload: boolean,
    ) { }
  }