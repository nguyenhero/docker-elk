import { compareStrLower } from '@common/models';
import { CsUnitService } from './../../common/swagger-services/api/csUnit.service';
import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ChangeDetectorRef,
    AfterViewInit
} from '@angular/core';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { WEBPROTECTION_ALIAS, DDOSL4_ALIAS } from '../../config';
import { Subscription } from 'rxjs';
import { Field, HiddenControl } from '@common/models';
import { Page } from "@common/page";
import { ITableData } from "@common/components";

interface BeforeOnDestroy {
    ngxBeforeOnDestroy();
  }
  
  type NgxInstance = BeforeOnDestroy & Object;
  type Descriptor = TypedPropertyDescriptor<Function>;
  type Key = string | symbol;
  
  function BeforeOnDestroy(target: NgxInstance, key: Key, descriptor: Descriptor) {
      return {
          value: async function( ... args: any[]) {
              await target.ngxBeforeOnDestroy();
              return descriptor.value.apply(target, args);
          }
      }
  }

@AutoUnsubscribe()
@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DashboardComponent implements OnInit, OnDestroy, AfterViewInit, BeforeOnDestroy {

    public domain_list: any[];
    public ip_list: any[];
    sub0: Subscription;
    sub1: Subscription;
    tableHeight = 400;
    totalRule = 0;
    list = [{
        'id': '1',
        'data_chart': null
    },
    {
        'id': '2',
        'data_chart': null
    },
    {
        'id': '3',
        'data_chart': null
    },
    {
        'id': '4',
        'data_chart': null
    },
    {
        'id': '5',
        'data_chart': null
    },
    {
        'id': '6',
        'data_chart': null
    }]
    sortsData: any;
    FIELDS = [
        new Field('domain_name', 'Domain', {}, {
            type: 'label_table_domain',
            label_domain: true,
            minWidth: 200,
        }),
        new Field('service_pkg', 'Gói dịch vụ', {}, {
            maxWidth: 150,
            minWidth: 100,
        }),
        new Field('exp_date', 'Expiration date', {}, {
            type: 'label_table_domain',
            minWidth: 150,
            maxWidth: 200,
            label_exp_date: true
        }),

        new Field('status', "Status", {}, {
            type: 'label_table_domain',
            label_status: true,
            maxWidth: 150,
            minWidth: 100,
        }),

        new Field('attack', '', {}, {
            type: 'label_table_domain',
            minWidth: 100,
            maxWidth: 150,
            label_view: true,
            label: 'Attack/day'
        }),

        new Field('page_view', '', {}, {
            type: 'label_table_domain',
            minWidth: 100,
            maxWidth: 120,
            label_view: true,
            label: 'Pageview'
        }),
    ];
    tableData: ITableData = {
        page: new Page(),
        setPage: (e) => this.setPage(e),
        columns: this.FIELDS,
        rows: [],
        count: 0,
        total: 0,
        externalPaging: false,
        externalSorting: false,
        sorts: [],
        sortsData: [],
        onSort: this.noSort
    };
    constructor(
        public csUnitService: CsUnitService,
        private cdk: ChangeDetectorRef,
    ) {
        this.getAllDomain();
        this.getAllIp();
        
    }
    ngAfterViewInit() {
        try {
            setTimeout(() => {
                (document.getElementById('router-outlet-container') as HTMLElement).style.background = '#f2f4f8';
            },100)
        } catch (error) {
            
        }
      }

    ngOnInit() {
        this.loadData();
    }

    public ngxBeforeOnDestroy() {
        return new Promise((resolve) => {
            setTimeout(() => {
                (document.getElementById('router-outlet-container') as HTMLElement).style.background = '#ffff';
            },100)
        });
      }
    
    @BeforeOnDestroy
    public ngOnDestroy() {
    
        
    }
    getAllDomain() {
        let limit = 100;
        let offset = 0;
        let services = [WEBPROTECTION_ALIAS];
        const customer_service_id = undefined;
        this.sub0 = this.csUnitService.getCustomerServiceUnitList(
            limit,
            offset,
            services,
            customer_service_id)
            .subscribe(resp => {
                let websites = resp.data.rows;
                websites = websites.sort((a, b) => {
                    return a.identity > b.identity ? 1 : a.identity < b.identity ? -1 : 0;
                });
                this.domain_list = (websites || []).map(x => {
                    return {
                        ...x,
                        'name': x.identity,
                        'label': x.identity,
                        '_id': x._id,
                        'value': x._id,
                    };
                }).sort((x, y) => compareStrLower(x.label, y.label));
                this.cdk.detectChanges();
            });
    }
    getAllIp() {
        let limit = 100;
        let offset = 0;
        let services = [DDOSL4_ALIAS];
        const customer_service_id = undefined;
        this.sub1 = this.csUnitService.getCustomerServiceUnitList(
            limit,
            offset,
            services,
            customer_service_id)
            .subscribe(resp => {
                let ips = resp.data.rows;
                ips = ips.sort((a, b) => {
                    return a.identity > b.identity ? 1 : a.identity < b.identity ? -1 : 0;
                });
                this.ip_list = (ips || []).map(x => {
                    return {
                        ...x,
                        'name': x.identity,
                        'label': x.identity,
                        '_id': x._id,
                        'value': x._id,
                    };
                }).sort((x, y) => compareStrLower(x.label, y.label));
                this.cdk.detectChanges();
            });
    }
    doAddDomain() {

    }
    doViewDomain(domain) {

    }
    doDeleteDomain(domain) {

    }
    doAddIp() {

    }
    doViewIp(ip) {

    }
    doDeleteIp(ip) {

    }


    setPage(e) {

    }

    noSort(e) {
        this.sortsData = e.sorts[0];
    }

    loadData() {
        setTimeout(() => {
            this.tableData.rows = [
                {
                    domain_name: "domain1.com",
                    service_pkg: "VIP",
                    type:'News',
                    exp_date: 20,
                    status: 50,
                    active: true,
                    attack:800,
                    page_view: 1000,
                    canUpdate: true,
                    canRenew: false
                },
                {
                    domain_name: "domain2.com",
                    service_pkg: "FREE",
                    type:'News',
                    exp_date: 15,
                    status: 50,
                    active: false,
                    attack:800,
                    page_view: 1000,
                    canUpdate: false,
                    canRenew: true
                },
                {
                    domain_name: "domain2.com",
                    service_pkg: "FREE",
                    type:'News',
                    exp_date: 6,
                    status: 50,
                    active: false,
                    attack:800,
                    page_view: 1000,
                    canUpdate: true,
                    canRenew: false
                },
                {
                    domain_name: "domain2.com",
                    service_pkg: "FREE",
                    type:'News',
                    exp_date: 10,
                    status: 50,
                    active: true,
                    attack:800,
                    page_view: 1000,
                    canUpdate: false,
                    canRenew: true
                },
                {
                    domain_name: "domain2.com",
                    service_pkg: "FREE",
                    type:'News',
                    exp_date: 8,
                    status: 50,
                    active: true,
                    attack:800,
                    page_view: 1000,
                    canUpdate: false,
                    canRenew: true
                }
            ];
            this.tableData.count = this.tableData.rows.length;
            this.tableData.total = this.tableData.rows.length;
            this.totalRule = this.tableData.total;
            this.cdk.detectChanges();
        }, 500);
        setTimeout(() => window.dispatchEvent(new Event('resize')), 500);
        this.list.map(it =>it.data_chart = this.getChart(it));
    }


    getChart(data) {
        const dataChart = [
          { label: 'a', value: 5 },
          { label: 'a1', value: 51 },
          { label: 'a2', value: 25 },
          { label: 'a3', value: 12 },
          { label: 'a4', value: 37 },
          { label: 'a5', value: 45 },
          { label: 'a6', value: 17 },
          { label: 'a', value: 5 },
          { label: 'a1', value: 51 },
          { label: 'a2', value: 25 },
          { label: 'a3', value: 12 },
          { label: 'a4', value: 37 },
          { label: 'a5', value: 45 },
          { label: 'a6', value: 17 },
          { label: 'a6', value: 27 },
          { label: 'a6', value: 37 },
          { label: 'a6', value: 7 },
          { label: 'a6', value: 87 },
          { label: 'a6', value: 57 },
          { label: 'a6', value: 37 },
          { label: 'a', value: 5 },
          { label: 'a1', value: 51 },
          { label: 'a2', value: 25 },
          { label: 'a3', value: 12 },
          { label: 'a4', value: 37 },
          { label: 'a5', value: 45 },
          { label: 'a6', value: 17 },
          { label: 'a', value: 5 },
          { label: 'a1', value: 51 },
          { label: 'a2', value: 25 },
          { label: 'a3', value: 12 },
          { label: 'a4', value: 37 },
          { label: 'a5', value: 45 },
          { label: 'a6', value: 17 },
          { label: 'a6', value: 27 },
          { label: 'a6', value: 37 },
          { label: 'a6', value: 7 },
          { label: 'a6', value: 87 },
          { label: 'a6', value: 57 },
          { label: 'a6', value: 37 },
        ];
        return new TopChartIP(
        dataChart,
          'label',
          'value',
          '',
          data.id,
          true,
        )
      }
}

export class TopChartIP {
    constructor(
      public topData: any,
      public name: string,
      public value: string,
      public field: string,
      public chart_id: string,
      public reload: boolean,
    ) { }
  }
