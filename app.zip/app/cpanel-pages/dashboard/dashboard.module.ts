import {NgModule} from '@angular/core';
import {COMMON_MODULES} from '@common/lazyload';
import {dashboardRouter} from './dashboard.router';
import { DashboardComponent } from './dashboard.component';
import { ChartIPComponent } from './chart-ip-component/chart-ip.component';
const MODALS = [];
@NgModule({
    declarations: [
        DashboardComponent,
        ChartIPComponent
    ],
    imports: [
        ...COMMON_MODULES,
        dashboardRouter,
    ],
    entryComponents: [
        ...MODALS,
    ],
    providers: [],
})
export class DashboardModule {
}
