export enum Status {
  SUCCESS = 'accepted',
  PROCESSING = 'processing',
  CANCELED = 'canceled',
}