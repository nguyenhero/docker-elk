import {
  Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef
} from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { Page } from '@common/page';
import { OrderService } from '@common/swagger-services';
import { ClientPermService } from '@common/services';
import { AutoUnsubscribe } from "ngx-auto-unsubscribe";

@AutoUnsubscribe()
@Component({
  selector: 'tour-orders',
  templateUrl: './orders.component.html',
  styleUrls: [ './orders.component.scss' ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TourOrdersComponent implements OnInit {
  orderList = [];
  page = new Page();
  sub01;

  constructor(private orderService: OrderService,
    private clientPerm: ClientPermService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cd: ChangeDetectorRef,
  ) {
    this.orderList = [];
    this.page.size = 10;
    this.page.pageNumber = 0;
  }

  get user() {
    return this.clientPerm.current_user;
  }

  ngOnInit() {
    this.loadOrderList();
  }

  ngOnDestroy() {
    this.sub01 && this.sub01.unsubscribe();
  }

  /**
   * Load order list from server
   */
  FAKE_ORDER_RESP = {
    "code": 200,
    "count": 1,
    "data": {
      "rows": [
        {
          "_id": "5b29cc13010608274ef10718",
          "amount": 1000000,
          "code": 413,
          "created_date": "2018-06-20T03:37Z",
          "customer_id": "5af67c870106082b7365f38b",
          "customer_info": {
            "address": "6518 Robert Village\nWalkerstad, CA 26857",
            "birthday": null,
            "company": null,
            "email": "dustingonzalez@young.com",
            "fullname": "Jordan Nguyen_D0",
            "id_number": "960671249",
            "phone": "6804969989",
            "website": null
          },
          "customer_name": "Jordan Nguyen_D0",
          "deleted": false,
          "distributor_id": "5af67c830106082b7365e5ba",
          "histories": [
            {
              "actor": "customer_D0_1",
              "actor_id": "5af67c870106082b7365f38b",
              "data": {},
              "date": "20/06/2018",
              "message": "Created new record"
            }
          ],
          "modified_date": "20/06/2018",
          "owner_id": "5af67c870106082b7365f38b",
          "owner_name": "Jordan Nguyen_D0",
          "package_info": [
            {
              "_id": "5af67c890106082b7365f590",
              "nDomain": 9,
              "nDuration": 55,
              "name": "Package_D0_17",
              "price": 1000000,
              "service_name": "AntiDDoS Layer 7",
              "time_unit": "day"
            }
          ],
          "packages": [
            "5af67c890106082b7365f590"
          ],
          "payment_status": "unpaid",
          "payment_type": "Chuyển khoản ATM",
          "salePrice": 0,
          "saler_id": "5af67c830106082b7365e6cf",
          "service_name_list": [
            "AntiDDoS Layer 7"
          ],
          "status": "processing",
          "tempPrice": 1000000,
          "type": "new"
        }
      ]
    },
    "jsonrpc": "2.0",
    "message": "OK",
    "notification": {
      "helpdesk": 2,
      "orders": 0,
      "promotions": 0
    },
    "status": true,
    "version": "CLOUD PORTAL v1.0"
  };
  loadOrderList(offset?) {
    this.orderList = this.FAKE_ORDER_RESP.data.rows;
    this.page.totalElements = this.FAKE_ORDER_RESP.count;
    this.cd.detectChanges();
  }

  /**
   * Create new order
   */
  onNewOrder() {
  }

  /**
   * On change page
   */
  changePage(e) {
  }

  /**
   * Navigate wrapper
   */
  navigate(url, opt?) {
  }

  /**
   * Check if pagination is visible
   */
  isPagerVisible() {
    return (this.page.totalElements / this.page.size) > 1;
  }

  /**
   * Get number of orders
   */
  orderCount() {
    return this.page.totalElements;
  }

}
