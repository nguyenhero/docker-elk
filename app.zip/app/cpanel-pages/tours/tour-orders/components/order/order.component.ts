import {Component, OnInit, Input, ChangeDetectorRef, ChangeDetectionStrategy, OnDestroy} from '@angular/core';
import {Status} from '../../constants';
import {OrderService} from '@common/swagger-services';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";


@AutoUnsubscribe()
@Component({
  selector: 'tour-order-item',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TourOrderComponent implements OnInit, OnDestroy {
  Status = Status;
  @Input() data: any = {};
  isTitleExpanded = false;
  isRated = false;

  constructor(private orderService: OrderService,
              private cd: ChangeDetectorRef,
  ) {
  }

  ngOnInit() {
    this.isRated = this.data.rating > 0;
  }

  ngOnDestroy() {

  }

  // TODO: trams
  get title() {
    let names = this.data.service_name_list || [];
    let first = names[0] || '';
    let remain = names.length - 1;
    let title;
    if (!this.isTitleExpanded) {
      if (remain <= 0) return first;
      return `${first} và ${remain} sản phẩm khác`;
    } else {
      return names.join(', ');
    }
  }

  get status() {
    return this.data.status;
  }

  get rating() {
    return this.data.rating;
  }

  onRatingChange(e) {
    this.data.rating = e.rating;
  }

  toggleTitle() {
    this.isTitleExpanded = !this.isTitleExpanded;
  }

  cancelOrder() {
    // swalShowConfirm('Hủy đơn hàng', 'Xác nhận hủy đơn hàng?', () => {
    //   const model: any = {status: 'canceled'};
    //
    //   this.orderService.putOrderItem(this.data._id, model).subscribe((resp: any) => {
    //     this.data.status = Status.CANCELED;
    //     this.cd.detectChanges();
    //   });
    // });
  }

  setRating() {
    if (this.data.rating) {
      this.isRated = true;
    }
  }
}
