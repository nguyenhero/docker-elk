import {Component, OnInit, Inject, ChangeDetectorRef, OnDestroy} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {FormControl, Validators} from '@angular/forms';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";


@AutoUnsubscribe()
@Component({
  selector: 'tour-otp-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class TourPaymentModalComponent implements OnInit, OnDestroy {
  data: any;

  constructor(public dialogRef: MatDialogRef<TourPaymentModalComponent>,
              @Inject(MAT_DIALOG_DATA) public datax: any, private cd: ChangeDetectorRef,) {
    this.data = datax;
  }

  ngOnInit() {
  }

  ngOnDestroy() {

  }

  setData(datax) {
    this.data = datax;
    this.cd.detectChanges();
  }

  closeDialog() {
    this.dialogRef.close();
  }

}
