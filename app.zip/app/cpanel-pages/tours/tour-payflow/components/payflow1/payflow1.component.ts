import {
  Component, OnInit, ChangeDetectionStrategy,
  ChangeDetectorRef, AfterViewInit
} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { OrderService, PriceService} from '@common/swagger-services';
import { ClientPermService} from '@common/services';
import {castArray, swalNotiSuccess, swalShowError} from '@common/utils';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";


function range(n) {
  return Array.apply(null, {length: n}).map(function (value, index) {
    return index + 1;
  });
}


class Package {
  public _id;
  public name;
  public maxDomain;
  public duration;
  public price;

  public nDomain;
  public nDuration;
  public customPrice;

  constructor(json) {
    for (let k in json) {
      this[k] = json[k];
    }

    this.nDomain = this.nDomain || this.maxDomain;
    this.nDuration = this.nDuration || this.duration;
    this.customPrice = this.customPrice || this.price;
  }

  calcPrice() {
    let domainScale = this.maxDomain ? (this.nDomain <= this.maxDomain ? 1 : this.nDomain / this.maxDomain) : 1;
    this.customPrice = this.price * domainScale * (this.nDuration / this.duration);
    this.customPrice = Math.round(this.customPrice);
    return this.customPrice;
  }
}


class Service {
  public name;
  public packageList;
  public curPackage;

  constructor(json) {
    for (let k in json) {
      this[k] = json[k];
    }
    this.packageList = this.packageList || [];
    this.packageList = this.packageList.map(v => new Package(v));
    this.curPackage = this.packageList[0] || {};
  }

  calcPrice() {
    return (this.curPackage && this.curPackage.calcPrice && this.curPackage.calcPrice()) || 0;
  }

  setCurPackage(id) {
    let p = this.packageList.find(v => v._id == id);
    this.curPackage = p || {};
    return p;
  }
}


@AutoUnsubscribe()
@Component({
  selector: 'tour-payflow1',
  templateUrl: './payflow1.component.html',
  styleUrls: ['./payflow1.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TourPayflow1Component implements OnInit {
  sub01;
  monthList = range(100);
  numDomainList = range(100);
  serviceList = [];
  servicePackageMap = [];
  params;

  tempPrice = 0;
  salePrice = 0;
  finalPrice = 0;

  promotionCode;
  activePromotionCode;

  FAKE_PRICE_SERVICES = {
    "code": 200,
    "count": 3,
    "data": {
      "rows": [
        {
          "_id": "5af67c830106082b7365e5c2",
          "name": "AntiDDoS Layer 7",
          "packageList": [
            {
              "_id": "5af67c890106082b7365f590",
              "base_packages": [],
              "created_date": "12/05/2018",
              "deleted": false,
              "distributor_id": "5af67c830106082b7365e5ba",
              "duration": 55,
              "histories": [
                {
                  "actor": "sadmin",
                  "actor_id": "5a655e36da0d1e1f8db866f8",
                  "data": {},
                  "date": "12/05/2018",
                  "message": "Created new record"
                },
                {
                  "actor": "sadmin",
                  "actor_id": "5a655e36da0d1e1f8db866f8",
                  "data": {
                    "status": "inactive"
                  },
                  "date": "12/05/2018",
                  "message": "Updated record"
                },
                {
                  "actor": "sadmin",
                  "actor_id": "5a655e36da0d1e1f8db866f8",
                  "data": {
                    "status": "active"
                  },
                  "date": "14/06/2018",
                  "message": "Updated record"
                }
              ],
              "maxDomain": 9,
              "modified_date": "14/06/2018",
              "name": "Package_D0_17",
              "note": "",
              "price": 1000000,
              "price_base": "service",
              "services": [
                {
                  "_id": "5af67c830106082b7365e5c2",
                  "name": "AntiDDoS Layer 7",
                  "price": 1000000,
                  "properties": [
                    {
                      "_id": "5af67c820106082b7365e5b0",
                      "name": "Hỗ trợ băng thông tối đa",
                      "type": "number",
                      "unit": "GB/tháng",
                      "value": "230"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b1",
                      "name": "Chống tấn công khai thác lỗ hổng web",
                      "type": "boolean",
                      "unit": " ",
                      "value": "false"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b2",
                      "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
                      "type": "boolean",
                      "unit": " ",
                      "value": "false"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b3",
                      "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
                      "type": "boolean",
                      "unit": " ",
                      "value": "false"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b4",
                      "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
                      "type": "boolean",
                      "unit": " ",
                      "value": "true"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b6",
                      "name": "load",
                      "type": "number",
                      "unit": "Request/s",
                      "value": "419"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b7",
                      "name": "ndomain",
                      "type": "number",
                      "unit": "Max domain",
                      "value": "9"
                    }
                  ]
                }
              ],
              "status": "active",
              "time_unit": "day"
            },
            {
              "_id": "5af67c890106082b7365f5a9",
              "base_packages": [],
              "created_date": "12/05/2018",
              "deleted": false,
              "distributor_id": "5af67c830106082b7365e5ba",
              "duration": 62,
              "histories": [
                {
                  "actor": "sadmin",
                  "actor_id": "5a655e36da0d1e1f8db866f8",
                  "data": {},
                  "date": "12/05/2018",
                  "message": "Created new record"
                },
                {
                  "actor": "sadmin",
                  "actor_id": "5a655e36da0d1e1f8db866f8",
                  "data": {
                    "status": "inactive"
                  },
                  "date": "12/05/2018",
                  "message": "Updated record"
                },
                {
                  "actor": "sadmin",
                  "actor_id": "5a655e36da0d1e1f8db866f8",
                  "data": {
                    "status": "active"
                  },
                  "date": "14/06/2018",
                  "message": "Updated record"
                }
              ],
              "maxDomain": 10,
              "modified_date": "14/06/2018",
              "name": "Package_D0_42",
              "note": "",
              "price": 1000000,
              "price_base": "service",
              "services": [
                {
                  "_id": "5af67c830106082b7365e5c2",
                  "name": "AntiDDoS Layer 7",
                  "price": 1000000,
                  "properties": [
                    {
                      "_id": "5af67c820106082b7365e5b0",
                      "name": "Hỗ trợ băng thông tối đa",
                      "type": "number",
                      "unit": "GB/tháng",
                      "value": "258"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b1",
                      "name": "Chống tấn công khai thác lỗ hổng web",
                      "type": "boolean",
                      "unit": " ",
                      "value": "true"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b2",
                      "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
                      "type": "boolean",
                      "unit": " ",
                      "value": "false"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b3",
                      "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
                      "type": "boolean",
                      "unit": " ",
                      "value": "false"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b4",
                      "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
                      "type": "boolean",
                      "unit": " ",
                      "value": "false"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b6",
                      "name": "load",
                      "type": "number",
                      "unit": "Request/s",
                      "value": "278"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b7",
                      "name": "ndomain",
                      "type": "number",
                      "unit": "Max domain",
                      "value": "10"
                    }
                  ]
                }
              ],
              "status": "active",
              "time_unit": "day"
            },
            {
              "_id": "5b2b0da10106081184890083",
              "base_packages": [],
              "created_date": "21/06/2018",
              "deleted": false,
              "distributor_id": "5af67c830106082b7365e5ba",
              "duration": 24,
              "histories": [
                {
                  "actor": "sadmin",
                  "actor_id": "5a655e36da0d1e1f8db866f8",
                  "data": {},
                  "date": "21/06/2018",
                  "message": "Created new record"
                },
                {
                  "actor": "sadmin",
                  "actor_id": "5a655e36da0d1e1f8db866f8",
                  "data": {
                    "price": 1000000,
                    "services": {
                      "0": {
                        "price": 1000000
                      }
                    }
                  },
                  "date": "21/06/2018",
                  "message": "Updated record"
                },
                {
                  "actor": "sadmin",
                  "actor_id": "5a655e36da0d1e1f8db866f8",
                  "data": {
                    "duration": 24,
                    "price": 5000000,
                    "services": {
                      "0": {
                        "price": 5000000,
                        "properties": {
                          "3": {
                            "value": "false"
                          },
                          "4": {
                            "value": "999"
                          },
                          "5": {
                            "value": "20"
                          },
                          "6": {
                            "value": "500"
                          }
                        }
                      }
                    }
                  },
                  "date": "21/06/2018",
                  "message": "Updated record"
                }
              ],
              "maxDomain": 20,
              "modified_date": "21/06/2018",
              "name": "Package_D0_99",
              "note": "",
              "owner_id": "5a655e36da0d1e1f8db866f8",
              "price": 5000000,
              "price_base": "service",
              "services": [
                {
                  "_id": "5af67c830106082b7365e5c2",
                  "name": "AntiDDoS Layer 7",
                  "price": 5000000,
                  "properties": [
                    {
                      "_id": "5af67c820106082b7365e5b1",
                      "name": "Chống tấn công khai thác lỗ hổng web",
                      "type": "boolean",
                      "unit": " ",
                      "value": "true"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b2",
                      "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
                      "type": "boolean",
                      "unit": " ",
                      "value": "true"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b3",
                      "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
                      "type": "boolean",
                      "unit": " ",
                      "value": "true"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b4",
                      "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
                      "type": "boolean",
                      "unit": " ",
                      "value": "false"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b6",
                      "name": "load",
                      "type": "number",
                      "unit": "Request/s",
                      "value": "999"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b7",
                      "name": "ndomain",
                      "type": "number",
                      "unit": "Max domain",
                      "value": "20"
                    },
                    {
                      "_id": "5af67c820106082b7365e5b0",
                      "name": "Hỗ trợ băng thông tối đa",
                      "type": "number",
                      "unit": "GB/tháng",
                      "value": "500"
                    }
                  ]
                }
              ],
              "status": "active",
              "time_unit": "month"
            }
          ]
        }
      ]
    },
    "jsonrpc": "2.0",
    "message": "OK",
    "notification": {
      "helpdesk": 2,
      "orders": 0,
      "promotions": 0
    },
    "status": true,
    "version": "CLOUD PORTAL v1.0"
  };

  constructor(private router: Router,
              private activatedRoute: ActivatedRoute,
              private packageService: PriceService,
              private orderService: OrderService,
              private clientPerm: ClientPermService,
              private cd: ChangeDetectorRef,
  ) {
  }

  ngOnInit() {
    this.sub01 = this.activatedRoute.queryParams.subscribe(params => {
      const step = parseInt(params.step) || 1;
      const substep = parseInt(params.substep) || 1;
      if (step != 1 || substep != 2) return;

      if (!params.services) {
        return this.navigate(['/c/payflow'], {replaceUrl: true});
      }

      this.params = params;
      this.parseServicePackageMap(params.services);
      let serviceList = this.servicePackageMap.map(v => v[0]);
      this.getServiceData(serviceList);
    });
  }


  ngOnDestroy() {
    this.sub01 && this.sub01.unsubscribe();
  }

  get user() {
    return this.clientPerm.current_user;
  }

  parseServicePackageMap(services) {
    services = castArray(services);
    this.servicePackageMap = services.map(v => v.split(','));
  }

  getServiceData(serviceList) {
    // const u = void 0;
    // this.packageService.getPriceList(u, u, u, u, u, u, serviceList)
    //   .subscribe((resp: any) => {
    //     this.parseServiceData(resp.data.rows);
    //   });
    this.parseServiceData(this.FAKE_PRICE_SERVICES.data.rows);
  }

  /**
   * Parse service json
   */
  parseServiceData(serviceList) {
    this.serviceList = serviceList.map(v => new Service(v));
    if (!this.setCurPackage()) return;
    this.calcPrice();
  }

  setCurPackage() {
    for (let i = 0; i < this.serviceList.length; i++) {
      let s = this.serviceList[i];
      let pid = this.servicePackageMap[i][1];
      if (!s.setCurPackage(pid)) {
        swalShowError('Lỗi', 'Tham số package_id không hợp lệ');
        this.navigate(['/c/tourpayflow'], {replaceUrl: true});
        return false;
      }
    }
    return true;
  }

  /**
   * Get packages id
   */
  getPackagesId() {
    return this.serviceList.map(v => v.curPackage._id);
  }

  /**
   * Get package info
   */
  getPackageInfo() {
    return this.serviceList.map(v => {
      let o = {service_name: v.name, price: v.curPackage.customPrice};
      let p = Object.assign({}, v.curPackage, o);
      if (!p.nDomain) delete p.nDomain; // remove nDomain
      return p;
    });
  }

  createOrder() {
    // const u = void 0;
    // const packages = this.getPackagesId();
    // const packageinfo = this.getPackageInfo();
    // const model: any = {
    //   amount: this.finalPrice,
    //   customer_id: this.user.user_id,
    //   payment_status: 'unpaid',
    //   status: 'processing',
    //   packages: packages,
    //   package_info: packageinfo,
    //   coupon_code: this.activePromotionCode,
    // };
    // this.orderService.postOrderList(model)
    //   .subscribe(resp => {
    //     // console.log('postorder', resp);
    //     const q = {step: 2, order_id: resp.data};
    //     this.navigate(['/c/tourpayflow'], {queryParams: q});
    //   }, err => {
    //     // btn.disabled = false;
    //     throw err;
    //   });
  }

  navigate(url, opt?) {
    // setTimeout(() => this.router.navigate(url, opt), 100);
  }

  /**
   * Handle event change package type
   */
  onChangePackageType(service, e) {
    const cp = e.value;
    cp.nDomain = cp.maxDomain;
    service.curPackage = cp;
    this.calcPrice();
  }

  /**
   * Handle event change package number of domain
   */
  onChangePackageNumDomain(service, value) {
    const cp = service.curPackage;
    cp.nDomain = value;
    this.calcPrice();
  }

  /**
   * Handle event change package duration
   */
  onChangePackageDuration(service, value) {
    const cp = service.curPackage;
    cp.nDuration = value;
    this.calcPrice();
  }

  /**
   * Calculate price
   */
  calcPrice() {
    this.serviceList.map(v => v.calcPrice());
    this.get_price_packages();
  }

  /**
   * Get price for packages with current promotion code
   */
  get_price_packages() {
    // const u = void 0;
    // const model: any = {
    //   packages: this.getPackagesId(),
    //   package_info: this.getPackageInfo(),
    //   coupon_code: this.activePromotionCode,
    // };
    // this.orderService.postApplyCouponCode(model).subscribe(resp => {
    //   let data: any = resp.data || {};
    //   if (data.status == 'valid') {
    //     this.salePrice = data.sale;
    //     this.tempPrice = data.temp_price;
    //     this.finalPrice = data.total_price;
    //     this.detectChanges();
    //   } else {
    //     swalShowError('Lỗi', data.message);
    //   }
    // });
  }

  /**
   * Apply coupon code
   */
  onApply() {
    // const model = {
    //   packages: this.getPackagesId(),
    //   coupon_code: this.promotionCode,
    //   package_info: this.getPackageInfo(),
    // };
    // this.orderService.postApplyCouponCode(model).subscribe(resp => {
    //   let data: any = resp.data || {};
    //   if (data.status == 'valid') {
    //     this.salePrice = data.sale;
    //     this.tempPrice = data.temp_price;
    //     this.finalPrice = data.total_price;
    //     this.activePromotionCode = this.promotionCode;
    //     this.detectChanges();
    //     swalNotiSuccess('Thông báo', `Mã giảm giá: ${this.promotionCode}`);
    //   } else {
    //     this.activePromotionCode = void 0;
    //     swalShowError('Lỗi', data.message);
    //     this.calcPrice();
    //   }
    // });
  }

  /**
   * Buy more service
   */
  buyMoreService() {
    // const q = {services: this.params.services, step: 1, substep: 1};
    // this.navigate(['/c/payflow'], {queryParams: q});
  }

  detectChanges() {
    try {
      this.cd.detectChanges();
    } catch (e) {
    }
  }
}
