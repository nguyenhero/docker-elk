import {Component, ChangeDetectionStrategy, ChangeDetectorRef} from '@angular/core';
import {Router, ActivatedRoute} from "@angular/router";
import {PublicService} from '@common/swagger-services';
import {castArray, swalShowWarn, _ } from '@common/utils';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";

@AutoUnsubscribe()
@Component({
  selector: 'tour-select-package',
  templateUrl: 'selectpackage.html',
  styleUrls: ['selectpackage.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TourSelectPackageComponent {
  tabInfo;
  SERVICES = [];
  PACKAGES = [];
  selectedList;

  sub01;
  sub02;
  sub03;

  FAKE_PACKAGES_RESP = {
    "code": 200,
    "data": [
      {
        "packages": [
          {
            "_id": "5b3b14f80106081f8ea974ce",
            "ext": [],
            "name": "WAF1",
            "price": 1000000,
            "properties": [
              {
                "_id": "5b3a12c20106080fa1770fdd",
                "name": "Hỗ trợ băng thông tối đa",
                "type": "number",
                "unit": "GB/tháng",
                "value": "1"
              },
              {
                "_id": "5b3a12c20106080fa1770fde",
                "name": "Chống tấn công khai thác lỗ hổng web",
                "type": "boolean",
                "unit": " ",
                "value": "false"
              },
              {
                "_id": "5b3a12c20106080fa1770fdf",
                "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fe0",
                "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
                "type": "boolean",
                "unit": " ",
                "value": "false"
              },
              {
                "_id": "5b3a12c20106080fa1770fe1",
                "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
                "type": "boolean",
                "unit": " ",
                "value": "false"
              },

            ]
          },
          {
            "_id": "5b3b15140106081f8ea974cf",
            "ext": [],
            "name": "WAF2",
            "price": 2000000,
            "properties": [
              {
                "_id": "5b3a12c20106080fa1770fdd",
                "name": "Hỗ trợ băng thông tối đa",
                "type": "number",
                "unit": "GB/tháng",
                "value": "22"
              },
              {
                "_id": "5b3a12c20106080fa1770fde",
                "name": "Chống tấn công khai thác lỗ hổng web",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fdf",
                "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fe0",
                "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fe1",
                "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
                "type": "boolean",
                "unit": " ",
                "value": "false"
              },

            ]
          },
          {
            "_id": "5b3b152a0106081f8ea974d0",
            "ext": [],
            "name": "WAF3",
            "price": 300000,
            "properties": [
              {
                "_id": "5b3a12c20106080fa1770fdd",
                "name": "Hỗ trợ băng thông tối đa",
                "type": "number",
                "unit": "GB/tháng",
                "value": "333"
              },
              {
                "_id": "5b3a12c20106080fa1770fde",
                "name": "Chống tấn công khai thác lỗ hổng web",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fdf",
                "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fe0",
                "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fe1",
                "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },

            ]
          },
        ],
        "service": {
          "_id": "5b3a12c20106080fa1770fec",
          "ext": [],
          "name": "WAF",
          "properties": [
            {
              "_id": "5b3a12c20106080fa1770fdd",
              "name": "Hỗ trợ băng thông tối đa",
              "type": "number",
              "unit": "GB/tháng"
            },
            {
              "_id": "5b3a12c20106080fa1770fde",
              "name": "Chống tấn công khai thác lỗ hổng web",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fdf",
              "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe0",
              "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe1",
              "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
              "type": "boolean",
              "unit": " "
            }
          ]
        }
      },
      {
        "packages": [],
        "service": {
          "_id": "5b3a12c20106080fa1770fed",
          "ext": [],
          "name": "Email Security Gate",
          "properties": [
            {
              "_id": "5b3a12c20106080fa1770fdd",
              "name": "Hỗ trợ băng thông tối đa",
              "type": "number",
              "unit": "GB/tháng"
            },
            {
              "_id": "5b3a12c20106080fa1770fde",
              "name": "Chống tấn công khai thác lỗ hổng web",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fdf",
              "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe0",
              "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe1",
              "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe5",
              "name": "load",
              "type": "number",
              "unit": "Mail/s"
            }
          ]
        }
      },
      {
        "packages": [
          {
            "_id": "5b3a12c30106080fa17711ca",
            "ext": [],
            "name": "Package_D0_6",
            "price": 1000000,
            "properties": [
              {
                "_id": "5b3a12c20106080fa1770fdd",
                "name": "Hỗ trợ băng thông tối đa",
                "type": "number",
                "unit": "GB/tháng",
                "value": "226"
              },
              {
                "_id": "5b3a12c20106080fa1770fde",
                "name": "Chống tấn công khai thác lỗ hổng web",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fdf",
                "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fe0",
                "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fe1",
                "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fe2",
                "name": "bandwidth",
                "type": "number",
                "unit": "Gbps",
                "value": "296"
              }
            ]
          }
        ],
        "service": {
          "_id": "5b3a12c20106080fa1770fee",
          "ext": [],
          "name": "AntiDDoS Layer 4",
          "properties": [
            {
              "_id": "5b3a12c20106080fa1770fdd",
              "name": "Hỗ trợ băng thông tối đa",
              "type": "number",
              "unit": "GB/tháng"
            },
            {
              "_id": "5b3a12c20106080fa1770fde",
              "name": "Chống tấn công khai thác lỗ hổng web",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fdf",
              "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe0",
              "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe1",
              "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe2",
              "name": "bandwidth",
              "type": "number",
              "unit": "Gbps"
            }
          ]
        }
      },
      {
        "packages": [
          {
            "_id": "5b3a12c30106080fa17711cc",
            "ext": [],
            "name": "Package_D0_8",
            "price": 1000000,
            "properties": [
              {
                "_id": "5b3a12c20106080fa1770fdd",
                "name": "Hỗ trợ băng thông tối đa",
                "type": "number",
                "unit": "GB/tháng",
                "value": "91"
              },
              {
                "_id": "5b3a12c20106080fa1770fde",
                "name": "Chống tấn công khai thác lỗ hổng web",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fdf",
                "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
                "type": "boolean",
                "unit": " ",
                "value": "false"
              },
              {
                "_id": "5b3a12c20106080fa1770fe0",
                "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
                "type": "boolean",
                "unit": " ",
                "value": "false"
              },
              {
                "_id": "5b3a12c20106080fa1770fe1",
                "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
                "type": "boolean",
                "unit": " ",
                "value": "true"
              },
              {
                "_id": "5b3a12c20106080fa1770fe3",
                "name": "load",
                "type": "number",
                "unit": "Request/s",
                "value": "121"
              },
              {
                "_id": "5b3a12c20106080fa1770fe4",
                "name": "ndomain",
                "type": "number",
                "unit": "Max domain",
                "value": "7"
              }
            ]
          }
        ],
        "service": {
          "_id": "5b3a12c20106080fa1770fef",
          "ext": [],
          "name": "AntiDDoS Layer 7",
          "properties": [
            {
              "_id": "5b3a12c20106080fa1770fdd",
              "name": "Hỗ trợ băng thông tối đa",
              "type": "number",
              "unit": "GB/tháng"
            },
            {
              "_id": "5b3a12c20106080fa1770fde",
              "name": "Chống tấn công khai thác lỗ hổng web",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fdf",
              "name": "Cảnh báo lỗ hổng bảo mật thông thường cho website",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe0",
              "name": "Phòng chống tấn công từ chối dịch vụ ở layer 4 và layer 7",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe1",
              "name": "Cảnh báo lỗ hổng bảo mật nâng cao (0-day, 1-day)",
              "type": "boolean",
              "unit": " "
            },
            {
              "_id": "5b3a12c20106080fa1770fe3",
              "name": "load",
              "type": "number",
              "unit": "Request/s"
            },
            {
              "_id": "5b3a12c20106080fa1770fe4",
              "name": "ndomain",
              "type": "number",
              "unit": "Max domain"
            }
          ]
        }
      }
    ],
    "jsonrpc": "2.0",
    "message": "OK",
    "status": true,
    "version": "CLOUD PORTAL v1.0"
  };

  constructor(private router: Router,
              private activatedRoute: ActivatedRoute,
              private publicService: PublicService,
              // private clientPerm: ClientPermService,
              private cd: ChangeDetectorRef,
  ) {
    this.onCardSelected = this.onCardSelected.bind(this);
  }

  ngOnInit() {
    this.sub03 = this.activatedRoute.queryParams.subscribe(params => {
      this.selectedList = castArray(params.services) || [];
    });
    this.getServices();
  }

  ngOnDestroy() {
    this.sub01 && this.sub01.unsubscribe();
    this.sub02 && this.sub02.unsubscribe();
    this.sub03 && this.sub03.unsubscribe();
  }

  getServices() {
    this.tabInfo = this.FAKE_PACKAGES_RESP.data;
    this.cd.detectChanges();
  }


  onCardSelected(sv, pkg) {
    // if (this.publicService.isProdVersion()) {
    //   swalShowWarn(_("Thông báo"), _("Chức năng sẽ sớm ra mắt trong thời gian tới"));
    //   return;
    // }
    // const sid = sv._id;
    // const pid = pkg._id;
    // let selectedList = this.selectedList.concat([[sid, pid].join(',')]);
    // const q = {services: selectedList, substep: 2};
    // this.navigate(['/c/tourpayflow'], {queryParams: q})
  }

  navigate(url, opt?) {
    // setTimeout(() => this.router.navigate(url, opt), 100);
  }
}
