import {
  Component, OnInit, ChangeDetectionStrategy, OnDestroy, Input, ChangeDetectorRef, AfterViewInit
} from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {OrderService} from '@common/swagger-services';
import {HopscotchService} from '@visc/ngx-hopscotch';
import {MatDialog, MatDialogRef} from '@angular/material';
import {TourPaymentModalComponent} from '../../../popup-payment/modal.component';
import {AppComponent} from '@customer/app.component';
import {TranslateService} from '@ngx-translate/core';
import {PerfectScrollbarDirective} from 'ngx-perfect-scrollbar';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";

@AutoUnsubscribe()
@Component({
  selector: 'tour-payflow2',
  templateUrl: './payflow2.component.html',
  styleUrls: ['./payflow2.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TourPayflow2Component implements OnInit, AfterViewInit, OnDestroy {
  @Input() order_id;
  paymentType = "1";
  isExportOrderHidden = true;

  ATM_LIST = [
    // {value: 'ABB', name: '', image: '123PABB.jpg'},
    {value: 'ACB', name: '', image: '123PACB.jpg'},
    {value: 'AGB', name: '', image: '123PAGB.jpg'},
    {value: 'BAB', name: '', image: '123PBAB.jpg'},
    {value: 'BIDV', name: '', image: '123PBIDV.jpg'},
    // {value: 'BVB', name: '', image: '123PBVB.jpg'},
    {value: 'DAB', name: '', image: '123PDAB.jpg'},
    {value: 'EXB', name: '', image: '123PEIB.jpg'},
    {value: 'GPB', name: '', image: '123PGPB.jpg'},
    {value: 'HDB', name: '', image: '123PHDB.jpg'},
    // {value: 'LPB', name: '', image: '123PLPB.jpg'},
    {value: 'MB', name: '', image: '123PMB.jpg'},
    {value: 'MSB', name: '', image: '123PMRTB.jpg'},
    {value: 'NAB', name: '', image: '123PNAB.jpg'},
    {value: 'NVB', name: '', image: '123PNVB.jpg'},
    // {value: 'OCB', name: '', image: '123POCB.jpg'},
    {value: 'OJB', name: '', image: '123POCEB.jpg'},
    {value: 'PGB', name: '', image: '123PPGB.jpg'},
    {value: 'SCB', name: '', image: '123PSCB.jpg'},
    // {value: 'SEAB', name: '', image: '123PSEAB.jpg'},
    {value: 'SGB', name: '', image: '123PSGB.jpg'},
    {value: 'SHB', name: '', image: '123PSHB.jpg'},
    {value: 'TCB', name: '', image: '123PTCB.jpg'},
    {value: 'TPB', name: '', image: '123PTPB.jpg'},
    {value: 'VAB', name: '', image: '123PVAB.jpg'},
    {value: 'VCB', name: '', image: '123PVCB.jpg'},
    {value: 'VIB', name: '', image: '123PVIB.jpg'},
    {value: 'VPB', name: '', image: '123PVPB.jpg'},
    {value: 'ICB', name: '', image: '123PVTB.jpg'},
  ];

  VISA_LIST = [
    {value: 'VISA', name: '', image: 'visa.png'},
    {value: 'MASTER', name: '', image: 'mastercard.jpg'},
    {value: 'JCB', name: '', image: 'jcb.jpg'},
  ];

  PAYPAL_LIST = [
    {value: 'PAYPAL', name: '', image: 'paypal-mark.jpg'},
  ];
  /**
   * Load order data
   */
  FAKE_ORDER_RESP = {
    "code": 200,
    "data": {
      "_id": "5b22068901060841ccc33e32",
      "amount": 1000000,
      "code": 412,
      "customer_id": "5af67c870106082b7365f38b",
      "customer_info": {
        "address": "6518 Robert Village\nWalkerstad, CA 26857",
        "birthday": null,
        "company": null,
        "email": "dustingonzalez@young.com",
        "fullname": "Jordan Nguyen_D0",
        "id_number": "960671249",
        "phone": "6804969989",
        "website": null
      },
      "customer_name": "Jordan Nguyen_D0",
      "histories": [
        {
          "actor": "customer_D0_1",
          "actor_id": "5af67c870106082b7365f38b",
          "data": {},
          "date": "14/06/2018",
          "message": "Created new record"
        }
      ],
      "modified_date": "14/06/2018",
      "package_info": [
        {
          "_id": "5af67c890106082b7365f590",
          "nDomain": 9,
          "nDuration": 55,
          "name": "Package_D0_17",
          "price": 1000000,
          "service_name": "AntiDDoS Layer 7",
          "time_unit": "day"
        }
      ],
      "packages": [
        {
          "_id": "5af67c890106082b7365f590",
          "name": "Package_D0_17",
          "price": 1000000
        }
      ],
      "payment_status": "paid",
      "salePrice": 0,
      "status": "processing",
      "tempPrice": 1000000
    },
    "jsonrpc": "2.0",
    "message": "OK",
    "notification": {
      "helpdesk": 2,
      "orders": 0,
      "promotions": 0
    },
    "status": true,
    "version": "CLOUD PORTAL v1.0"
  };

  curPaymentCode: any = {};
  packageList = [];
  sub01;

  customer_info: any = {};
  tempPrice;
  salePrice;
  finalPrice;
  dialogRef: MatDialogRef<TourPaymentModalComponent>;
  perfectscroll: PerfectScrollbarDirective;
  initSelectPayment = false;


  constructor(private activatedRoute: ActivatedRoute,
              private orderService: OrderService,
              private cd: ChangeDetectorRef,
              private hs: HopscotchService,
              private router: Router,
              public dialog: MatDialog,
              protected  translate: TranslateService,
  ) {
    this.dialog.closeAll(); // for dev
  }

  ngOnInit() {
    this.sub01 = this.activatedRoute.queryParams.subscribe(params => {
      const step = parseInt(params.step) || 1;
      if (step !== 2) return;

      this.loadOrder(params.order_id);
    });
    this.perfectscroll = window['perfectscroll'];
  }

  ngAfterViewInit() {
    this.dialog.closeAll();
    this.configSteps();
  }

  popupTourPayment(toStep?, reverse?) {
    // this.dialog.closeAll();

    this.dialogRef = this.dialog.open(TourPaymentModalComponent, {
      autoFocus: false,
      width: '95%',
      maxWidth: '95%',
      height: '95%',
      maxHeight: '95%',
      data: {
        paymentType: this.paymentType,
        step: '1',
      },
    });

    let step = 14;
    if (this.paymentType == 'Paypal') {
      step = 12;
    }
    if (toStep) {
      step = toStep;
    }
    if (reverse) {
      if (this.paymentType == 'Paypal') {
        step = 13;
        this.dialogRef.componentInstance.setData({
          paymentType: 'Paypal',
          step: '2',
        });
      } else {
        step = 16;
      }
    }
    setTimeout(() => {
      // console.log('popup payment to step ', step);
      this.hs.step(step - 1); // why hopscotch need this to go to step 12????
      this.hs.step(step);
    }, 300);

    try {
      this.cd.detectChanges();
    } catch (e) {
    }
  }

  public _(k) {
    return this.translate.instant(k);
  }

  configSteps() {
    let steps = AppComponent.getTourSteps(this.router, this.hs, this.translate);
    let steps_override = [
      {
        stepIndex: 9,
        stepDef: {
          onPrev: () => {
            this.hs.step(9);
            this.hs.step(8);
            this.dialog.closeAll();
          },
          onNext: () => {
            this.dialog.closeAll();
            // if (!this.initSelectPayment) {
            //   this.paymentType = "1";
            //   this.onChangePaymentType("1");
            //   this.onSelectBank(this.VISA_LIST[0]);
            //   this.initSelectPayment = true;
            // }
            this.perfectscroll.scrollToBottom();
            this.hs.step(10);
          }
        }
      },
      {
        stepIndex: 10,
        stepDef: {
          onPrev: () => {
            this.perfectscroll.scrollToTop();
            this.hs.step(10);
            this.hs.step(9);
          },
          onNext: () => {
            this.hs.step(11);
          }
        }
      },
      {
        stepIndex: 11,
        stepDef: {
          onPrev: () => {
            this.dialog.closeAll();
            this.hs.step(10);
          },
          onNext: () => {
            this.dialog.closeAll();
            this.popupTourPayment();
          }
        }
      },
      {
        stepIndex: 12,  // paypal 1
        stepDef: {
          onPrev: () => {
            this.dialog.closeAll();
            this.hs.step(11);
          },
          onNext: () => {
            this.dialogRef.componentInstance.setData({
              paymentType: 'Paypal',
              step: '2',
            });
            setTimeout(() => {
              // console.log('next step', 13);
              this.hs.step(12);
              this.hs.step(13);
            }, 300);
          }
        }
      },
      {
        stepIndex: 13,  // paypal 2 - last step
        stepDef: {
          onPrev: () => {
            // console.log('onPrev of 13', this.dialog);
            if (!this.dialogRef) {
              this.dialog.closeAll();
              this.dialogRef = this.dialog.open(TourPaymentModalComponent, {
                autoFocus: false,
                width: '95%',
                maxWidth: '95%',
                height: '95%',
                maxHeight: '95%',
                data: {
                  paymentType: 'Paypal',
                  step: '1',
                },
              });
            } else {
              this.dialogRef.componentInstance.setData({
                paymentType: 'Paypal',
                step: '1',
              });
            }

            setTimeout(() => {
              this.hs.step(11);
              this.hs.step(12);
            }, 300);
          },
          onNext: () => {
            this.dialog.closeAll();
            this.router.navigate(['/c/tourpayflow'], {queryParams: {substep: 3}}).then(() => {
              setTimeout(() => {
                this.hs.step(16);
                this.hs.step(17);
              }, 300);
            });
          }
        }
      },
      {
        stepIndex: 14,  // nganluong
        stepDef: {
          onPrev: () => {
            this.dialog.closeAll();
            this.hs.step(11);
          },
        }
      },
      {
        stepIndex: 16,  // nganluong - last step
        stepDef: {
          onPrev: () => {
          },
          onNext: () => {
            this.dialog.closeAll();
            this.router.navigate(['/c/tourpayflow'], {queryParams: {substep: 3}}).then(() => {
              setTimeout(() => {
                this.hs.step(16);
                this.hs.step(17);
              }, 300);
            });
          }
        }
      },
      {
        stepIndex: 17,  // quanlyhoadon - last step
        stepDef: {
          onPrev: () => {
            const q = {step: 2, order_id: '5b22068901060841ccc33e32'};
            this.router.navigate(['/c/tourpayflow'], {queryParams: q}).then(() => {
              setTimeout(() => {
                this.popupTourPayment(null, true);
              }, 300);
            });
          },
        }
      },
    ];

    for (let step of steps) {
      for (let stepo of steps_override) {
        if (step['stepIndex'] == stepo['stepIndex']) {
          // step = Object.assign({}, step, stepo); oh damn miss function
          if ('onNext' in stepo['stepDef']) {
            step['stepDef']['onNext'] = stepo['stepDef']['onNext'];
          }
          if ('onPrev' in stepo['stepDef']) {
            step['stepDef']['onPrev'] = stepo['stepDef']['onPrev'];
          }
        }
      }
    }

    this.hs.configure(steps);
  }

  loadOrder(order_id) {
    // if (!order_id) return;
    //
    // this.orderService.getOrderItem(order_id).subscribe((resp: any) => {
    //   const data = resp.data;
    //   this.customer_info = data.customer_info;
    //   this.packageList = data.package_info;
    //   this.tempPrice = data.tempPrice;
    //   this.salePrice = data.salePrice;
    //   this.finalPrice = data.amount;
    //   this.cd.detectChanges();
    // });

    const data = this.FAKE_ORDER_RESP.data;
    this.customer_info = data.customer_info;
    this.packageList = data.package_info;
    this.tempPrice = data.tempPrice;
    this.salePrice = data.salePrice;
    this.finalPrice = data.amount;
    this.cd.detectChanges();
  }

  /**
   * Set selected bank
   */
  onSelectBank(item) {
    // clear prev state
    this.curPaymentCode.selected = false;

    // set selected state to current item
    item.selected = true;
    this.curPaymentCode = item;
    this.cd.detectChanges();
  }

  /**
   * Clear selected bank when change payment type
   */
  onChangePaymentType(v) {
    this.paymentType = v;
    this.curPaymentCode.selected = false;
    this.curPaymentCode = {};
    this.configSteps();
    this.cd.detectChanges();
  }

  ngOnDestroy() {
    this.sub01 && this.sub01.unsubscribe();
  }

  /**
   * Update customer info for order
   */
  updateOrderCustomer() {
    // const model: any = {customer_info: this.customer_info};
    // this.orderService.putOrderItem(this.order_id, model)
    //   .subscribe((resp: any) => {
    //     notifySuccess('Thông báo', 'Cập nhật đơn hàng thành công');
    //   });
  }

  /**
   * Toogle export order panel
   */
  toggleExportOrder() {
    this.isExportOrderHidden = !this.isExportOrderHidden;
  }

}
