import {
  Component, OnInit, ViewEncapsulation, ChangeDetectionStrategy,
  ChangeDetectorRef, AfterViewInit
} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {HoverTextSection} from '@angular/language-service';
import {HopscotchService} from '@visc/ngx-hopscotch';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";


@AutoUnsubscribe()
@Component({
  selector: 'tour--payflow',
  templateUrl: './payflow.component.html',
  styleUrls: ['./payflow.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TourPayflowComponent implements OnInit, AfterViewInit {
  step;
  substep;
  order_id;
  sub01;

  headerList = [
    'Đăng ký tài khoản',
    'Chọn dịch vụ',
    'Thanh toán',
  ];

  constructor(private activatedRoute: ActivatedRoute,
              private router: Router,
              private cd: ChangeDetectorRef,
              private hc: HopscotchService,
  ) {
  }

  ngOnInit() {
    this.sub01 = this.activatedRoute.queryParams.subscribe(params => {
      this.step = parseInt(params.step) || 1;
      this.substep = parseInt(params.substep) || 1;
      this.order_id = params.order_id;
      this.cd.markForCheck();
    });
  }

  ngAfterViewInit(): void {
    // console.log('afterviewinit payflow: start tour 0');
    // this.hc.end();
    this.hc.init();
    this.hc.step(0);
  }

  ngOnDestroy() {
    this.sub01 && this.sub01.unsubscribe();

    // console.log('end tour');
    this.hc.end();
  }

  nextStep() {
    this.router.navigate(['/c/tourpayflow'], {queryParams: {step: 1}});
  }

}
