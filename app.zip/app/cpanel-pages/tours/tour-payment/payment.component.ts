import {
  Component,
  Input,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  AfterViewInit,
  OnDestroy
} from '@angular/core';
import {_} from '@fosec/fosec-template-customer';
import {Router} from "@angular/router";
import {Location} from "@angular/common";
import {loadVisJsScript, swalClose, swalShowError, swalShowLoading} from '@common/utils';
import {PaymentService} from '@common/swagger-services';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";

enum PaymentType {
  Visa = 'Visa',
  ATM = 'ATM',
  Paypal = 'Paypal',
}

const PAYPAL_CHECKOUT_JS = 'https://www.paypalobjects.com/api/checkout.js';

/**
 * Handle paypal request.post error
 */
function handlePPError(e) {
  try {
    let msg = e.message || '';
    let idx = msg.indexOf('Correlation id: unknown') + 'Correlation id: unknown'.length;
    let data = msg.slice(idx);
    let json = JSON.parse(data);
    swalShowError('Lỗi', json.message);
  } catch (error) {
    swalShowError('Lỗi', e.message);
  }
}


@AutoUnsubscribe()
@Component({
  selector: 'tour-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush
})
export class TourPaymentComponent implements OnInit, OnDestroy {
  @Input() order_id;
  @Input() showTour = false;
  @Input() free = false;
  @Input() paymentCode;

  mc_flow;
  _paymentType;
  isPaypalButtonInitialized = false;
  PAYMENT_SERVICES = {
    Nganluong: this.payByNganluong3.bind(this),
  };

  constructor(private paymentService: PaymentService,
              private location: Location,
              private router: Router,
              private cd: ChangeDetectorRef,
  ) {
  }

  ngOnInit() {
    // loadVisJsScript(PAYPAL_CHECKOUT_JS);
  }

  ngOnDestroy() {

  }

  /**
   * Load paypal button if needed
   */
  @Input() set paymentType(val) {
    if (val == PaymentType.Paypal) {
      this.initPaypalButton(() => {
        this._paymentType = val;
        this.cd.detectChanges();
      });
    } else {
      this._paymentType = val;
    }
  }

  get paymentType() {
    return this._paymentType;
  }

  onPayClick(btn) {
    // this.showTour = true;

    // const paymentType = 'Nganluong';
    // btn.disabled = true;
    // this.showLoading();
    //
    // this.paymentService.getPayment(this.order_id, paymentType, this.paymentCode, void 0)
    //   .subscribe((resp: any) => {
    //     this.hideLoading();
    //
    //     if (!resp.data.valid) {
    //       btn.disabled = false;
    //       return swalShowError('Lỗi', resp.data.message);
    //     }
    //
    //     let fn = this.PAYMENT_SERVICES[paymentType];
    //     fn && fn(resp.data);
    //   }, err => {
    //     btn.disabled = false;
    //     throw err;
    //   });
  }

  navigate(cmd, opt?) {
    setTimeout(() => this.router.navigate(cmd, opt), 100);
  }

  payByNganluong3(data) {
    setTimeout(() => window.location.href = data.link, 100);
  }

  /**
   * Back to prev step
   */
  goBack() {
    this.location.back();
  }

  /**
   * Init paypal button checkout
   */
  initPaypalButton(cb) {
    this.isPaypalButtonInitialized = true;
    this.showLoading();
    if (this.isPaypalButtonInitialized) {
      cb && cb();
      return;
    }
  }

  /**
   * show loading popup
   */
  showLoading() {
    // swalShowLoading('Đang tải');
  }

  /**
   * hide loading popup
   */
  hideLoading() {
    // swalClose();
  }
}
