export enum Status {
  SUCCESS = 'accepted',
  PROCESSING = 'processing',
  CANCELED = 'canceled',
  REJECTED = 'rejected',
}

export enum PaymentStatus {
  UNPAID = 'unpaid',
  PAID = 'paid',
}