import { Component, OnInit, Input, ChangeDetectorRef, ChangeDetectionStrategy, OnDestroy, Output, EventEmitter } from '@angular/core';
import { Status, PaymentStatus } from '../../constants';
import {OrderService, PaymentService} from "@common/swagger-services";
import {
  _,
  swalClose,
  swalNotiSuccess,
  swalShowConfirm,
  swalShowLoading,
  swalShowWarn
} from '@common/utils';
import { redirectPayflowStep2 } from '../../../payflow/utils';
import {
  Router
} from '@angular/router';
import { AutoUnsubscribe } from "ngx-auto-unsubscribe";


const PAYMENT_TYPE = {
  None: _('Hình thức khác'),
  visa: _('Thẻ tín dụng'),
  atm: _('Chuyển khoản ATM'),
  paypal: _('Paypal'),
  trial: _('Dùng thử'),
};

@AutoUnsubscribe()
@Component({
  selector: 'order-item',
  templateUrl: './order.component.html',
  styleUrls: [ './order.component.scss' ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderComponent implements OnInit, OnDestroy {
  Status = Status;
  PaymentStatus = PaymentStatus;
  @Input() data: any = {};
  isTitleExpanded = false;
  isRated = false;
  payment_type;
  @Output() onDeleteOrder: EventEmitter<any> = new EventEmitter();
  @Output() onReload = new EventEmitter();

  constructor(
    private router: Router,
    private orderService: OrderService,
    private paymentService: PaymentService,
    private cd: ChangeDetectorRef,
  ) {
  }

  ngOnInit() {
    this.isRated = this.data.rating > 0;
    this.payment_type = PAYMENT_TYPE[ this.data.payment_type || 'None' ];
  }

  ngOnDestroy() {

  }

  // TODO: trans
  get title() {
    let names = this.data.service_name_list || [];
    let first = names[ 0 ] || '';
    let remain = names.length - 1;
    if (!this.isTitleExpanded) {
      if (remain <= 0) return first;
      return `${first} và ${remain} sản phẩm khác`;
    } else {
      return names.join(', ');
    }
  }

  get status() {
    return this.data.status;
  }

  get rating() {
    return this.data.rating;
  }

  get payment_status() {
    return this.data.payment_status;
  }

  isTrial() {
    return this.data.type == 'trial';
  }

  onRatingChange(e) {
    this.data.rating = e.rating;
  }

  cancelOrder() {
    swalShowConfirm(_('Hủy đơn hàng'), _('Xác nhận hủy đơn hàng?'), () => {
      swalShowLoading('', 'Đang tải');
      const model: any = {status: 'canceled'};
      this.orderService.putOrderCancel(this.data._id, model).subscribe((resp: any) => {
        swalClose();
        // If cancel ok, server will return 'true', LOL
        let data = (resp && resp.data) || {};
        if (data.status == 'paid') {
          swalShowWarn('Warn', 'Không thể hủy đơn hàng đã được thanh toán');
          this.onReload.emit(true);
        } else if (data.paygate_status === false) {
          swalShowWarn('Warn', 'WARN_PAYGATE_CONNECTION_ERR');
        } else {
          this.data.status = Status.CANCELED;
          this.cd.detectChanges();
        }
      });
    });
  }

  continuePayflow() {
    swalShowLoading('', 'Đang tải');
    this.paymentService.getPaymentStatus(this.data._id).subscribe((resp: any) => {
      swalClose();
      if (resp.data.status == 'paid') {
        swalShowWarn('Warn', 'WARN_PAY_PAID_ORDER');
        this.onReload.emit(true);
      } else if (resp.data.paygate_status === false) {
        swalShowWarn('Warn', 'WARN_PAYGATE_CONNECTION_ERR');
      } else {
        redirectPayflowStep2(this.router, this.data._id);
      }
    });
  }

  setRating() {
    if (this.data.rating) {
      this.isRated = true;
    }
  }

  isTrialOrFree() {
    return this.data && this.data.amount <= 0;
  }

  deleteOrder() {
    swalShowConfirm(_('Xóa đơn hàng'), _('Xác nhận xóa đơn hàng?'), () => {
      this.orderService.deleteOrderItem(this.data._id).subscribe((resp: any) => {
        swalNotiSuccess('Thông báo', _('Đã xóa đơn hàng'));
        this.onDeleteOrder && this.onDeleteOrder.emit(this.data);
        this.cd.detectChanges();
      });
    });
  }
}
