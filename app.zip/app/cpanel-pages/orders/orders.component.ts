import {
  Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, OnDestroy, HostListener
} from '@angular/core';
import { OrderService } from "@common/swagger-services";
import { ClientPermService } from "@common/services";
import { ActivatedRoute, Router } from "@angular/router";
import { Page } from "@common/page";
import { HeaderSidebarService } from '@customer/header-sidebar.service';
import { AutoUnsubscribe } from "ngx-auto-unsubscribe";
import {swalClose, swalShowLoading, utc2local} from '@common/utils';
import {API_BASE_URL} from "@customer/config";
import {Observable} from "rxjs/Observable";
import 'rxjs/add/observable/forkJoin';
import {HttpClient} from "@angular/common/http";
import {isMobileExtension, isTabletExtension} from "@common/utils/mobile";
import { Status } from './constants';

@AutoUnsubscribe()
@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: [ './orders.component.scss' ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrdersComponent implements OnInit, OnDestroy {
  Status = Status;
  orderList = [];
  page = new Page();
  sub01;
  curOffset;

  isMobileExtension = isMobileExtension;
  isTabletExtension = isTabletExtension;

  constructor(private orderService: OrderService,
    private clientPerm: ClientPermService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private cd: ChangeDetectorRef,
    private _headerSidebar: HeaderSidebarService,
    private http: HttpClient,
  ) {
    _headerSidebar.title = 'Quản lý đơn hàng';
    this.orderList = [];
    this.page.size = 8;
    this.page.pageNumber = 0;
  }

  get user() {
    return this.clientPerm.current_user;
  }

  ngOnInit() {
    this.sub01 = this.activatedRoute.queryParams.subscribe(params => {
      let offset = parseInt(params.offset) || 0;
      this.page.pageNumber = offset + 1;
      this.loadOrderList(offset);
    });
  }

  ngOnDestroy() {
    this.sub01 && this.sub01.unsubscribe();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
  }

  /**
   * Load order list from server
   */
  loadOrderList(offset) {
    const u = void 0;
    this.page.pageNumber = offset + 1;
    this.curOffset = offset;
    this.orderService.getGetListByCustomer(u, u, this.page.size, offset)
      .subscribe((resp: any) => {
        let orders = resp.data.rows;
        let total = resp.count;
        this.page.totalElements = total;
        let loadmoreOrder = 0;
        for (let order of orders) {
          if (this.isFormatedOrder(order) && total > this.page.size) {
            loadmoreOrder++;
          }
        }
        if (loadmoreOrder % 2 !== 0) {
          this.orderService.getGetListByCustomer(u, u, 1, this.page.size)
            .subscribe((res: any) => {
              orders.push(res.data.rows[ 0 ]);
              this.orderList = this.formatOrders(orders);
              this.cd.detectChanges();
            });
        } else {
          this.orderList = this.formatOrders(orders);
          this.cd.detectChanges();
        }
        this.checkForUnpaidOrders();
      });
  }

  /**
   * Format orders
   */
  formatOrders(orders) {
    return orders.map(order => {
      order.created_date = utc2local(order.created_date);
      order.modified_date = utc2local(order.modified_date);
      return order;
    });
  }

  isFormatedOrder(order) {
    return order.status === 'processing';
  }

  /**
   * Create new order
   */
  onNewOrder() {
    this.router.navigate([ '/pricelist' ]);
  }

  /**
   * On change page
   */
  changePage(e) {
    const page = e.page;
    const q = { offset: page - 1 };
    this.navigate([ '/c/orders' ], { queryParams: q });
  }

  /**
   * Navigate wrapper
   */
  navigate(url, opt?) {
    setTimeout(() => this.router.navigate(url, opt), 100);
  }

  /**
   * Check if pagination is visible
   */
  isPagerVisible() {
    return (this.page.totalElements / this.page.size) > 1;
  }

  /**
   * Get number of orders
   */
  orderCount() {
    return this.page.totalElements;
  }

  onDeleteOrder(order) {
    // if current page has only one order, then go to prev page after delete
    if (this.orderList.length == 1 && this.page.pageNumber > 1) {
      this.changePage({page: this.page.pageNumber - 1});
    } else {
      // reload current page
      this.loadOrderList(this.page.pageNumber - 1);
    }
  }

  /**
   * Check if unpaid order list has been paid or not
   */
  checkForUnpaidOrders() {
    let tasks = this.orderList
      .filter(v => v.payment_status == 'unpaid' && v.status == 'processing')
      .map(v => {
        let url = `${API_BASE_URL}/payment/status/?order_id=${v._id}`;
        return this.http.get(url);
      });
    if (tasks.length) {
      swalShowLoading('', 'Đang tải');
      Observable.forkJoin(tasks).subscribe((resps: any) => {
        setTimeout(() => swalClose(), 200); // for better animation
        let paid = resps.find(resp => resp.data.status == 'paid');
        if (paid) {
          this.reloadCurrentList();
        }
      });
    }
  }

  reloadCurrentList() {
    this.loadOrderList(this.curOffset);
  }
}
