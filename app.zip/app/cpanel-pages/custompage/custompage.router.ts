import {Routes, RouterModule} from '@angular/router';
import { CustompageComponent } from './custompage.component';

const ROUTER: Routes = [
  {
    path: '',
    component: CustompageComponent
  }
];

export const custompageRouter = RouterModule.forChild(ROUTER);
