import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ChangeDetectorRef
} from '@angular/core';
import {AutoUnsubscribe} from 'ngx-auto-unsubscribe';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { swalNotiSuccess, swalShowError } from "@common/utils";
import { GlobalService } from '../../common/services/global.service';
import { CustomPageService } from '../../common/swagger-services/api/customPage.service';
@AutoUnsubscribe()
@Component({
    selector: 'app-custompage',
    templateUrl: './custompage.component.html',
    styleUrls: ['./custompage.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CustompageComponent implements OnInit, OnDestroy {
    data: any = [];
    constructor(iconRegistry: MatIconRegistry,
        sanitizer: DomSanitizer,
        private cd: ChangeDetectorRef,
        public globalService: GlobalService,
        private customPageService: CustomPageService) {
        iconRegistry.addSvgIcon(
            'icon_help', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/icons/arrow-right.svg'));
        
    }

    ngOnInit() {
        this.getAllCustomPage();
      
    }
    getAllCustomPage() {
        let domain_name ='abc.com'
        this.customPageService.getAllCustomPage(domain_name).subscribe(res => {
            if (res.code == 200) {
                this.data = res.data;
                this.cd.detectChanges();
            }
        },
            error => {
                throw error;
            })
    }
    ngOnDestroy() {
    }
}
