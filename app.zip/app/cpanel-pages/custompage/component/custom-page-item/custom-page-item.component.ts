import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ChangeDetectorRef,
    Input
} from '@angular/core';
import {AutoUnsubscribe} from 'ngx-auto-unsubscribe';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { swalNotiSuccess, swalShowError } from "@common/utils";
import { GlobalService } from '../../../../common/services/global.service';

@AutoUnsubscribe()
@Component({
    selector: 'app-custom-page-item',
    templateUrl: './custom-page-item.component.html',
    styleUrls: ['./custom-page-item.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CustompageItemComponent implements OnInit, OnDestroy {
    @Input() data: any;
    showHelp = false;

    constructor(iconRegistry: MatIconRegistry,
        public sanitizer: DomSanitizer,
        private cd: ChangeDetectorRef,
        public globalService: GlobalService  ) {
        iconRegistry.addSvgIcon(
            'icon_help', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/icons/arrow-right.svg'));
    }

    ngOnInit() {
      
    }
    ngOnDestroy() {
    }

    changeShowHelp() {
        this.showHelp = !this.showHelp;
    }

    getImage(image) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(`data:image/png;base64, ${image}`);
    }

    
}
