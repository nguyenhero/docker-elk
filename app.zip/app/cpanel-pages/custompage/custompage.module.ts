import {NgModule} from '@angular/core';
import {COMMON_MODULES} from '@common/lazyload';
import {custompageRouter} from './custompage.router';
import { CustompageComponent } from './custompage.component';
import { CustompageItemComponent } from './component/custom-page-item/custom-page-item.component';
const MODALS = [];
@NgModule({
    declarations: [
        CustompageComponent,
        CustompageItemComponent
    ],
    imports: [
        ...COMMON_MODULES,
        custompageRouter,
    ],
    entryComponents: [
        ...MODALS,
    ],
    providers: [],
})
export class CustompageModule {
}
