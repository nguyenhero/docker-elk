import {Component, OnDestroy, OnInit} from '@angular/core';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";

@AutoUnsubscribe()
@Component({
  selector: 'attack-monitor-l7',
  templateUrl: './attack-monitor-l7.component.html',
  styleUrls: ['./attack-monitor-l7.component.scss'],

})
export class AttackMonitorL7Component implements OnInit, OnDestroy {

  constructor() { }

  ngOnInit() {
  }

  ngOnDestroy() {

  }
}
