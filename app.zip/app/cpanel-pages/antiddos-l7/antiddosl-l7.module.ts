import {NgModule} from '@angular/core';
import {COMMON_MODULES} from '@common/lazyload';


import { AntiddosL7Router } from './antiddosl-l7.router';
import { AttackLogL7Component } from './component/attack-log-l7/attack-log-l7.component';
import { WebsiteACLComponent } from './component/website-acl/website-acl.component';
import { AttackMonitorL7Component } from './component/attack-monitor-l7/attack-monitor-l7.component';
import { AttackTypeConfigL7Component } from './component/attack-type-config-l7/attack-type-config-l7.component';
import { URIACLComponent } from './component/website-acl/uri-acl/uri-acl.component';
import { IPACLComponent } from './component/website-acl/ip-acl/ip-acl.component';
const MODALS = [];
@NgModule({
    declarations: [
        AttackLogL7Component, 
        WebsiteACLComponent,
        AttackMonitorL7Component,
        AttackTypeConfigL7Component,
        URIACLComponent,
        IPACLComponent,
    ],
    imports: [
        ...COMMON_MODULES,
        AntiddosL7Router,
    ],
    entryComponents: [
        ...MODALS,
    ],
    providers: [],
})
export class AntiddosL7Module {
}
