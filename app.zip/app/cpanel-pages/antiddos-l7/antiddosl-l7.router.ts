import {Routes, RouterModule} from '@angular/router';
import { AttackMonitorL7Component } from './component/attack-monitor-l7/attack-monitor-l7.component';
import { AttackLogL7Component } from './component/attack-log-l7/attack-log-l7.component';
import { WebsiteACLComponent } from './component/website-acl/website-acl.component';
import { AttackTypeConfigL7Component } from './component/attack-type-config-l7/attack-type-config-l7.component';



const ROUTER: Routes = [
  {
    path: 'attack-mon',
    component: AttackMonitorL7Component
  },
  {
    path: 'attack-log',
    component: AttackLogL7Component
  },
  {
    path: 'website-acl',
    component: WebsiteACLComponent
  },
  {
    path: 'attack-type-config',
    component: AttackTypeConfigL7Component
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'attack-mon',
  },
];

export const AntiddosL7Router = RouterModule.forChild(ROUTER);
