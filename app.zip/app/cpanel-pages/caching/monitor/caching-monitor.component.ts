import { SeriesUtils } from './../../../../../../../libs/visc-template/src/utils/series';
import { moment } from '@visc/visc-template';
import { mulChart } from '@customer/cpanel-pages/antiddos/l4-monitoring/share-module/multiple-line-chart/multiple-line-chart.component';
import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ChangeDetectorRef,
} from '@angular/core';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { TranslateService } from '@ngx-translate/core';
import { GlobalService } from '../../../common/services/global.service';
@AutoUnsubscribe()
@Component({
    selector: 'app-caching-monitor',
    templateUrl: './caching-monitor.component.html',
    styleUrls: ['./caching-monitor.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CachingMonitorComponent implements OnInit, OnDestroy {

    cacheFile = {
        total: 0,
        html: 0,
        js: 0,
        css: 0,
        image: 0
    };
    cacheSize = {
        total: 0,
        html: 0,
        js: 0,
        css: 0,
        image: 0

    };
    cacheOps = {
        total: 0,
        html: 0,
        js: 0,
        css: 0,
        image: 0

    };

    cachingsChart: any;
    selectedIndex = 1;
    selectedDuration = 1;
    startDate: Date = new Date();
    endDate: Date = new Date();
    constructor(
        private cd: ChangeDetectorRef,
        private translate: TranslateService,
        public globalService: GlobalService,
    ) {
        this.globalService.notifyObservable$.subscribe(resp => {
            if (resp && resp.selected_domain) {
                // TODO: add search
                this.search();
            }
        });
    }

    ngOnInit() {
        let CLOUDRITY_CONST = JSON.parse(this.globalService.getItem("CLOUDRITY_CONST"));
        if (CLOUDRITY_CONST && CLOUDRITY_CONST.selected_domain) {
            // TODO: add search
            this.search();
        }
    }
    ngOnDestroy() {
    }
    search(event?) {
        if (event) {
            this.startDate = event.start;
            this.endDate = event.end;
        }

        let time_from = SeriesUtils.startDateToUTC(this.startDate);
        let time_to = SeriesUtils.endDateToUTC(this.endDate);

        this.getChartData(time_from, time_to);
    }

    getChartData(time_from, time_to) {
        this.cachingsChart = this.getChart();
        // call service
        let data = [];
        for (let index = 0; index < 24; index++) {
            let cache_out = Math.floor(Math.random() * 1000);
            let out = cache_out + Math.floor(Math.random() * 1000);
            let model = {
                ts: moment("2020/25/08").add(-index, 'hours').format('YYYY-MM-DD hh:mm:ss'),
                cache_out,
                out
            };
            data.unshift(model);
        }

        data = data.map(d => {
            return {
                data: { cache_out: d['cache_out'], out: d['out'] },
                date: moment(d['ts']).toDate(),
            };
        });
        this.cachingsChart = this.getChart(data);
        this.getRealTime();
    }
    getChart(data?) {
        data = (data === undefined) ? [] : data;
        return new mulChart(
            data,
            'Cache statistic',
            ['cache_out', 'out'],
            'cache_statistic',
            ['Cache Throughtput', 'Total Output'],
            '',
            2,
            false,
            false,
            false,
            true,
            { equalSpacing: false },
        );
    }
    getRealTime() {
        let html, js, css, image, total;
        html = Math.floor(Math.random() * 1000);
        js = Math.floor(Math.random() * 1000);
        css = Math.floor(Math.random() * 1000);
        image = Math.floor(Math.random() * 1000);
        total = html + js + css + image;
        this.cacheFile = {
            total,
            html,
            js,
            css,
            image,
        };
        html = Math.floor(Math.random() * 1000);
        js = Math.floor(Math.random() * 1000);
        css = Math.floor(Math.random() * 1000);
        image = Math.floor(Math.random() * 1000);
        total = html + js + css + image;
        this.cacheSize = {
            total,
            html,
            js,
            css,
            image,
        };
        html = Math.floor(Math.random() * 1000);
        js = Math.floor(Math.random() * 1000);
        css = Math.floor(Math.random() * 1000);
        image = Math.floor(Math.random() * 1000);
        total = html + js + css + image;
        this.cacheOps = {
            total,
            html,
            js,
            css,
            image,
        };
    }
}
