import { swalNotiSuccess } from '@common/utils';
import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ChangeDetectorRef,
} from '@angular/core';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { TranslateService } from '@ngx-translate/core';
import { GlobalService } from '../../../common/services/global.service';
import { DomainService } from '../../../common/swagger-services/api/api';
@AutoUnsubscribe()
@Component({
    selector: 'app-caching-config',
    templateUrl: './caching-config.component.html',
    styleUrls: ['./caching-config.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CachingConfigComponent implements OnInit, OnDestroy {
    isConfigCache = false;
    cacheTimeOut = 1;
    isHtml = false;
    isJs = false;
    isCss = false;
    isImage = false;

    html = {
        size: 1,
        file: 1,
        ops: 1,
    };
    js = {
        size: 1,
        file: 1,
        ops: 1,
    };
    css = {
        size: 1,
        file: 1,
        ops: 1,
    };
    image = {
        size: 1,
        file: 1,
        ops: 1,
    };

    currentId;
    currentDomain;
    isFirstLoad = true;
    isProcessing = false;
    constructor(
        private cd: ChangeDetectorRef,
        private translate: TranslateService,
        public domainService: DomainService,
        public globalService: GlobalService,
    ) {
        this.globalService.notifyObservable$.subscribe(resp => {
            if (resp && resp.selected_domain) {
                this.loadCurrentConfig(resp.selected_domain.identity);
            }
        });
    }

    ngOnInit() {
        let CLOUDRITY_CONST = JSON.parse(this.globalService.getItem("CLOUDRITY_CONST"));
        if (CLOUDRITY_CONST && CLOUDRITY_CONST.selected_domain) {
            this.loadCurrentConfig(CLOUDRITY_CONST.selected_domain.identity);
        }
    }

    loadCurrentConfig(domain) {
        this.domainService.getDomainItem(domain).subscribe(resp => {
            if (resp.data) {
                // set data
                this.currentId = resp.data._id;
            } else {
                // set default
                this.currentId = null;
            }
            this.currentDomain = domain;
            this.isFirstLoad = false;
            this.cd.detectChanges();
        },
            err => {
                console.log("get error", err);
                return;
            });
    }
    ngOnDestroy() {
    }
    toggleImage() {
        this.isImage = !this.isImage;
        //set default
        this.image = {
            size: 1,
            file: 1,
            ops: 1,
        };
    }
    toggleJs() {
        this.isJs = !this.isJs;
        //set default
        this.js = {
            size: 1,
            file: 1,
            ops: 1,
        };
    }
    toggleCss() {
        this.isCss = !this.isCss;
        //set default
        this.css = {
            size: 1,
            file: 1,
            ops: 1,
        };
    }
    toggleHtml() {
        this.isHtml = !this.isHtml;
        //set default
        this.html = {
            size: 1,
            file: 1,
            ops: 1,
        };
    }
    updateConfig(formSave?) {
        if (!formSave) {
            return;
        }
        if (this.isFirstLoad) {
            return;
        }
        if (!this.currentDomain) {
            return;
        }
        if (!this.currentId) {
            const payload = {
                // put pay load
            };
            this.domainService.postDomainList(payload
            ).subscribe(resp => {
                if (resp.data) {

                    this.currentId = resp.data;
                    swalNotiSuccess('Thông báo', 'Cập nhật thành công');
                }
            },
                err => {
                    console.log("get error", err);
                    return;
                });
        } else {
            const payload = {
                // put pay load
            };
            this.domainService.putDomainItem(this.currentId, payload
            ).subscribe(resp => {
                if (resp.data) {
                    this.currentId = resp.data;
                    swalNotiSuccess('Thông báo', 'Cập nhật thành công');
                }
            },
                err => {
                    console.log("get error", err);
                    return;
                });
        }
    }
}
