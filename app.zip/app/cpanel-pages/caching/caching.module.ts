import {NgModule} from '@angular/core';
import {COMMON_MODULES} from '@common/lazyload';
import {cachingRouter} from './caching.router';
import { CachingMonitorComponent } from './monitor/caching-monitor.component';
import { CachingConfigComponent } from './config/caching-config.component';
import { ShareModule } from '../antiddos/l4-monitoring/share-module/share-module';
const MODALS = [];
@NgModule({
    declarations: [
        CachingMonitorComponent,
        CachingConfigComponent,
    ],
    imports: [
        ...COMMON_MODULES,
        ShareModule,
        cachingRouter,
    ],
    entryComponents: [
        ...MODALS,
    ],
    providers: [],
})
export class CachingModule {
}
