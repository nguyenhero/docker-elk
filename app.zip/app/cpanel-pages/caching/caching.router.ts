import {Routes, RouterModule} from '@angular/router';
import { CachingMonitorComponent } from './monitor/caching-monitor.component';
import { CachingConfigComponent } from './config/caching-config.component';

const ROUTER: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'monitor',
  },
  {
    path: 'monitor',
    component: CachingMonitorComponent
  },
  {
    path: 'config',
    component: CachingConfigComponent
  }
];

export const cachingRouter = RouterModule.forChild(ROUTER);
