import {ChangeDetectorRef, Component, Input, OnInit} from '@angular/core';
import {QcBaseComponent} from "../base/base.component";
import {COMMA, ENTER} from "@angular/cdk/keycodes";
import {HttpClient} from "@angular/common/http";
import {FormBuilder, Validators} from "@angular/forms";
import {AbstractControl} from "@angular/forms/src/model";
import {TranslateService} from "@ngx-translate/core";
import {swalShowError} from "@common/utils";
import {DomainValidator, DomainPortValidator} from "@common/validators/validators";
import {Observable} from "rxjs/Rx";
import {API_BASE_URL} from '@customer/config';
import {MyValidators} from "@common/validate";
import {validateCertFile, validateKeyFile} from "@customer/cpanel-pages/waf/constants";


/**
 * Validator for sub domains list
 */
function subDomainsValidator(control: AbstractControl) {
  const REGEX = /^\s*([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+([A-Za-z]{2,6}|[A-Za-z0-9-]{2,})\s*$/;
  if (!control.value) return;
  let subDomains = control.value.trim().split(',').map(v => v.trim());
  for (let domain of subDomains) {
    if (!REGEX.test(domain)) {
      return {pattern: true};
    }
  }
  return null;
}

class PortModel {
  _id?: any;
  checked?: boolean;
  port?: number;
  https?: boolean;
  // protocol?: string;
  cert_content?: any;
  cert?: any; // https cert file
  cert_name?: any;
  key_content?: any;
  key?: any; // https key file
  key_name?: any;

  constructor() {
    this._id = new Date().getTime();
  }
}

class DomainModel {
  _id: any;
  domain?: string;
  subdomain?: string;
  ports: PortModel[];
  vWebProgLang?: string;
  vQueryDataLang?: string;
  vWebServer?: string;
  vFramework?: string;
  ynUseFirewall?: boolean;
  vUseFirewall?: string;
  ynLimitSrcIP: boolean;
  ynLimitRateCreateConnSrcIP?: boolean;
  vLimitRateCreateConnSrcIP?: string;
  ynLimitConcurentConnSrcIP?: boolean;
  vLimitConcurentConnSrcIP?: string;
  ynUseIPClient?: boolean;
  ynWhitelistBot?: boolean;
  vWhitelistBot?: string;
  ynAllow3rdSearch?: boolean;
  vAllow3rdSearch?: string;
  ynWhitelistIP?: boolean;
  ynAllowAccessURI?: boolean;
  vAllowAccessURI?: string;
  ynRequestURI?: boolean;
  vRequestURI?: string;
  ynUseLB?: boolean;
  vLBAlgorithm?: string;
  vLBLayer?: string;
  ynUseCacheStatic?: boolean;
  vMaxRps?: string;
  vMaxCps?: string;
  vMaxBps?: string;
  ynIsAttackBefore?: boolean;
  IPsType?: string;
  IPs?: string[];
  IPsLB?: string[];

  constructor() {
    this._id = new Date().getTime();
    this.IPsType = 'web';
    this.ynUseFirewall = false;
    this.ynLimitSrcIP = false;
    this.ynLimitRateCreateConnSrcIP = false;
    this.ynLimitConcurentConnSrcIP = false;
    this.ynUseIPClient = false;
    this.ynWhitelistBot = false;
    this.ynAllow3rdSearch = false;
    this.ynWhitelistIP = false;
    this.ynAllowAccessURI = false;
    this.ynRequestURI = false;
    this.ynUseLB = false;
    this.ynUseCacheStatic = false;
    this.ynIsAttackBefore = false;
    this.vLBLayer = "Layer 7";
    this.IPs = [];
    this.IPsLB = [];
  }

  /**
   * Get all valid ports
   */
  get selectedPorts() {
    return this.ports.filter(p => {
      return p.checked && (!p.https || (p.https && p.cert && p.key));
    });
  }
}

@Component({
  selector: 'qc-base-domain',
  templateUrl: './add-domain.component.html',
  styleUrls: ['./add-domain.component.scss']
})
export class BaseDomainComponent extends QcBaseComponent implements OnInit {
  model: DomainModel;
  HTTP = 'http';
  HTTPS = 'https';
  isShowAdvView = false;
  YES = true;
  NO = false;

  curPort: PortModel;
  isShowAddPortView = false;

  readonly separatorKeysCodes: number[] = [ENTER];

  // form controls
  domainControl = this.fb.control('', [MyValidators.required, MyValidators.domain], [this.asyncValidateDomain.bind(this)])
  subdomainFC = this.fb.control('', [subDomainsValidator]);
  ipsFC = this.fb.control('');
  portControl = this.fb.control('', [MyValidators.required, MyValidators.port]);

  constructor(public http: HttpClient,
              public fb: FormBuilder,
              public translate: TranslateService,
              public cd: ChangeDetectorRef) {
    super();
  }

  ngOnInit() {
  }

  onClickShowAddPort() {
    if (this.isShowAddPortView) return;
    this.curPort = new PortModel();
    this.portControl.reset();
    this.isShowAddPortView = true;
  }

  onClickAddPort() {
    this.curPort.checked = true;
    this.curPort.port = this.portControl.value.trim();
    this.model.ports.push(this.curPort);
    this.isShowAddPortView = false;
  }

  onCurCertFileChange(event) {
    if (event.target.files.length > 0) {
      this.readCertFile(this.curPort, event.target.files[0]);
    }
  }

  onCurKeyFileChange(event) {
    if (event.target.files.length > 0) {
      this.readKeyFile(this.curPort, event.target.files[0]);
    }
  }

  onCertFileChange(item: PortModel, event) {
    // console.log('onCertFileChange', item, event);
    if (event.target.files.length > 0) {
      this.readCertFile(item, event.target.files[0]);
    }
  }

  onKeyFileChange(item: PortModel, event) {
    // console.log('onKeyFileChange', item, event);
    if (event.target.files.length > 0) {
      this.readKeyFile(item, event.target.files[0]);
    }
  }

  readCertFile(item, file) {
    // console.log('readCertFile', item, file);
    let fileName = file.name;
    let err = validateCertFile(fileName, file.size);
    if (!err) {
        this.readFile(file).then((text: any) => {
            text = text.replace(/[^\x00-\x7F]/g, "");
            item.cert = file;
            item.cert_content = text;
            item.cert_name = fileName;
        }, err2 => {
          swalShowError('ERROR', err2);
        });
    } else {
        swalShowError('ERROR', err);
    }
  }

  readKeyFile(item, file) {
    // console.log('readKeyFile', item, file);
    let fileName = file.name;
    let err = validateKeyFile(fileName, file.size);
    if (!err) {
        this.readFile(file).then((text: any) => {
            text = text.replace(/[^\x00-\x7F]/g, "");
            item.key = file;
            item.key_content = text;
            item.key_name = fileName;
        }, err2 => {
          swalShowError('ERROR', err2);
        });
    } else {
        swalShowError('ERROR', err);
    }
  }

  onClickUploadCert(item) {
    let el = document.getElementById('input_cert_' + item._id);
    if (el) el.click();
  }

  onClickUploadKey(item) {
    let el = document.getElementById('input_key_' + item._id);
    if (el) el.click();
  }

  isInvalidIPs() {
    const REGEX = /^\s*([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])\.([1-9]?\d|1\d\d|2[0-4]\d|25[0-5])(\/([1-9]|[1-2][0-9]*|3[0-2]*)){0,1}\s*$/;
    let ips = this.model.IPs || [];
    if (ips.length <= 0) return false;
    for (let ip of ips) {
      if (!REGEX.test(ip)) {
        return true;
      }
    }
    return false;
  }

  isInvalidPorts() {
    let ports = (this.model && this.model.ports) || [];
    ports = ports.filter(p => p.checked);
    if (ports.length <= 0) return true;
    for (let port of ports) {
      if (port.https) {
        if (!port.cert_name || !port.key_name) {
          return true;
        }
      }
    }
    return false;
  }

  isEmptyPorts() {
    let ports = (this.model && this.model.ports) || [];
    ports = ports.filter(p => p.checked);
    if (ports.length <= 0) return true;
  }

  removeIPsWeb(item) {
    const index = this.model.IPs.indexOf(item);

    if (index >= 0) {
      this.model.IPs.splice(index, 1);
    }
  }

  addIPsWeb(event) {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      if (this.model.IPs.indexOf(value) == -1) {
        this.model.IPs.push(value);
      }
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.ipsFC.setValue('');
  }

  /**
   * Read file
   * @param file: File object
   * @param sizeLimit: size in bytes
   */
  readFile(file, sizeLimit?) {
    return new Promise((resolve, reject) => {
      sizeLimit = sizeLimit || 1024 * 1024; // 1MB
      if (file.size <= 0) {
        reject('WARN_UPLOAD_EMPTY_FILE');
      }
      if (file.size > sizeLimit) {
        reject('Maximum upload size is 1MB');
      }
      let reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.readAsText(file);
    });
  }

  getModel() {
    let model: any = {...this.model};

    // get domain from form control
    model.domain = this.domainControl.value;

    // remove port is not checked
    model.ports = model.ports.filter(p => p.checked);

    // cast as int
    let keys = ['vLimitConcurentConnSrcIP', 'vMaxBps', 'vMaxCps', 'vMaxRps'];
    for (let k of keys) {
      if (model[k] != null) {
        model[k] = parseInt(model[k]) || undefined;
      }
    }

    // trim any string value
    for (let k of Object.keys(model)) {
      if (typeof model[k] == 'string') {
        model[k] = model[k].trim();
      }
    }

    return model;
  }

  loadData() {
    let model = this.model;

    // load domain name
    this.domainControl.setValue(model.domain);

    // set all ports as checked
    model.ports.forEach(p => p.checked = true);

    // sort ports as ASC
    model.ports.sort((a, b) => a.port - b.port);
  }

  onClickConfirm() {
    let model = this.getModel();
    // console.log(model);
    this.onConfirm.emit(model);
  }

  asyncValidateDomain(c: AbstractControl): Observable<{ [key: string]: any }> {
    let body = {value: c.value.trim()};
    let url = API_BASE_URL + `/cs-unit/validate_name/`;
    return this.http.post(url, body).map((resp: any) => {
      let err = resp.data.valid ? null : {exist: true};

      // force change immediately
      c.setErrors(err);
      this.cd.detectChanges();

      return err;
    });
  }

  validatePort(c: AbstractControl): any {
    let ports = (this.model && this.model.ports) || [];
    for (let port of ports) {
      if (port.port == (c.value || '').trim()) {
        return {exist: true};
      }
    }
    return null;
  }

  onChangePort(item: PortModel) {
    if (item.port == 80) {
      item.https = false;
    } else if (item.port == 443) {
      item.https = true;
    }
  }

  getPortTitle(port) {
    if (port == 80) {
      return 'port_http_required';
    } else if (port == 443) {
      return 'port_https_required';
    }
  }
}

@Component({
  selector: 'qc-add-domain',
  templateUrl: './add-domain.component.html',
  styleUrls: ['./add-domain.component.scss']
})
export class AddDomainComponent extends BaseDomainComponent implements OnInit {
  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.model = new DomainModel();
    this.model.ports = [
      {_id: 1, port: 80, https: false, checked: true},
    ];
  }
}

@Component({
  selector: 'qc-edit-domain',
  templateUrl: './add-domain.component.html',
  styleUrls: ['./add-domain.component.scss']
})
export class EditDomainComponent extends BaseDomainComponent implements OnInit {
  @Input() model;

  ngOnInit() {
    this.loadData();
  }
}
