import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {QcBaseComponent} from "../base/base.component";

@Component({
  selector: 'qc-domain-manager',
  templateUrl: './domain-manager.component.html',
  styleUrls: ['./domain-manager.component.scss']
})
export class DomainManagerComponent extends QcBaseComponent implements OnInit {
  @Input() serviceName;
  MANAGE_MODE = 'mange';
  ADD_MODE = 'add';
  EDIT_MODE = 'edit';
  mode = this.MANAGE_MODE;

  model = {
    domainList: [],
  };
  curItem = {}; // for editing
  @Output() onAdd = new EventEmitter();

  constructor() {
    super();
  }

  ngOnInit() {
  }

  onClickAdd() {
    this.mode = this.ADD_MODE;
    this.onAdd.emit('onClickAdd');
  }

  onAddItem(item) {
    console.log('added item', item);
    this.model.domainList.push(item);
    this.model.domainList = [...this.model.domainList]; // detect changes
    this.mode = this.MANAGE_MODE;
    // notify added item here
  }

  onClickEdit(item) {
    this.curItem = item;
    this.mode = this.EDIT_MODE;
  }

  onEditedItem(item) {
    let dl = this.model.domainList;
    let idx = dl.map(i => i._id).indexOf(item._id);
    if (idx != -1) {
      dl[idx] = item;
    }
    this.model.domainList = [...dl]; // detect changes
    this.mode = this.MANAGE_MODE;
    // notify edited item here
  }

  onClickDel(item) {
    this.model.domainList = this.model.domainList.filter(i => i._id != item._id);
    // notify deleted item here
  }

  onClickConfirm() {
    this.onConfirm.emit(this.model);
  }
}
