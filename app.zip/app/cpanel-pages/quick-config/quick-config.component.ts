import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'qc-quick-config',
  templateUrl: './quick-config.component.html',
  styleUrls: ['./quick-config.component.scss']
})
export class QuickConfigComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
