import {ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {MatDialog} from "@angular/material";
import {FlowComponent} from "../flow/flow.component";
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";
import {Router} from "@angular/router";
import {OrderService} from "@common/swagger-services";
import { TranslateService } from "@ngx-translate/core";

@AutoUnsubscribe()
@Component({
    selector: 'qc-start-now',
    templateUrl: './start-now.component.html',
    styleUrls: ['./start-now.component.scss']
})
export class StartNowComponent implements OnInit, OnDestroy {
    @Output() finish = new EventEmitter();
    @Input() isBought = false;
    sub01;

    constructor(public dialog: MatDialog,
                public router: Router,
                public orderService: OrderService,
                public translate: TranslateService,
                public cd: ChangeDetectorRef) {
    }

    ngOnInit() {
    }

    onClickStartNow() {
        let dialog = this.dialog.open(FlowComponent, {
            width: 'auto',
            minWidth: '310px',
            height: 'auto',
            maxWidth: '100%',
            maxHeight: '85%',
            disableClose: true
        });
        this.sub01 = dialog.afterClosed().subscribe((completed: any) => {
            // console.log('afterClosed', completed);
            if (completed) {
                this.finish.emit(true);
            }
        });
    }

    ngOnDestroy() {

    }

    buyNow() {
        this.router.navigate(['/pricelist']);
    }
}
