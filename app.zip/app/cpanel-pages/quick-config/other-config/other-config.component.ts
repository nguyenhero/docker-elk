import {Component, Input, OnInit} from '@angular/core';
import {QcBaseComponent} from "../base/base.component";

@Component({
  selector: 'qc-other-config',
  templateUrl: './other-config.component.html',
  styleUrls: ['./other-config.component.scss']
})
export class OtherConfigComponent extends QcBaseComponent implements OnInit {
  @Input() serviceName;
  @Input() model = {
    toggle_telegram: false,
    toggle_email: false,
    report_duration: 2,
  };
  report_duration_label;
  @Input() reportDurations = [];
  labelMap = {};
  @Input() isConfirmDisabled = false;

  constructor() {
    super();
  }

  ngOnInit() {
    for (let d of this.reportDurations) {
      this.labelMap[d.value] = d.text;
    }

    this.report_duration_label = this.labelMap[this.model.report_duration]; // TODO: remove
  }

  toggleTelegram() {
    // console.log('toggle telegram');
    this.model.toggle_telegram = !this.model.toggle_telegram;
    // this.customerNoticeService.postCustomerNotice({
    //   customer_id: this.cur_user.user_id,
    //   type: 'toggle_telegram',
    //   value: this.model.toggle_telegram
    // }).subscribe(resp => {
    //   if (resp.data.valid) {
    //     swalNotiSuccess(_('Thông báo'), _('Status changed successfully'));
    //     if (resp.data.can_on_telegram != undefined) {
    //       this.model.toggle_telegram = false;
    //       swalShowWarn(_('Cảnh báo'), _('telegram_can_not_on_warn'));
    //     }
    //   } else {
    //     swalShowError(_('Lỗi'), _('Có lỗi xảy ra'));
    //   }
    // });
  }

  toggleEmail() {
    // console.log('toggle email');
    this.model.toggle_email = !this.model.toggle_email;
    // this.customerNoticeService.postCustomerNotice({
    //   customer_id: this.cur_user.user_id,
    //   type: 'toggle_email',
    //   value: this.model.toggle_email
    // }).subscribe(resp => {
    //   if (resp.data.valid) {
    //     swalNotiSuccess(_('Thông báo'), _('Status changed successfully'));
    //   } else {
    //     swalShowError(_('Lỗi'), _('Có lỗi xảy ra'));
    //   }
    // });
  }

  changeReportDuration(event) {
    // console.log('change report duration');
    // console.log(event);
    this.model.report_duration = event.value;
    this.report_duration_label = this.labelMap[this.model.report_duration] || '';
    // this.customerNoticeService.postCustomerChangeReportSchedule({
    //   customer_id: this.cur_user.user_id,
    //   value: this.model.report_duration
    // }).subscribe(resp => {
    //   if (resp.data.valid) {
    //     swalNotiSuccess(_('Thông báo'), _('Status changed successfully'));
    //   } else {
    //     swalShowError(_('Lỗi'), _('Có lỗi xảy ra'));
    //   }
    // });
  }

  onClickConfirm() {
    this.onConfirm.emit(this.model);
  }
}
