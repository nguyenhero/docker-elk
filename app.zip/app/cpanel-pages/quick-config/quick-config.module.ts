import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {SelectServiceComponent} from './select-service/select-service.component';
import {StartNowComponent} from './start-now/start-now.component';
import {StartNowPopupComponent} from './start-now-popup/start-now-popup.component';
import {QcBaseComponent} from './base/base.component';
import {AddDomainComponent, BaseDomainComponent, EditDomainComponent} from './add-domain/add-domain.component';
import {OtherConfigComponent} from './other-config/other-config.component';
import {FinishNoServiceComponent} from './finish-no-service/finish-no-service.component';
import {FinishCompletedComponent} from './finish-completed/finish-completed.component';
import {DomainManagerComponent} from './domain-manager/domain-manager.component';
import {COMMON_MODULES} from "@common/lazyload";
import {FlowComponent} from "./flow/flow.component";
import {LayoutComponent} from "./layout/layout.component";
import {QuickConfigComponent} from "./quick-config.component";

@NgModule({
  declarations: [
    QuickConfigComponent,
    SelectServiceComponent,
    StartNowComponent,
    StartNowPopupComponent,
    QcBaseComponent,
    BaseDomainComponent,
    AddDomainComponent,
    EditDomainComponent,
    OtherConfigComponent,
    FinishNoServiceComponent,
    FinishCompletedComponent,
    DomainManagerComponent,
    FlowComponent,
    LayoutComponent,
  ],
  imports: [
    CommonModule,
    ...COMMON_MODULES,
  ],
  entryComponents: [
    FlowComponent,
  ],
  exports: [
    QuickConfigComponent,
    SelectServiceComponent,
    StartNowComponent,
    StartNowPopupComponent,
    QcBaseComponent,
    BaseDomainComponent,
    AddDomainComponent,
    EditDomainComponent,
    OtherConfigComponent,
    FinishNoServiceComponent,
    FinishCompletedComponent,
    DomainManagerComponent,
    FlowComponent,
    LayoutComponent,
  ]
})
export class QuickConfigModule {
}
