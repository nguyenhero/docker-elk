import {Component, Input, OnInit} from '@angular/core';
import {QcBaseComponent} from "../base/base.component";

@Component({
  selector: 'qc-finish-completed',
  templateUrl: './finish-completed.component.html',
  styleUrls: ['./finish-completed.component.scss']
})
export class FinishCompletedComponent extends QcBaseComponent implements OnInit {
  @Input() ticketName;
  constructor() {
    super();
  }

  ngOnInit() {
  }

}
