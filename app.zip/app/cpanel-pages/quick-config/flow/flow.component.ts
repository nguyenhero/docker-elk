import {Component, OnInit, ViewChild} from '@angular/core';
import {MatDialogRef} from "@angular/material";
import {HttpClient} from "@angular/common/http";
import {Router} from "@angular/router";
import {API_BASE_URL} from "@customer/config";

@Component({
  selector: 'qc-flow',
  templateUrl: './flow.component.html',
  styleUrls: ['./flow.component.scss']
})
export class FlowComponent implements OnInit {
  SELECT_SERVICE_STEP = 0;
  ADD_DOMAIN_STEP = 1;
  EDIT_DOMAIN_STEP = 10;
  OTHER_CONFIG_STEP = 2;
  FINISH_OK_STEP = 3;
  FINISH_OOPS_STEP = 4;
  step = this.SELECT_SERVICE_STEP;
  domainModel;
  configModel;
  serviceModel;
  ticketName;
  editDomainModel;
  reportDurations = [];
  isOtherConfigConfirmDisabled = false;

  constructor(public dialogRef: MatDialogRef<FlowComponent>,
              public router: Router,
              public http: HttpClient) {
  }

  ngOnInit() {

  }

  close(result?) {
    if (this.step == this.FINISH_OK_STEP) {
      result = true;
    }
    this.dialogRef.close(result);
  }

  onSelectServiceOK(model) {
    this.serviceModel = model || {};
    let url = API_BASE_URL + '/quick_config/setup/?service_id=WebProtection';
    this.http.get(url).subscribe((resp: any) => {
      this.reportDurations = resp.data.report_durations || [];
      this.configModel = {
        toggle_telegram: false,
        toggle_email: false,
        report_duration: 2,
      };
      this.step = this.ADD_DOMAIN_STEP;
    });
  }

  onAddDomainOK(model) {
    // console.log('onAddDomainOK', model);
    this.domainModel = {domainList: [model]};
    this.step = this.OTHER_CONFIG_STEP;
  }

  onEditDomainOK(model) {
    // console.log('onEditDomainOK', model);
    this.domainModel = {domainList: [model]};
    this.step = this.OTHER_CONFIG_STEP;
  }

  /**
   * Check if user has brought service or not
   */
  onOtherConfigOK(model) {
    this.isOtherConfigConfirmDisabled = true;
    this.configModel = model;
    // console.log(this.domainModel);
    // console.log(this.configModel);
    let url = API_BASE_URL + '/quick_config/setup/';
    let body: any = {
      service_id: this.serviceModel._id,
      ...this.domainModel,
      ...this.configModel,
    };
    this.http.post(url, body).subscribe((resp: any) => {
      let data: any = resp.data || {};
      let bought = data.bought;
      this.ticketName = data.ticketName;
      if (bought) {
        this.step = this.FINISH_OK_STEP;
      } else {
        this.step = this.FINISH_OOPS_STEP;
      }
    }, err => {
      this.isOtherConfigConfirmDisabled = false;
      throw err;
    });
  }

  onBuyNow() {
    this.close();

    setTimeout(() => this.router.navigate(['/pricelist']), 200);
  }
}
