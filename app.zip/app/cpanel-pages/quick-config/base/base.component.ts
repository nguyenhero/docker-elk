import {Component, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'qc-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.scss']
})
export class QcBaseComponent {
  @Output() onCancel = new EventEmitter();
  @Output() onConfirm = new EventEmitter();

  onClickCancel() {
    this.onCancel.emit('onClickCancel');
  }

  onClickConfirm() {
    this.onConfirm.emit('onClickConfirm');
  }
}
