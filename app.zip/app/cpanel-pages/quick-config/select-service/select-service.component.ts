import {Component, OnInit} from '@angular/core';
import {QcBaseComponent} from "../base/base.component";
import {HttpClient} from "@angular/common/http";
import {API_BASE_URL} from "@customer/config";

@Component({
  selector: 'qc-select-service',
  templateUrl: './select-service.component.html',
  styleUrls: ['./select-service.component.scss']
})
export class SelectServiceComponent extends QcBaseComponent implements OnInit {
  model = {};
  serviceList = [
    // {
    //   _id: '1',
    //   name: 'Web protection',
    //   description: 'Lorem ipsum dolor sit amet,\n' +
    //   'consectetuer adipiscing elit, sed diam\n' +
    //   'nonummy nibh euismod tincidunt ut\n' +
    //   'laoreet dolore magna aliquam erat'
    // },
    // {
    //   _id: '2',
    //   name: 'Web protection',
    //   description: 'Lorem ipsum dolor sit amet,\n' +
    //   'consectetuer adipiscing elit, sed diam\n' +
    //   'nonummy nibh euismod tincidunt ut\n' +
    //   'laoreet dolore magna aliquam erat'
    // },
    // {
    //   _id: '3',
    //   name: 'Web protection',
    //   description: 'Lorem ipsum dolor sit amet,\n' +
    //   'consectetuer adipiscing elit, sed diam\n' +
    //   'nonummy nibh euismod tincidunt ut\n' +
    //   'laoreet dolore magna aliquam erat'
    // },
  ];

  constructor(public http: HttpClient) {
    super();
  }

  ngOnInit() {
    this.loadServiceList();
  }

  loadServiceList() {
    let url = API_BASE_URL + '/quick_config/list_service/';
    this.http.get(url).subscribe((resp: any) => {
      this.serviceList = resp.data || [];
      this.model = this.serviceList.find(s => s.checked) || {};
    });
  }

  onChangeService(service) {
    this.model = service;
  }

  onClickConfirm() {
    this.onConfirm.emit(this.model);
  }
}
