import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {QcBaseComponent} from "../base/base.component";

@Component({
  selector: 'qc-finish-no-service',
  templateUrl: './finish-no-service.component.html',
  styleUrls: ['./finish-no-service.component.scss']
})
export class FinishNoServiceComponent extends QcBaseComponent implements OnInit {
  @Output() onBuyNow = new EventEmitter();

  constructor() {
    super();
  }

  ngOnInit() {
  }

  onClickBuyNow() {
    this.onBuyNow.emit('onClickBuyNow');
  }
}
