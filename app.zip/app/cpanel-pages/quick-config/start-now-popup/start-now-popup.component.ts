import {Component, OnInit} from '@angular/core';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import 'rxjs/add/observable/interval';
import {API_BASE_URL} from "@customer/config";
import {Router} from "@angular/router";
import {ClientPermService} from "@common/services";
import {QuickConfigHelperService} from "@common/services/quick-config-helper";
import {DeviceDetectorService} from "ngx-device-detector";

@AutoUnsubscribe()
@Component({
  selector: 'qc-start-now-popup',
  templateUrl: './start-now-popup.component.html',
  styleUrls: ['./start-now-popup.component.scss']
})
export class StartNowPopupComponent implements OnInit {
  hidden = true;
  sub01;
  isMobile;

  get isBoughtPackage() {
    return this.qcHelper.isBought;
  }

  get isConfigured() {
    return this.qcHelper.isConfigured;
  }

  constructor(public http: HttpClient,
              public clientPerm: ClientPermService,
              public qcHelper: QuickConfigHelperService,
              private deviceDetector: DeviceDetectorService,
              public router: Router) {
    this.isMobile = deviceDetector.isMobile();
    console.log(this.isMobile)
  }

  ngOnInit() {
    if (!this.isMobile) {
      // first load
      setTimeout(() => {
        this.qcHelper.checkForStatus().subscribe(() => {
          this.hidden = this.qcHelper.isConfigured;
        });
      }, 6000);

      this.sub01 = Observable.interval(3 * 60000).switchMap(() => {
        return this.qcHelper.checkForStatus();
      }).subscribe(() => {
        this.hidden = this.qcHelper.isConfigured;
      });
    }
  }

  /* This is required for Auto Unsubscribe */
  ngOnDestroy() {

  }

  close() {
    this.hidden = true;
  }

  onFinish() {
    this.close();
    this.qcHelper.redirect();
  }
}
