import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigureServicesComponent } from './configure-services.component';

describe('ConfigureServicesComponent', () => {
  let component: ConfigureServicesComponent;
  let fixture: ComponentFixture<ConfigureServicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigureServicesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigureServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
