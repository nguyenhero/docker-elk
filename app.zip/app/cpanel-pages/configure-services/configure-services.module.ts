import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {COMMON_MODULES} from '@common/lazyload';

import { configureServicesRoute } from './configure-services-routing.module';
import { GeneralConfigComponent } from './components/general-config/general-config.component';
import { ConfigureServicesComponent } from './configure-services.component';

import { WafWebsitesService, ResMonitorService, AttackMonitorService, AlertsMonitorService } from '@common/swagger-services-waf';
import { CsUnitService } from '@common/swagger-services';

import { WebProtectionConfigModule } from '../waf/webprotection-config.module';
import { AntiddosConfigurationModule } from '../antiddos/antiddos-configuration.module';
import {CanDeactivateGuard} from "@common/can_deactivate_guard";

const WAF_SERVICES = [
  WafWebsitesService
]

const GENERAL_SERVICES = [
  CsUnitService
]

// import { 
//   WebprotectionConfigComponent, 
//   WebprotectionConfigFormComponent,
//   PortHttpsFormComponent } from './components/webprotection-config';

// let WEBPROTECT_CONFIG = [
//   WebprotectionConfigComponent,
//   WebprotectionConfigFormComponent,
//   PortHttpsFormComponent
// ]
@NgModule({
  imports: [
    ...COMMON_MODULES,
    CommonModule,
    configureServicesRoute,
    WebProtectionConfigModule,
    AntiddosConfigurationModule
  ],
  declarations: [
    ConfigureServicesComponent,
    GeneralConfigComponent,
    // ...WEBPROTECT_CONFIG
  ],
  providers: [
    ...WAF_SERVICES,
    ...GENERAL_SERVICES,
    CanDeactivateGuard,
  ]
})
export class ConfigureServicesModule { }
