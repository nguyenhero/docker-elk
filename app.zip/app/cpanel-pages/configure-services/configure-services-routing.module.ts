import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConfigureServicesComponent } from './configure-services.component';
import { CanDeactivateGuard } from "@common/can_deactivate_guard";

const routes: Routes = [
  {
    path: '',
    component: ConfigureServicesComponent,
    canDeactivate: [CanDeactivateGuard],
  }
];

export const configureServicesRoute = RouterModule.forChild(routes);
