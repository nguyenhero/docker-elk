import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { ClientPermService } from "@common/services";
import { HeaderSidebarService } from '@customer/header-sidebar.service';
import { ComponentCanDeactivate } from "@common/can_deactivate_guard";
import { Observable } from "rxjs/Observable";
import {TranslateService} from "@ngx-translate/core";

@Component({
  selector: 'app-configure-services',
  templateUrl: './configure-services.component.html',
  styleUrls: [ './configure-services.component.scss' ]
})
export class ConfigureServicesComponent implements OnInit, ComponentCanDeactivate {

  selectedIndex = 0;
  selectedTab: any;

  infoTabs;

  wpTab = new Tab('Web Protection Configuration', 'WPC');
  ddosl4Tab = new Tab('AntiDDoS Configuration', 'ADDC');

  TABS = {
    'wp': this.wpTab,
    'ddosl4': this.ddosl4Tab
  };

  editingStatus = false;

  onChangeConfig(event) {
      this.editingStatus = event.editingStatus;
  }

  get enableWebProtection() {
    return this.permService.isEnableWebProtection();
  }

  get enableDDoSL4() {
    return this.permService.isEnableDDoSL4();
  }

  get user_services() {
    return this.permService.current_user.services || [];
  }

  constructor(
      private permService: ClientPermService,
      private translate: TranslateService,
      private _headerSidebar: HeaderSidebarService
  ) {
    _headerSidebar.title = 'Cấu hình dịch vụ';
  }

  ngOnInit() {
    // this.infoTabs = this.user_services.map(s => this.TABS[s]);
    let services_dict = {};
    this.user_services.map(s => services_dict[ s ] = true);
    this.infoTabs = [];
    Object.keys(this.TABS).map(s => {
      if (services_dict[ s ]) {
        this.infoTabs.push(this.TABS[ s ]);
      }
    });
    if (this.infoTabs && this.infoTabs.length > 0) {
      this.selectedIndex = 0;
      this.selectedTab = this.infoTabs[ 0 ];
    }
  }

  onInfoChange(event) {
    // this.selectedTab = this.infoTabs[event.index];
    this.selectedTab = event;
    // console.log(this.selectedTab);
    /* remove dispatch resize */
    window.dispatchEvent(new Event('resize'));

    if (this.selectedIndex !== 0) {
      this.editingStatus = false;
    }
  }

  @HostListener('window:beforeunload')
  canDeactivate(): Observable<boolean> | boolean {
    return !this.editingStatus;
  }

}

export class Tab {
  constructor(
    public title: string,
    public type: string,
    public active: boolean = false
  ) { }
}
