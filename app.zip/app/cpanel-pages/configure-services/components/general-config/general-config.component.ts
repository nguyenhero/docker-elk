import { Component, OnInit } from '@angular/core';
import {swalNotiSuccess, swalShowConfirm, swalShowError,_ , swalShowWarn} from '@common/utils';
import {CustomerNoticeService} from '@common/swagger-services/api/customerNotice.service'
import {ClientPermService} from '@common/services';

@Component({
  selector: 'app-service-general-config',
  templateUrl: './general-config.component.html',
  styleUrls: ['./general-config.component.scss']
})
export class GeneralConfigComponent implements OnInit {
  reportDurations: any[];
  model: any = {};
  cur_user;
  report_duration_label = '';
  labelMap = {};

  constructor(public customerNoticeService: CustomerNoticeService,
              public clientPermService: ClientPermService
  ) { }

  ngOnInit() {
    this.cur_user = this.clientPermService.current_user;
    this.customerNoticeService.getCustomerNotice(this.cur_user.user_id).subscribe(resp =>{
      this.model = resp.data.customer_notice || {};
      this.reportDurations = resp.data.report_durations || [];
      for (let d of this.reportDurations) this.labelMap[d.value] = d.text;
      this.report_duration_label = this.labelMap[this.model.report_duration] || '';
    });
  }

  toggleTelegram(){
    // if(1+1==2){
    //   swalShowWarn(_("Thông báo"), _("Chức năng sẽ sớm ra mắt trong thời gian tới"));
    //   return;
    // }

    // console.log('toggle telegram');
    this.model.toggle_telegram = ! this.model.toggle_telegram;
    this.customerNoticeService.postCustomerNotice({
      customer_id: this.cur_user.user_id,
      type: 'toggle_telegram',
      value: this.model.toggle_telegram
    }).subscribe(resp =>{
      if(resp.data.valid){
        swalNotiSuccess(_('Thông báo'), _('Status changed successfully'));
        if(resp.data.can_on_telegram != undefined){
          this.model.toggle_telegram = false;
          swalShowWarn(_('Cảnh báo'), _('telegram_can_not_on_warn'));
        }
      }else{
        swalShowError(_('Lỗi'), _('Có lỗi xảy ra'));
      }
    });
  }

  toggleEmail(){
    // if(1+1==2){
    //   swalShowWarn(_("Thông báo"), _("Chức năng sẽ sớm ra mắt trong thời gian tới"));
    //   return;
    // }

    // console.log('toggle email');
    this.model.toggle_email = ! this.model.toggle_email;
    this.customerNoticeService.postCustomerNotice({
      customer_id: this.cur_user.user_id,
      type: 'toggle_email',
      value: this.model.toggle_email
    }).subscribe(resp =>{
      if(resp.data.valid){
        swalNotiSuccess(_('Thông báo'), _('Status changed successfully'));
      }else{
        swalShowError(_('Lỗi'), _('Có lỗi xảy ra'));
      }
    });
  }

  changeReportDuration(event){
    // if(1+1==2){
    //   swalShowWarn(_("Thông báo"), _("Chức năng sẽ sớm ra mắt trong thời gian tới"));
    //   return;
    // }

    // console.log('change report duration');
    // console.log(event);
    this.model.report_duration = event.value;
    this.report_duration_label = this.labelMap[this.model.report_duration] || '';
    this.customerNoticeService.postCustomerChangeReportSchedule({
      customer_id: this.cur_user.user_id,
      value: this.model.report_duration
    }).subscribe(resp =>{
      if(resp.data.valid){
        swalNotiSuccess(_('Thông báo'), _('Status changed successfully'));
      }else{
        swalShowError(_('Lỗi'), _('Có lỗi xảy ra'));
      }
    });
  }
}
