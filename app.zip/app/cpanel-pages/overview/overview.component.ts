import { moment } from '@visc/visc-template';
import { mulChart } from '@customer/cpanel-pages/antiddos/l4-monitoring/share-module/multiple-line-chart/multiple-line-chart.component';
import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ChangeDetectorRef,
} from '@angular/core';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { TranslateService } from '@ngx-translate/core';
import { GlobalService } from '../../common/services/global.service';
import { SeriesUtils } from '../../../../../../libs/visc-template/src/utils/series';
import { OneLineChart } from '../antiddos/l4-monitoring/share-module/one-line-chart/oneLineChart.model';
@AutoUnsubscribe()
@Component({
    selector: 'app-overview',
    templateUrl: './overview.component.html',
    styleUrls: ['./overview.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OverviewComponent implements OnInit, OnDestroy {
    selectedDate: Date;
    filterData: any;
    underAttackMode = true;
    developmentMode = true;
    totalRequestChart: any;
    percentCacheChart: any;
    totalDataServerChart: any;
    dataCachedChart: any;
    statisticChart: any;
    startDate: Date = new Date();
    endDate: Date = new Date();
    constructor(
        public globalService: GlobalService,
        public cd: ChangeDetectorRef,
        private translate: TranslateService
    ) {
        this.globalService.notifyObservable$.subscribe(resp => {
            if (resp && resp.selected_domain) {
                // TODO: add search
                this.search();
            }
        });
        this.selectedDate = new Date(moment().format('YYYY/MM/DD'));
    }

    ngOnInit() {
        let CLOUDRITY_CONST = JSON.parse(this.globalService.getItem("CLOUDRITY_CONST"));
        if (CLOUDRITY_CONST && CLOUDRITY_CONST.selected_domain) {
            // TODO: add search
            this.search();
        }
        this.totalRequestChart = new OneLineChart(
            [{ "date": "2018-06-06 00:23", "value": 217 }, { "date": "2018-06-06 00:24", "value": 873 }, { "date": "2018-06-06 00:25", "value": 971 }, { "date": "2018-06-06 00:26", "value": 532 }, { "date": "2018-06-06 00:27", "value": 268 }, { "date": "2018-06-06 00:28", "value": 568 }, { "date": "2018-06-06 00:29", "value": 39 }, { "date": "2018-06-06 00:30", "value": 982 }, { "date": "2018-06-06 00:31", "value": 73 }, { "date": "2018-06-06 00:32", "value": 208 }, { "date": "2018-06-06 00:33", "value": 43 }, { "date": "2018-06-06 00:34", "value": 71 }, { "date": "2018-06-06 00:35", "value": 8 }, { "date": "2018-06-06 00:36", "value": 937 }, { "date": "2018-06-06 00:37", "value": 47 }, { "date": "2018-06-06 00:38", "value": 120 }, { "date": "2018-06-06 00:39", "value": 379 }, { "date": "2018-06-06 00:40", "value": 116 }, { "date": "2018-06-06 00:41", "value": 760 }, { "date": "2018-06-06 00:42", "value": 815 }, { "date": "2018-06-06 00:43", "value": 722 }, { "date": "2018-06-06 00:44", "value": 478 }, { "date": "2018-06-06 00:45", "value": 749 }, { "date": "2018-06-06 00:46", "value": 330 }, { "date": "2018-06-06 00:47", "value": 6 }, { "date": "2018-06-06 00:48", "value": 806 }, { "date": "2018-06-06 00:49", "value": 204 }, { "date": "2018-06-06 00:50", "value": 809 }, { "date": "2018-06-06 00:51", "value": 466 }, { "date": "2018-06-06 00:52", "value": 344 }, { "date": "2018-06-06 00:53", "value": 867 }, { "date": "2018-06-06 00:54", "value": 961 }, { "date": "2018-06-06 00:55", "value": 468 }, { "date": "2018-06-06 00:56", "value": 946 }, { "date": "2018-06-06 00:57", "value": 690 }, { "date": "2018-06-06 00:58", "value": 434 }, { "date": "2018-06-06 00:59", "value": 157 }, { "date": "2018-06-06 01:00", "value": 530 }, { "date": "2018-06-06 01:01", "value": 959 }, { "date": "2018-06-06 01:02", "value": 752 }, { "date": "2018-06-06 01:03", "value": 200 }, { "date": "2018-06-06 01:04", "value": 179 }, { "date": "2018-06-06 01:05", "value": 99 }, { "date": "2018-06-06 01:06", "value": 157 }, { "date": "2018-06-06 01:07", "value": 516 }, { "date": "2018-06-06 01:08", "value": 28 }, { "date": "2018-06-06 01:09", "value": 199 }, { "date": "2018-06-06 01:10", "value": 561 }, { "date": "2018-06-06 01:11", "value": 845 }, { "date": "2018-06-06 01:12", "value": 643 }, { "date": "2018-06-06 01:13", "value": 55 }, { "date": "2018-06-06 01:14", "value": 973 }, { "date": "2018-06-06 01:15", "value": 304 }, { "date": "2018-06-06 01:16", "value": 92 }, { "date": "2018-06-06 01:17", "value": 837 }, { "date": "2018-06-06 01:18", "value": 10 }, { "date": "2018-06-06 01:19", "value": 443 }, { "date": "2018-06-06 01:20", "value": 361 }, { "date": "2018-06-06 01:21", "value": 12 }, { "date": "2018-06-06 01:22", "value": 522 }, { "date": "2018-06-06 01:23", "value": 448 }, { "date": "2018-06-06 01:24", "value": 583 }, { "date": "2018-06-06 01:25", "value": 498 }, { "date": "2018-06-06 01:26", "value": 36 }, { "date": "2018-06-06 01:27", "value": 662 }, { "date": "2018-06-06 01:28", "value": 255 }, { "date": "2018-06-06 01:29", "value": 348 }, { "date": "2018-06-06 01:30", "value": 872 }, { "date": "2018-06-06 01:31", "value": 629 }, { "date": "2018-06-06 01:32", "value": 244 }, { "date": "2018-06-06 01:33", "value": 547 }, { "date": "2018-06-06 01:34", "value": 157 }, { "date": "2018-06-06 01:35", "value": 18 }, { "date": "2018-06-06 01:36", "value": 47 }, { "date": "2018-06-06 01:37", "value": 138 }, { "date": "2018-06-06 01:38", "value": 456 }, { "date": "2018-06-06 01:39", "value": 896 }, { "date": "2018-06-06 01:40", "value": 700 }, { "date": "2018-06-06 01:41", "value": 694 }, { "date": "2018-06-06 01:42", "value": 180 }, { "date": "2018-06-06 01:43", "value": 373 }, { "date": "2018-06-06 01:44", "value": 88 }, { "date": "2018-06-06 01:45", "value": 729 }, { "date": "2018-06-06 01:46", "value": 733 }, { "date": "2018-06-06 01:47", "value": 678 }, { "date": "2018-06-06 01:48", "value": 773 }, { "date": "2018-06-06 01:49", "value": 991 }, { "date": "2018-06-06 01:50", "value": 706 }, { "date": "2018-06-06 01:51", "value": 748 }, { "date": "2018-06-06 01:52", "value": 37 }, { "date": "2018-06-06 01:53", "value": 559 }, { "date": "2018-06-06 01:54", "value": 18 }, { "date": "2018-06-06 01:55", "value": 344 }, { "date": "2018-06-06 01:56", "value": 952 }, { "date": "2018-06-06 01:57", "value": 511 }, { "date": "2018-06-06 01:58", "value": 211 }, { "date": "2018-06-06 01:59", "value": 273 }, { "date": "2018-06-06 02:00", "value": 337 }, { "date": "2018-06-06 02:01", "value": 565 }, { "date": "2018-06-06 02:02", "value": 771 }, { "date": "2018-06-06 02:03", "value": 242 }, { "date": "2018-06-06 02:04", "value": 456 }, { "date": "2018-06-06 02:05", "value": 511 }, { "date": "2018-06-06 02:06", "value": 931 }, { "date": "2018-06-06 02:07", "value": 251 }, { "date": "2018-06-06 02:08", "value": 450 }, { "date": "2018-06-06 02:09", "value": 955 }, { "date": "2018-06-06 02:10", "value": 763 }, { "date": "2018-06-06 02:11", "value": 307 }, { "date": "2018-06-06 02:12", "value": 454 }, { "date": "2018-06-06 02:13", "value": 298 }, { "date": "2018-06-06 02:14", "value": 333 }, { "date": "2018-06-06 02:15", "value": 996 }, { "date": "2018-06-06 02:16", "value": 41 }, { "date": "2018-06-06 02:17", "value": 688 }, { "date": "2018-06-06 02:18", "value": 830 }, { "date": "2018-06-06 02:19", "value": 37 }, { "date": "2018-06-06 02:20", "value": 432 }, { "date": "2018-06-06 02:21", "value": 871 }, { "date": "2018-06-06 02:22", "value": 655 }],
            'date',
            'value',
            'value',
            "totalRequestChart",
            "Request"
        );
        this.percentCacheChart = new OneLineChart(
            [{ "date": "2018-06-06 00:23", "value": 217 }, { "date": "2018-06-06 00:24", "value": 873 }, { "date": "2018-06-06 00:25", "value": 971 }, { "date": "2018-06-06 00:26", "value": 532 }, { "date": "2018-06-06 00:27", "value": 268 }, { "date": "2018-06-06 00:28", "value": 568 }, { "date": "2018-06-06 00:29", "value": 39 }, { "date": "2018-06-06 00:30", "value": 982 }, { "date": "2018-06-06 00:31", "value": 73 }, { "date": "2018-06-06 00:32", "value": 208 }, { "date": "2018-06-06 00:33", "value": 43 }, { "date": "2018-06-06 00:34", "value": 71 }, { "date": "2018-06-06 00:35", "value": 8 }, { "date": "2018-06-06 00:36", "value": 937 }, { "date": "2018-06-06 00:37", "value": 47 }, { "date": "2018-06-06 00:38", "value": 120 }, { "date": "2018-06-06 00:39", "value": 379 }, { "date": "2018-06-06 00:40", "value": 116 }, { "date": "2018-06-06 00:41", "value": 760 }, { "date": "2018-06-06 00:42", "value": 815 }, { "date": "2018-06-06 00:43", "value": 722 }, { "date": "2018-06-06 00:44", "value": 478 }, { "date": "2018-06-06 00:45", "value": 749 }, { "date": "2018-06-06 00:46", "value": 330 }, { "date": "2018-06-06 00:47", "value": 6 }, { "date": "2018-06-06 00:48", "value": 806 }, { "date": "2018-06-06 00:49", "value": 204 }, { "date": "2018-06-06 00:50", "value": 809 }, { "date": "2018-06-06 00:51", "value": 466 }, { "date": "2018-06-06 00:52", "value": 344 }, { "date": "2018-06-06 00:53", "value": 867 }, { "date": "2018-06-06 00:54", "value": 961 }, { "date": "2018-06-06 00:55", "value": 468 }, { "date": "2018-06-06 00:56", "value": 946 }, { "date": "2018-06-06 00:57", "value": 690 }, { "date": "2018-06-06 00:58", "value": 434 }, { "date": "2018-06-06 00:59", "value": 157 }, { "date": "2018-06-06 01:00", "value": 530 }, { "date": "2018-06-06 01:01", "value": 959 }, { "date": "2018-06-06 01:02", "value": 752 }, { "date": "2018-06-06 01:03", "value": 200 }, { "date": "2018-06-06 01:04", "value": 179 }, { "date": "2018-06-06 01:05", "value": 99 }, { "date": "2018-06-06 01:06", "value": 157 }, { "date": "2018-06-06 01:07", "value": 516 }, { "date": "2018-06-06 01:08", "value": 28 }, { "date": "2018-06-06 01:09", "value": 199 }, { "date": "2018-06-06 01:10", "value": 561 }, { "date": "2018-06-06 01:11", "value": 845 }, { "date": "2018-06-06 01:12", "value": 643 }, { "date": "2018-06-06 01:13", "value": 55 }, { "date": "2018-06-06 01:14", "value": 973 }, { "date": "2018-06-06 01:15", "value": 304 }, { "date": "2018-06-06 01:16", "value": 92 }, { "date": "2018-06-06 01:17", "value": 837 }, { "date": "2018-06-06 01:18", "value": 10 }, { "date": "2018-06-06 01:19", "value": 443 }, { "date": "2018-06-06 01:20", "value": 361 }, { "date": "2018-06-06 01:21", "value": 12 }, { "date": "2018-06-06 01:22", "value": 522 }, { "date": "2018-06-06 01:23", "value": 448 }, { "date": "2018-06-06 01:24", "value": 583 }, { "date": "2018-06-06 01:25", "value": 498 }, { "date": "2018-06-06 01:26", "value": 36 }, { "date": "2018-06-06 01:27", "value": 662 }, { "date": "2018-06-06 01:28", "value": 255 }, { "date": "2018-06-06 01:29", "value": 348 }, { "date": "2018-06-06 01:30", "value": 872 }, { "date": "2018-06-06 01:31", "value": 629 }, { "date": "2018-06-06 01:32", "value": 244 }, { "date": "2018-06-06 01:33", "value": 547 }, { "date": "2018-06-06 01:34", "value": 157 }, { "date": "2018-06-06 01:35", "value": 18 }, { "date": "2018-06-06 01:36", "value": 47 }, { "date": "2018-06-06 01:37", "value": 138 }, { "date": "2018-06-06 01:38", "value": 456 }, { "date": "2018-06-06 01:39", "value": 896 }, { "date": "2018-06-06 01:40", "value": 700 }, { "date": "2018-06-06 01:41", "value": 694 }, { "date": "2018-06-06 01:42", "value": 180 }, { "date": "2018-06-06 01:43", "value": 373 }, { "date": "2018-06-06 01:44", "value": 88 }, { "date": "2018-06-06 01:45", "value": 729 }, { "date": "2018-06-06 01:46", "value": 733 }, { "date": "2018-06-06 01:47", "value": 678 }, { "date": "2018-06-06 01:48", "value": 773 }, { "date": "2018-06-06 01:49", "value": 991 }, { "date": "2018-06-06 01:50", "value": 706 }, { "date": "2018-06-06 01:51", "value": 748 }, { "date": "2018-06-06 01:52", "value": 37 }, { "date": "2018-06-06 01:53", "value": 559 }, { "date": "2018-06-06 01:54", "value": 18 }, { "date": "2018-06-06 01:55", "value": 344 }, { "date": "2018-06-06 01:56", "value": 952 }, { "date": "2018-06-06 01:57", "value": 511 }, { "date": "2018-06-06 01:58", "value": 211 }, { "date": "2018-06-06 01:59", "value": 273 }, { "date": "2018-06-06 02:00", "value": 337 }, { "date": "2018-06-06 02:01", "value": 565 }, { "date": "2018-06-06 02:02", "value": 771 }, { "date": "2018-06-06 02:03", "value": 242 }, { "date": "2018-06-06 02:04", "value": 456 }, { "date": "2018-06-06 02:05", "value": 511 }, { "date": "2018-06-06 02:06", "value": 931 }, { "date": "2018-06-06 02:07", "value": 251 }, { "date": "2018-06-06 02:08", "value": 450 }, { "date": "2018-06-06 02:09", "value": 955 }, { "date": "2018-06-06 02:10", "value": 763 }, { "date": "2018-06-06 02:11", "value": 307 }, { "date": "2018-06-06 02:12", "value": 454 }, { "date": "2018-06-06 02:13", "value": 298 }, { "date": "2018-06-06 02:14", "value": 333 }, { "date": "2018-06-06 02:15", "value": 996 }, { "date": "2018-06-06 02:16", "value": 41 }, { "date": "2018-06-06 02:17", "value": 688 }, { "date": "2018-06-06 02:18", "value": 830 }, { "date": "2018-06-06 02:19", "value": 37 }, { "date": "2018-06-06 02:20", "value": 432 }, { "date": "2018-06-06 02:21", "value": 871 }, { "date": "2018-06-06 02:22", "value": 655 }],
            'date',
            'value',
            'value',
            "percentCacheChart",
            "%"
        );
        this.totalDataServerChart = new OneLineChart(
            [{ "date": "2018-06-06 00:23", "value": 217 }, { "date": "2018-06-06 00:24", "value": 873 }, { "date": "2018-06-06 00:25", "value": 971 }, { "date": "2018-06-06 00:26", "value": 532 }, { "date": "2018-06-06 00:27", "value": 268 }, { "date": "2018-06-06 00:28", "value": 568 }, { "date": "2018-06-06 00:29", "value": 39 }, { "date": "2018-06-06 00:30", "value": 982 }, { "date": "2018-06-06 00:31", "value": 73 }, { "date": "2018-06-06 00:32", "value": 208 }, { "date": "2018-06-06 00:33", "value": 43 }, { "date": "2018-06-06 00:34", "value": 71 }, { "date": "2018-06-06 00:35", "value": 8 }, { "date": "2018-06-06 00:36", "value": 937 }, { "date": "2018-06-06 00:37", "value": 47 }, { "date": "2018-06-06 00:38", "value": 120 }, { "date": "2018-06-06 00:39", "value": 379 }, { "date": "2018-06-06 00:40", "value": 116 }, { "date": "2018-06-06 00:41", "value": 760 }, { "date": "2018-06-06 00:42", "value": 815 }, { "date": "2018-06-06 00:43", "value": 722 }, { "date": "2018-06-06 00:44", "value": 478 }, { "date": "2018-06-06 00:45", "value": 749 }, { "date": "2018-06-06 00:46", "value": 330 }, { "date": "2018-06-06 00:47", "value": 6 }, { "date": "2018-06-06 00:48", "value": 806 }, { "date": "2018-06-06 00:49", "value": 204 }, { "date": "2018-06-06 00:50", "value": 809 }, { "date": "2018-06-06 00:51", "value": 466 }, { "date": "2018-06-06 00:52", "value": 344 }, { "date": "2018-06-06 00:53", "value": 867 }, { "date": "2018-06-06 00:54", "value": 961 }, { "date": "2018-06-06 00:55", "value": 468 }, { "date": "2018-06-06 00:56", "value": 946 }, { "date": "2018-06-06 00:57", "value": 690 }, { "date": "2018-06-06 00:58", "value": 434 }, { "date": "2018-06-06 00:59", "value": 157 }, { "date": "2018-06-06 01:00", "value": 530 }, { "date": "2018-06-06 01:01", "value": 959 }, { "date": "2018-06-06 01:02", "value": 752 }, { "date": "2018-06-06 01:03", "value": 200 }, { "date": "2018-06-06 01:04", "value": 179 }, { "date": "2018-06-06 01:05", "value": 99 }, { "date": "2018-06-06 01:06", "value": 157 }, { "date": "2018-06-06 01:07", "value": 516 }, { "date": "2018-06-06 01:08", "value": 28 }, { "date": "2018-06-06 01:09", "value": 199 }, { "date": "2018-06-06 01:10", "value": 561 }, { "date": "2018-06-06 01:11", "value": 845 }, { "date": "2018-06-06 01:12", "value": 643 }, { "date": "2018-06-06 01:13", "value": 55 }, { "date": "2018-06-06 01:14", "value": 973 }, { "date": "2018-06-06 01:15", "value": 304 }, { "date": "2018-06-06 01:16", "value": 92 }, { "date": "2018-06-06 01:17", "value": 837 }, { "date": "2018-06-06 01:18", "value": 10 }, { "date": "2018-06-06 01:19", "value": 443 }, { "date": "2018-06-06 01:20", "value": 361 }, { "date": "2018-06-06 01:21", "value": 12 }, { "date": "2018-06-06 01:22", "value": 522 }, { "date": "2018-06-06 01:23", "value": 448 }, { "date": "2018-06-06 01:24", "value": 583 }, { "date": "2018-06-06 01:25", "value": 498 }, { "date": "2018-06-06 01:26", "value": 36 }, { "date": "2018-06-06 01:27", "value": 662 }, { "date": "2018-06-06 01:28", "value": 255 }, { "date": "2018-06-06 01:29", "value": 348 }, { "date": "2018-06-06 01:30", "value": 872 }, { "date": "2018-06-06 01:31", "value": 629 }, { "date": "2018-06-06 01:32", "value": 244 }, { "date": "2018-06-06 01:33", "value": 547 }, { "date": "2018-06-06 01:34", "value": 157 }, { "date": "2018-06-06 01:35", "value": 18 }, { "date": "2018-06-06 01:36", "value": 47 }, { "date": "2018-06-06 01:37", "value": 138 }, { "date": "2018-06-06 01:38", "value": 456 }, { "date": "2018-06-06 01:39", "value": 896 }, { "date": "2018-06-06 01:40", "value": 700 }, { "date": "2018-06-06 01:41", "value": 694 }, { "date": "2018-06-06 01:42", "value": 180 }, { "date": "2018-06-06 01:43", "value": 373 }, { "date": "2018-06-06 01:44", "value": 88 }, { "date": "2018-06-06 01:45", "value": 729 }, { "date": "2018-06-06 01:46", "value": 733 }, { "date": "2018-06-06 01:47", "value": 678 }, { "date": "2018-06-06 01:48", "value": 773 }, { "date": "2018-06-06 01:49", "value": 991 }, { "date": "2018-06-06 01:50", "value": 706 }, { "date": "2018-06-06 01:51", "value": 748 }, { "date": "2018-06-06 01:52", "value": 37 }, { "date": "2018-06-06 01:53", "value": 559 }, { "date": "2018-06-06 01:54", "value": 18 }, { "date": "2018-06-06 01:55", "value": 344 }, { "date": "2018-06-06 01:56", "value": 952 }, { "date": "2018-06-06 01:57", "value": 511 }, { "date": "2018-06-06 01:58", "value": 211 }, { "date": "2018-06-06 01:59", "value": 273 }, { "date": "2018-06-06 02:00", "value": 337 }, { "date": "2018-06-06 02:01", "value": 565 }, { "date": "2018-06-06 02:02", "value": 771 }, { "date": "2018-06-06 02:03", "value": 242 }, { "date": "2018-06-06 02:04", "value": 456 }, { "date": "2018-06-06 02:05", "value": 511 }, { "date": "2018-06-06 02:06", "value": 931 }, { "date": "2018-06-06 02:07", "value": 251 }, { "date": "2018-06-06 02:08", "value": 450 }, { "date": "2018-06-06 02:09", "value": 955 }, { "date": "2018-06-06 02:10", "value": 763 }, { "date": "2018-06-06 02:11", "value": 307 }, { "date": "2018-06-06 02:12", "value": 454 }, { "date": "2018-06-06 02:13", "value": 298 }, { "date": "2018-06-06 02:14", "value": 333 }, { "date": "2018-06-06 02:15", "value": 996 }, { "date": "2018-06-06 02:16", "value": 41 }, { "date": "2018-06-06 02:17", "value": 688 }, { "date": "2018-06-06 02:18", "value": 830 }, { "date": "2018-06-06 02:19", "value": 37 }, { "date": "2018-06-06 02:20", "value": 432 }, { "date": "2018-06-06 02:21", "value": 871 }, { "date": "2018-06-06 02:22", "value": 655 }],
            'date',
            'value',
            'value',
            "totalDataServerChart",
            ""
        );
        this.dataCachedChart = new OneLineChart(
            [{ "date": "2018-06-06 00:23", "value": 217 }, { "date": "2018-06-06 00:24", "value": 873 }, { "date": "2018-06-06 00:25", "value": 971 }, { "date": "2018-06-06 00:26", "value": 532 }, { "date": "2018-06-06 00:27", "value": 268 }, { "date": "2018-06-06 00:28", "value": 568 }, { "date": "2018-06-06 00:29", "value": 39 }, { "date": "2018-06-06 00:30", "value": 982 }, { "date": "2018-06-06 00:31", "value": 73 }, { "date": "2018-06-06 00:32", "value": 208 }, { "date": "2018-06-06 00:33", "value": 43 }, { "date": "2018-06-06 00:34", "value": 71 }, { "date": "2018-06-06 00:35", "value": 8 }, { "date": "2018-06-06 00:36", "value": 937 }, { "date": "2018-06-06 00:37", "value": 47 }, { "date": "2018-06-06 00:38", "value": 120 }, { "date": "2018-06-06 00:39", "value": 379 }, { "date": "2018-06-06 00:40", "value": 116 }, { "date": "2018-06-06 00:41", "value": 760 }, { "date": "2018-06-06 00:42", "value": 815 }, { "date": "2018-06-06 00:43", "value": 722 }, { "date": "2018-06-06 00:44", "value": 478 }, { "date": "2018-06-06 00:45", "value": 749 }, { "date": "2018-06-06 00:46", "value": 330 }, { "date": "2018-06-06 00:47", "value": 6 }, { "date": "2018-06-06 00:48", "value": 806 }, { "date": "2018-06-06 00:49", "value": 204 }, { "date": "2018-06-06 00:50", "value": 809 }, { "date": "2018-06-06 00:51", "value": 466 }, { "date": "2018-06-06 00:52", "value": 344 }, { "date": "2018-06-06 00:53", "value": 867 }, { "date": "2018-06-06 00:54", "value": 961 }, { "date": "2018-06-06 00:55", "value": 468 }, { "date": "2018-06-06 00:56", "value": 946 }, { "date": "2018-06-06 00:57", "value": 690 }, { "date": "2018-06-06 00:58", "value": 434 }, { "date": "2018-06-06 00:59", "value": 157 }, { "date": "2018-06-06 01:00", "value": 530 }, { "date": "2018-06-06 01:01", "value": 959 }, { "date": "2018-06-06 01:02", "value": 752 }, { "date": "2018-06-06 01:03", "value": 200 }, { "date": "2018-06-06 01:04", "value": 179 }, { "date": "2018-06-06 01:05", "value": 99 }, { "date": "2018-06-06 01:06", "value": 157 }, { "date": "2018-06-06 01:07", "value": 516 }, { "date": "2018-06-06 01:08", "value": 28 }, { "date": "2018-06-06 01:09", "value": 199 }, { "date": "2018-06-06 01:10", "value": 561 }, { "date": "2018-06-06 01:11", "value": 845 }, { "date": "2018-06-06 01:12", "value": 643 }, { "date": "2018-06-06 01:13", "value": 55 }, { "date": "2018-06-06 01:14", "value": 973 }, { "date": "2018-06-06 01:15", "value": 304 }, { "date": "2018-06-06 01:16", "value": 92 }, { "date": "2018-06-06 01:17", "value": 837 }, { "date": "2018-06-06 01:18", "value": 10 }, { "date": "2018-06-06 01:19", "value": 443 }, { "date": "2018-06-06 01:20", "value": 361 }, { "date": "2018-06-06 01:21", "value": 12 }, { "date": "2018-06-06 01:22", "value": 522 }, { "date": "2018-06-06 01:23", "value": 448 }, { "date": "2018-06-06 01:24", "value": 583 }, { "date": "2018-06-06 01:25", "value": 498 }, { "date": "2018-06-06 01:26", "value": 36 }, { "date": "2018-06-06 01:27", "value": 662 }, { "date": "2018-06-06 01:28", "value": 255 }, { "date": "2018-06-06 01:29", "value": 348 }, { "date": "2018-06-06 01:30", "value": 872 }, { "date": "2018-06-06 01:31", "value": 629 }, { "date": "2018-06-06 01:32", "value": 244 }, { "date": "2018-06-06 01:33", "value": 547 }, { "date": "2018-06-06 01:34", "value": 157 }, { "date": "2018-06-06 01:35", "value": 18 }, { "date": "2018-06-06 01:36", "value": 47 }, { "date": "2018-06-06 01:37", "value": 138 }, { "date": "2018-06-06 01:38", "value": 456 }, { "date": "2018-06-06 01:39", "value": 896 }, { "date": "2018-06-06 01:40", "value": 700 }, { "date": "2018-06-06 01:41", "value": 694 }, { "date": "2018-06-06 01:42", "value": 180 }, { "date": "2018-06-06 01:43", "value": 373 }, { "date": "2018-06-06 01:44", "value": 88 }, { "date": "2018-06-06 01:45", "value": 729 }, { "date": "2018-06-06 01:46", "value": 733 }, { "date": "2018-06-06 01:47", "value": 678 }, { "date": "2018-06-06 01:48", "value": 773 }, { "date": "2018-06-06 01:49", "value": 991 }, { "date": "2018-06-06 01:50", "value": 706 }, { "date": "2018-06-06 01:51", "value": 748 }, { "date": "2018-06-06 01:52", "value": 37 }, { "date": "2018-06-06 01:53", "value": 559 }, { "date": "2018-06-06 01:54", "value": 18 }, { "date": "2018-06-06 01:55", "value": 344 }, { "date": "2018-06-06 01:56", "value": 952 }, { "date": "2018-06-06 01:57", "value": 511 }, { "date": "2018-06-06 01:58", "value": 211 }, { "date": "2018-06-06 01:59", "value": 273 }, { "date": "2018-06-06 02:00", "value": 337 }, { "date": "2018-06-06 02:01", "value": 565 }, { "date": "2018-06-06 02:02", "value": 771 }, { "date": "2018-06-06 02:03", "value": 242 }, { "date": "2018-06-06 02:04", "value": 456 }, { "date": "2018-06-06 02:05", "value": 511 }, { "date": "2018-06-06 02:06", "value": 931 }, { "date": "2018-06-06 02:07", "value": 251 }, { "date": "2018-06-06 02:08", "value": 450 }, { "date": "2018-06-06 02:09", "value": 955 }, { "date": "2018-06-06 02:10", "value": 763 }, { "date": "2018-06-06 02:11", "value": 307 }, { "date": "2018-06-06 02:12", "value": 454 }, { "date": "2018-06-06 02:13", "value": 298 }, { "date": "2018-06-06 02:14", "value": 333 }, { "date": "2018-06-06 02:15", "value": 996 }, { "date": "2018-06-06 02:16", "value": 41 }, { "date": "2018-06-06 02:17", "value": 688 }, { "date": "2018-06-06 02:18", "value": 830 }, { "date": "2018-06-06 02:19", "value": 37 }, { "date": "2018-06-06 02:20", "value": 432 }, { "date": "2018-06-06 02:21", "value": 871 }, { "date": "2018-06-06 02:22", "value": 655 }],
            'date',
            'value',
            'value',
            "dataCachedChart",
            ""
        );
    }
    ngOnDestroy() {
    }
    search(event?) {
        if (event) {
            this.startDate = event.start;
            this.endDate = event.end;
        }

        let time_from = SeriesUtils.startDateToUTC(this.startDate);
        let time_to = SeriesUtils.endDateToUTC(this.endDate);

        this.getChartData(time_from, time_to);
    }
    getChartData(time_from, time_to) {
        this.statisticChart = this.getChart();
        // call service
        let data = [];
        for (let index = 0; index < 30; index++) {
            let data1 = Math.floor(Math.random() * 1000);
            let data2 = Math.floor(Math.random() * 1000);
            let model = {
                ts: moment().add(-index, 'hours').format('YYYY-MM-DD hh:mm:ss'),
                data1,
                data2
            };
            data.unshift(model);
        }

        data = data.map(d => {
            return {
                data: { data1: d['data1'], data2: d['data2'] },
                date: d['ts'],
                // date: moment(d['ts']).toDate(),
            };
        });
        this.statisticChart = this.getChart(data);
    }
    getChart(data?) {
        data = (data === undefined) ? [] : data;
        return new mulChart(
            data,
            'Overview statistic',
            ['data1', 'data2'],
            'overview_statistic',
            ['Visit', 'Attack'],
            '',
            2,
            false,
            false,
            false,
            true,
            { equalSpacing: false },
        );
    }
    onChangeDate(e) {
        this.selectedDate = e;
    }
    getDay() {
        return moment(this.selectedDate).date();
    }
    getFulldate() {
        moment.locale(this.translate.currentLang);
        return moment(this.selectedDate).format("MMM YYYY");
    }
    changeUnderAttackMode() {
        this.underAttackMode = !this.underAttackMode;
    }
    changeDevelopmentMode() {
        this.developmentMode = !this.developmentMode;
    }
}
