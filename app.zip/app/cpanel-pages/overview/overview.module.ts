import {NgModule} from '@angular/core';
import {COMMON_MODULES} from '@common/lazyload';
import {overviewRouter} from './overview.router';
import { OverviewComponent } from './overview.component';
import { ShareModule } from '../antiddos/l4-monitoring/share-module/share-module';
const MODALS = [];
@NgModule({
    declarations: [
        OverviewComponent,
    ],
    imports: [
        ...COMMON_MODULES,
        ShareModule,
        overviewRouter,
    ],
    entryComponents: [
        ...MODALS,
    ],
    providers: [],
})
export class OverviewModule {
}
