import {Routes, RouterModule} from '@angular/router';
import { OverviewComponent } from './overview.component';

const ROUTER: Routes = [
  {
    path: '',
    component: OverviewComponent
  }
];

export const overviewRouter = RouterModule.forChild(ROUTER);
