import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttackMonitoringComponent } from './attack-monitoring.component';

describe('AttackMonitoringComponent', () => {
  let component: AttackMonitoringComponent;
  let fixture: ComponentFixture<AttackMonitoringComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttackMonitoringComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttackMonitoringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
