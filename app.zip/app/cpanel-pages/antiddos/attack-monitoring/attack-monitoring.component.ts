import {Component, OnInit, Injector} from '@angular/core';

import {DasboardTabPanelComponent} from '@common/components';
import {Router, ActivatedRoute} from '@angular/router';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {ClientPermService} from '@common/services';
import {AttackMonitorService} from '@common/swagger-services-waf';
import {SeriesUtils, moment} from '@visc/visc-template';

import {MAX_RANGE_SUMMERIES, WINDOW_RANGE_SUMMERIES} from '@customer/config';
import {
    OneLineChart
} from '../l4-monitoring/share-module/one-line-chart/oneLineChart.model';
import {
    TopPieChart
} from '../l4-monitoring/share-module/top-pie-chart/topPieChart.model';
import {
    TopChart
} from '../l4-monitoring/share-module/top-chart/topchart.model';

import {DDosL4MonitorService} from '@common/ddosl4-services';
import {AutoUnsubscribe} from 'ngx-auto-unsubscribe';

export class AttackType {
    constructor(
        public label: string,
        public value: number,
        public color: any
    ) {
    }
}

export const colors: string[] = ["#FF0F00", "#FF6600", "#FF9E01", "#FCD202", "#F8FF01", "#B0DE09", "#04D215", "#0D8ECF", "#0D52D1", "#2A0CD0", "#8A0CCF", "#CD0D74", "#754DEB", "#DDDDDD", "#999999", "#333333", "#000000", "#57032A", "#CA9726", "#990000", "#4B0C25"];

@AutoUnsubscribe()
@Component({
    selector: 'app-attack-monitoring',
    templateUrl: './attack-monitoring.component.html',
    styleUrls: ['./attack-monitoring.component.scss']
})
export class AttackMonitoringComponent extends DasboardTabPanelComponent implements OnInit {
    get websiteId(): any {
        return this.domainId || undefined;
    }

    spinning: boolean = false;
    maxRangeSummeries: number = MAX_RANGE_SUMMERIES;
    windowRangeSummeries: number = WINDOW_RANGE_SUMMERIES;

    startDate: Date = new Date();
    endDate: Date = new Date();

    totalAttackChart: OneLineChart;
    topAttackTypeChart: any;
    topLargestAttackChart: any;

    sub01;

    getTotalAttackChart(data?) {
        data = data || [];
        return new OneLineChart(
            data,
            '',
            'value',
            '',
            'Total No of Attacks',
            ''
        );
    }

    getTopAttackTypeChart(data?) {
        data = data || [];
        return new TopPieChart(
            data,
            'Top Types of Attack',
            'Top Types of Attack'
        );
    }

    getTopLargestAttackChart(data?) {
        data = data || [];
        return new TopChart(
            data,
            '_id',
            'value',
            'top_largest_attack',
            'Largest Attack (bps)',
            true,
            false
        );
    }

    constructor(public router: Router,
                public activatedRoute: ActivatedRoute,
                public dialog: MatDialog,
                public permService: ClientPermService,
                public injector: Injector,
                public ddosMonService: DDosL4MonitorService,
                public attackMonitorService: AttackMonitorService) {
        super(router, activatedRoute, dialog, permService, injector);
        this.startDate.setDate(this.startDate.getDate() - 4);
    }

    ngOnInit() {
        super.ngOnInit();
        this.totalAttackChart = this.getTotalAttackChart();
        this.topAttackTypeChart = this.getTopAttackTypeChart();
        this.topLargestAttackChart = this.getTopLargestAttackChart();
    }

    reload() {
        this.search();
    }

    search(event?) {
        if (event) {
            this.startDate = event.start;
            this.endDate = event.end;
        }

        let time_from = SeriesUtils.startDateToUTC(this.startDate);
        let time_to = SeriesUtils.endDateToUTC(this.endDate);

        this.getTotalAttackMonNew(this.websiteId, time_from, time_to);
    }

    getTotalAttackMonNew(websiteId, timeFrom, timeTo) {
      let data = {
        'time_from': timeFrom,
        'time_to': timeTo,
        'ip_id': websiteId,
      };

      this.sub01 = this.ddosMonService.getTotalAttackMonNew(data).subscribe(res => {
        if (res.code === 200) {
          let resData = res.data;
          let attackTypeData = resData['top_attack_types'];
          let i = 0;
          let typeList = [];
          for (let at of attackTypeData) {
              i += 1;
              let a_att = new AttackType(
                  at._id,
                  at.count,
                  colors[i]
              );
              typeList.push(a_att);
          }
          this.topAttackTypeChart = this.getTopAttackTypeChart(typeList);
          this.totalAttackChart = this.getTotalAttackChart(resData.count_attack);
          let bandwidthDistribution = resData['attack_bandwidth_distribution'] || {};
          let topLargestBps = bandwidthDistribution.bps || [];

          // Top Largest Attack (bps)
          // check has data or not
          let eventLargest = topLargestBps.reduce((sum, x) => sum + x.value, 0);
          if (eventLargest == 0) {
              topLargestBps = [];
          }
          this.topLargestAttackChart = this.getTopLargestAttackChart(topLargestBps);

          this.cd.detectChanges();
        }
      });
    }

    getTotalAttackMon(websiteId, time_from, time_to) {
        let data = {
            from: moment(this.startDate).format('YYYY-MM-DD HH:mm'),
            to: moment(this.endDate).format('YYYY-MM-DD HH:mm'),
            ip_id: websiteId
        };

        this.sub01 = this.ddosMonService.getTotalAttackMon(data).subscribe(res => {
            let att_type = res.message;
            let attack_type_data = att_type.attack_type;
            let i = 0;
            let type_list = [];
            for (let at of attack_type_data) {
                i += 1;
                let a_att = new AttackType(
                    at._id,
                    at.count,
                    colors[i]
                );
                type_list.push(a_att);
            }
            this.topAttackTypeChart = this.getTopAttackTypeChart(type_list);
            this.totalAttackChart = this.getTotalAttackChart(att_type.count_attack);
            let topLargest = att_type.top_largest || {};
            let topLargestBps = topLargest.bps || [];

            // only for test
            // for(let item of topLargestBps) {
            //   item.value += Math.floor(Math.random() * 100)
            // }

            // Top Largest Attack (bps)
            // check has data or not
            let eventLargest = topLargestBps.reduce((sum, x) => sum + x.value, 0);
            if (eventLargest == 0) {
                topLargestBps = [];
            }
            this.topLargestAttackChart = this.getTopLargestAttackChart(topLargestBps);

            this.cd.detectChanges();

        });
    }
}
