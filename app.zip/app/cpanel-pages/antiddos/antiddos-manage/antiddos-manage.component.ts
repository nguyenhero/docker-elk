import { Component, OnInit, Injector, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { CustomerServiceService, CsUnitService } from '@common/swagger-services';
import { Router, ActivatedRoute } from '@angular/router';

import {
    WEBPROTECTION_ALIAS, WAF_ALIAS, DDOSL4_ALIAS, DDOSL7_ALIAS, WAF_SERVICE_NAME,
    MAX_CERT_KEY_SIZE, API_BASE_URL
} from '@customer/config';

import { DDosL4MonitorService } from '@common/ddosl4-services/monitor.service';
import { Subscription } from "rxjs/Subscription";
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { HeaderSidebarService } from '@customer/header-sidebar.service';
import { PlatformLocation } from '@angular/common';
import { HttpClient } from "@angular/common/http";
import { isMobileExtension, isTabletExtension } from "@common/utils/mobile";
import { TranslateService, LangChangeEvent } from "@ngx-translate/core";
import { ExportModalComponent } from './export-modal/export-modal.component';
import { MatIconRegistry, MatDialog } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';

@AutoUnsubscribe()
@Component({
    selector: 'app-antiddos-manage',
    templateUrl: './antiddos-manage.component.html',
    styleUrls: ['./antiddos-manage.component.scss']
})
export class AntiddosManageComponent implements OnInit, OnDestroy {
    loaded = false;
    _init_cc: string;

    ip_list: any[];
    ip_list_comsum: any[];
    ip_sel_id;
    websiteConsumption: any = {};

    selectedIndex = 0;

    sub20: Subscription = new Subscription();

    readonly serviceName = WAF_SERVICE_NAME;
    infoTabs: any;

    expression;

    sample_websiteConsumption = {
        highest_used_bps_day: "1 Kbps",
        highest_attack_bps_day: "1 Kbps",
        highest_attack_bps_month: "1.2 Kbps",
        no_attack_month: "12 tấn công",
        ip_address: "53.3.36.33",
        service_status: true,
        _id: "5c36ea4a779a1b2b5742bdee",
        service_name: 'AntiDDoS Layer 4',
    };

    allIPInfos = [];

    isMobileExtension = isMobileExtension;
    isTabletExtension = isTabletExtension;

    ALL_IP_ID = '__all_ip';

    get hasIp() {
        return this.ip_list && this.ip_list.length > 1;
    }

    constructor(
        iconRegistry: MatIconRegistry, sanitizer: DomSanitizer,
        public dialog: MatDialog,
        public activatedRoute: ActivatedRoute,
        public csUnitService: CsUnitService,
        public customerServiceService: CustomerServiceService,
        public ddosL4MonitorService: DDosL4MonitorService,
        public router: Router,
        public injector: Injector,
        public http: HttpClient,
        public translateService: TranslateService,
        public cd: ChangeDetectorRef,
        private _headerSidebar: HeaderSidebarService,
        private location: PlatformLocation
    ) {
        _headerSidebar.title = 'DDoS Protection';
        iconRegistry.addSvgIcon(
            'wa-export', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/web-analytics/Down _ ic-24.svg'));
    }

    ngOnInit() {
        this.infoTabs = [
            new Tab('Attack Monitoring', 'ATTACK'),
            new Tab('Attacked Logs', 'ALERT'),
            new Tab('Events', 'LOG'),
        ];

        this.sub20.add(this.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
            if (this.ip_sel_id === this.ALL_IP_ID) {
                // fix not change lang on select filter
                let tempList = this.ip_list;
                this.ip_list = [];
                this.cd.detectChanges();
                this.ip_list = tempList;
            }
        }));

        this.getAllIp(() => this.registerRouteChange());
        this.getDDosServiceStatus();
    }

    ngOnDestroy() {
        this.sub20.unsubscribe();
    }

    registerRouteChange() {
        this.sub20.add(this.activatedRoute.queryParams.subscribe(params => {
            this.ip_sel_id = params.cc || this.ALL_IP_ID;
            if (this.ip_sel_id === this.ALL_IP_ID) {
                this.getWebsiteConsumption();
            }
        }));
    }

    changeIp(event?) {
        if (!this.ip_sel_id) {
            return;
        }
        if (this.ip_sel_id === this.ALL_IP_ID) this.getWebsiteConsumption();

        this.updateRoute();
        this.cd.detectChanges();
    }

    ngModelChangeIP(event?) {
        if (this.ip_sel_id !== event) {
            this.ip_sel_id = event;
            setTimeout(() => this.changeIp(), 100);
        }
    }

    updateRoute() {
        if (!this.ip_sel_id) {
            return;
        }
        this.router.navigate([this.router.url.split('?')[0]],
            { queryParams: { 'cc': this.ip_sel_id, '_r': (new Date()).getTime() } });
    }

    getAllIp(cb?) {
        let limit = 100;
        let offset = 0;
        let services = [DDOSL4_ALIAS,];
        const customer_service_id = undefined;
        this.sub20.add(this.csUnitService.getCustomerServiceUnitList(limit, offset, services, customer_service_id).subscribe(resp => {
            this.loaded = true;
            let websites = resp.data.rows;
            this.ip_list = (websites || []).map(x => {
                return {
                    'name': x.identity,
                    'label': x.identity,
                    '_id': x._id,
                    'value': x._id,
                };
            });
            this.ip_list_comsum = (websites || []).map(x => {
                return x._id;
            });
            this.ip_list.unshift({
                'name': 'Tất cả',
                'label': 'Tất cả',
                '_id': this.ALL_IP_ID,
                'value': this.ALL_IP_ID,
            });
            try {
                let init_cc = this.activatedRoute.snapshot.queryParamMap.get('cc');
                if (init_cc) {
                    this.ip_sel_id = (this.ip_list.find(x => x._id === init_cc) || {})._id;
                }
                if (!this.ip_sel_id) {
                    this.ip_sel_id = this.ip_list[0]._id;
                }
            } catch (e) {
                this.ip_sel_id = undefined;
            }

            if (cb) cb();
        }));
    }

    getWebsiteConsumption() {
        let doc = {
            'ip_id': this.ip_list_comsum
        };
        this.sub20.add(this.ddosL4MonitorService.getServiceConsumptionMonthIp(doc)
            .subscribe(resp => {
                this.allIPInfos = resp.data;
            }));
    }

    onInfoChange(event) {
        /* remove dispatch resize */
        window.dispatchEvent(new Event('resize'));
    }

    isBoughtPackage;
    isConfiguredService;

    getDDosServiceStatus() {
        let url = API_BASE_URL + '/quick_config/resource/status/';
        this.sub20.add(this.http.get(url).subscribe((resp: any) => {
            const data: any = resp.data || {};
            this.isBoughtPackage = data['AntiDDoS Layer 4'].is_bought;
            this.isConfiguredService = data['AntiDDoS Layer 4'].is_configured;
            this.cd.detectChanges();
        }));
    }

    openDialog(component, model = {}, width?, height?, cb?) {
        const dialogRef = this.dialog.open(component, {
            autoFocus: false,
            width: width || '550px',
            maxWidth: '100%',
            height: height || '350px',
            maxHeight: '100%',
            data: model,
            disableClose: true
        });
        return dialogRef.afterClosed().subscribe((result: any) => {
            if (result) {
                cb(result.result);
            }
        });
    }

    doExport() {
        let current_ip = this.ip_list.find(x => x._id === this.ip_sel_id);
        console.log("current_ip", current_ip);
        this.openDialog(ExportModalComponent, {
            current_ip
        }, '350px', '180px', null);
    }
}

export class Tab {
    constructor(
        public title: string,
        public type: string,
        public active: boolean = false
    ) {
    }
}
