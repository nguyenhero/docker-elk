import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AntiddosManageComponent } from './antiddos-manage.component';

describe('AntiddosManageComponent', () => {
  let component: AntiddosManageComponent;
  let fixture: ComponentFixture<AntiddosManageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AntiddosManageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AntiddosManageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
