import { TranslateService } from '@ngx-translate/core';
import { SeriesUtils } from '@visc/visc-template';
import { MAX_RANGE_SUMMERIES, WINDOW_RANGE_SUMMERIES } from '@customer/config';
import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { Subscription } from 'rxjs';
import { saveAs } from "file-saver";
import { ActivatedRoute } from '@angular/router';
import { DDosL4MonitorService } from '../../../../common/ddosl4-services/monitor.service';
import * as moment from 'moment';

@AutoUnsubscribe()
@Component({
    selector: 'app-export-modal',
    templateUrl: './export-modal.component.html',
    styleUrls: ['./export-modal.component.scss']
})
export class ExportModalComponent implements OnInit, OnDestroy {

    maxRangeSummeries: number = MAX_RANGE_SUMMERIES;
    windowRangeSummeries: number = WINDOW_RANGE_SUMMERIES;
    startDate: Date = new Date();
    endDate: Date = new Date();


    startDate1: Date = new Date();
    endDate1: Date = new Date();
    startDate2: Date = new Date();
    endDate2: Date = new Date();

    isLoadingData = false;
    domainId: string;
    sub: Subscription;
    constructor(
        public translate: TranslateService,
        public dialogRef: MatDialogRef<ExportModalComponent>,
        public ddosMonService: DDosL4MonitorService,
        public activatedRoute: ActivatedRoute,
        @Inject(MAT_DIALOG_DATA) public data: any) {
        this.sub = this.activatedRoute.queryParams.subscribe(params => {
            if (params.cc == '__all_domain') return;
            // // console.log(this.domainId);
            if (this.domainId != params.cc) {
                this.domainId = params.cc;
            }
        });
    }

    ngOnInit() {


    }

    ngOnDestroy() {
    }
    search(event?) {
        if (event) {
            this.startDate = event.start;
            this.endDate = event.end;
        }
    }
    search1(event?) {
        if (event) {
            this.startDate1 = event.start;
            this.endDate1 = event.end;
        }
    }
    search2(event?) {
        if (event) {
            this.startDate2 = event.start;
            this.endDate2 = event.end;
        }
    }
    doExport() {
        this.isLoadingData = true;
        let time_from = SeriesUtils.startDateToUTC(this.startDate);
        let time_to = SeriesUtils.endDateToUTC(this.endDate);

        let time_from1 = SeriesUtils.startDateToUTC(this.startDate1);
        let time_to1 = SeriesUtils.endDateToUTC(this.endDate1);

        let time_from2 = SeriesUtils.startDateToUTC(this.startDate2);
        let time_to2 = SeriesUtils.endDateToUTC(this.endDate2);

        let ip_id = this.domainId;
        let data = {
            time_from,
            time_to,
            from_date: moment(time_from).format('YYYY-MM-DD HH:mm'),
            to_date: moment(time_to).format('YYYY-MM-DD HH:mm'),
            // time_from1,
            // time_to1,
            // time_from2,
            // time_to2,
            ip_id,
            lang: this.translate.currentLang,
        };
        console.log(data);
        this.ddosMonService.getExportDDOS(data).subscribe(resp => {
            this.isLoadingData = false;
            let filename = "";
            filename = `ReportDDOS_${moment(time_from).format('DD-MM-YYYY')}_${moment(time_to).format('DD-MM-YYYY')}.pdf`;

            saveAs(resp, filename);
            this.dialogRef.close();
        },
            err => {
                console.log("get error", err);
                this.isLoadingData = false;
                return;
            });
    }
    close() {
        this.dialogRef.close();
    }
}
