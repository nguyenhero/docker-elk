import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AntiddosManageComponent } from './antiddos-manage/antiddos-manage.component'

const ROUTER: Routes = [
  {
    path: '',
    component: AntiddosManageComponent
  }
];

export const antiddosManageRouter = RouterModule.forChild(ROUTER);
