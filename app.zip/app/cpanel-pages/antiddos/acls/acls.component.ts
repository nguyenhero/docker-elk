import { Component, OnInit, Injector } from '@angular/core';
import { BaseComponent } from '@common/components';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ClientPermService } from '@common/services';
import { Field, HiddenControl } from '@common/models';
import {
  swalNotiSuccess,
  swalShowConfirm,
  swalShowError,
  swalConfirmDelete,
  swalInputUniqueName
} from '@common/utils';

import {
  CsUnitService,
  CustomerServiceUnitACLUpdate
} from '@common/swagger-services';

import {
  AclsModalComponent,
  AclsModalEditComponent
} from '../acls-modal/acls-modal.component';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";

const TypeOptions = [
  { value: 'bl', label: 'Blacklist' },
  { value: 'wl', label: 'Whitelist' },
]

let onePoint = {
  'value': '2.3.4.5',
  'type': 'bl',
  'modified_time': new Date(),
  'desc': 'ip test',
  'active': true,
}

function typeRender(x) {
  return x == 'bl' ? 'Blacklist' : 'Whitelist';
}

function statusRender(x) {
  return x ? 'YES' : 'NO';
}

@AutoUnsubscribe()
@Component({
  selector: 'app-acls',
  templateUrl: './acls.component.html',
  styleUrls: [ './acls.component.scss' ]
})
export class AclsComponent extends BaseComponent implements OnInit {
  FIELDS = [
    new Field('value', 'Value', {}, {
      width: 180,
      minWidth: 110,
      maxWidth: 230
    }),
    new Field('type', 'Type', {
      'type': 'multiselect',
      'options': TypeOptions
    }, {
        'type': 'label_trans',
        'render': x => typeRender(x)
      }),
    new Field('modified_time', 'Modified Time', new HiddenControl(), {
      width: 90,
      minWidth: 90,
      maxWidth: 150,
    }),
    new Field('desc', 'Description', new HiddenControl(), {
      width: 90,
      minWidth: 90,
      maxWidth: 150,
    }),
    new Field('active', 'Active', new HiddenControl(), {
      width: 90,
      minWidth: 90,
      maxWidth: 150,
      'type': 'yesno',
      'render': x => statusRender(x)
    }),
    new Field('action', 'Thao tác', new HiddenControl(), {
      ref: this,
      type: 'actions',
      sortable: false,
      width: 90,
      minWidth: 90,
      maxWidth: 150,
      actions: [
        {
          icon: 'edit',
          click: row => this.editItem(row),
          tooltip: {
            tooltip: 'Edit',
            disabled: false,
            position: 'above',
            showDelay: 300
          }
        },
        {
          icon: 'delete',
          click: row => this.deleteItem(row),
          tooltip: {
            tooltip: 'Delete',
            disabled: false,
            position: 'above',
            showDelay: 300
          }
        }
      ]
    }),
  ]

  domainId: string;

  constructor(
    public router: Router,
    public activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    public permService: ClientPermService,
    public injector: Injector,
    public csUnitService: CsUnitService
  ) {
    super(router, activatedRoute, dialog, permService, injector);

    this.tableData.externalPaging = false;
    this.tableData.externalSorting = false;
  }

  ngOnInit() {
    super.ngOnInit();
    this.searchData.onNew = this.onNew.bind(this);
    this.searchData.onDelete = this.onDelete.bind(this);

    this.sub01 = this.activatedRoute.queryParams.subscribe(params => {
      if (this.domainId != params.cc) {
        this.domainId = params.cc;
        if (this.domainId) {
          this.search();
        }
      }
    });
  }

  onNew() {
    this.openDialog(AclsModalComponent, { model: {} }, (result) => {
      if (result && result.data) {
        let d = result.data;
        d = this.parseModalData(d);
        this.putAcl(d);
      }
    })
  }

  onDelete() {
    console.warn('NotImplementedError');
  }

  deleteItem(row) {
    swalShowConfirm('Thông báo', 'Bạn có muốn xóa ACL này không', resp => {
      this.deleteAcl(row.value);
    })
  }

  editItem(row) {
    let data = { ...row };
    data.ip = data.value;

    this.openDialog(AclsModalEditComponent, { model: data }, (result) => {
      if (result && result.data) {
        let d = result.data;
        d = this.parseModalData(d);
        this.putAcl(d);
      }
    })
  }

  parseModalData(d) {
    let ob = { ...d };
    ob.value = d.ip;
    return ob;
  }

  search(jumpToFirstPage = true) {
    if (jumpToFirstPage) {
      this.page.pageNumber = 0;
    }
    this.getAllAcl();
  }

  filter(data) {
    let m = this.model;
    let value_f = m.value ? (x => (x.value || "").indexOf(m.value) >= 0) : (x => true);
    let type_f = (m.type && m.type.length > 0) ? (x => m.type.indexOf(x.type) >= 0) : (x => true);
    let rl = data.filter(x => type_f(x) && value_f(x));
    return rl;
  }

  getAllAcl() {
    // TODO lap api
    let _id = this.domainId;
    this.sub02 = this.csUnitService.getCustomerServiceUnitAcls(_id)
      .subscribe(resp => {
        let rows = resp.data.rows;
        this.tableData.rows = this.filter(rows);
        this.tableData = { ...this.tableData };
        this.detectChanges();
      })
  }

  putAcl(data) {
    let _id = this.domainId;
    let cat = CustomerServiceUnitACLUpdate.ValueEnum.Ip;
    let doc = {
      value: cat,
      type: data.type,
      // uri: cat == 'uri' ? data.value : undefined,
      ip: data.value,
      desc: data.desc,
      active: data.active,
      port: 'all'
      // waf: data.waf,
      // ddosl7: data.ddosl7
    }

    this.sub03 = this.csUnitService.putCustomerServiceUnitAcls(_id, doc)
      .subscribe(resp => {
        swalNotiSuccess('Thông báo', 'Sửa ACL thành công');
        this.search();
      })
  }

  deleteAcl(value) {
    let _id = this.domainId;

    this.sub04 = this.csUnitService.deleteCustomerServiceUnitAcls(_id, value)
      .subscribe(resp => {
        swalNotiSuccess('Thông báo', 'Xoá ACL thành công');
        this.search();
      })
  }

  openDialog(component, model = {}, cb?) {
    const dialogRef = this.dialog.open(component, {
      autoFocus: false,
      width: '500px',
      maxWidth: '100%',
      height: '430px',
      maxHeight: '100%',
      data: model
    });
    this.sub01 = dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        cb(result.result);
      }
    });
  }

}
