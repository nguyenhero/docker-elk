import {Component, OnInit, Input, Output, SimpleChanges, EventEmitter, OnChanges, HostListener, OnDestroy} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';

import { CustomerServiceService, CsUnitService, PublicService } from '@common/swagger-services';


import { Subscription } from "rxjs/Subscription";
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { MatIconRegistry, MatListItem, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { formatBigNumber } from '@common/utils/utils';
import { swalShowWarn, _ } from '@common/utils';
import {isMobileExtension} from "@common/utils/mobile";

@AutoUnsubscribe()
@Component({
    selector: 'app-service-summary-antiddos-new',
    templateUrl: './service-summary-new.component.html',
    styleUrls: ['./service-summary-new.component.scss']
})
export class ServiceSummaryComponentNewComponent implements OnInit, OnChanges, OnDestroy {
    @Input() serviceName: string;
    @Input() websiteConsumption;
    @Input() summary_data;
    @Input() goDetailIp;
    @Output() onChangeIP = new EventEmitter();
    service: any = {
        package_name: '__',
    };

    formatBigNumber: any;
    isHideContent: boolean;
    private sub20: Subscription;

    isMobileExtension = isMobileExtension;

    get canUpgrade() {
        return this.service && this.service.canUpgrade;
    }

    constructor(
        public router: Router,
        public customerServiceService: CustomerServiceService,
        private publicService: PublicService,
        iconRegistry: MatIconRegistry, sanitizer: DomSanitizer,
    ) {
        this.isHideContent = this.isMobileExtension();
        iconRegistry.addSvgIcon(
            'cp-gear', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/gear.svg'));

    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.serviceName && this.serviceName) {
            this.getPackage();
        }
    }

    onClickChangeIP() {
        this.onChangeIP.emit();
    }

    ngOnInit() {
        this.formatBigNumber = formatBigNumber;
        console.log(this.websiteConsumption)
    }

    ngOnDestroy() {

    }

    @HostListener('window:resize', ['$event'])
    onResize(event) {
        if (!this.isMobileExtension()) {
            this.isHideContent = false;
        }
    }

    getPackage() {
        let u = undefined;
        let serviceNames = [this.serviceName];
        this.sub20 = this.customerServiceService.getCustomerServiceList(u, u, u, u, u, u, serviceNames)
            .subscribe(resp => {
                try {
                    this.service = resp.data.rows[0];
                } catch (e) {
                }
            });
    }

    goRenew() {
        // if (this.publicService.isProdVersion()) {
        //     swalShowWarn(_("Thông báo"), _("Chức năng sẽ sớm ra mắt trong thời gian tới"));
        //     return;
        // }
        let _id = this.service._id;
        this.router.navigate(['/c/payflow'],
            {
                queryParams: {
                    csId: _id,
                    substep: 2,
                    action: 'renew'
                }
            }).then();
    }

    goUpgrade() {
        // if (this.publicService.isProdVersion()) {
        //     swalShowWarn(_("Thông báo"), _("Chức năng sẽ sớm ra mắt trong thời gian tới"));
        //     return;
        // }
        let _id = this.service._id;
        this.router.navigate(['/c/payflow'],
            {
                queryParams: {
                    csId: _id,
                    action: 'upgrade'
                }
            }).then();
    }

    collapse() {
        this.isHideContent = !this.isHideContent;
    }

}
