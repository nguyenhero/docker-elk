import { Component, OnInit, Input, Injector } from '@angular/core';

import { DasboardTabPanelComponent } from '@common/components';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ClientPermService } from '@common/services';
import { AutoUnsubscribe } from "ngx-auto-unsubscribe";

@AutoUnsubscribe()
@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: [ './alerts.component.scss' ]
})
export class AlertsComponent extends DasboardTabPanelComponent implements OnInit {
  @Input() viewing: boolean;
  @Input() headerTitle: string = 'Events';
  constructor(
    public router: Router,
    public activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    public permService: ClientPermService,
    public injector: Injector,
  ) {
    super(router, activatedRoute, dialog, permService, injector);
  }

  ngOnInit() {
    super.ngOnInit();
  }

  reload() {
    // // console.log('search');
    // this.refreshData(true);
    // this.getWebsiteName(this.domainId);

  }

}
