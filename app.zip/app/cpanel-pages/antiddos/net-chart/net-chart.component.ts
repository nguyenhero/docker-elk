import {Component, OnInit, Injector, ChangeDetectorRef} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {ClientPermService} from '@common/services';
import {DasboardBaseComponent} from '@common/components';
import {MAX_RANGE_SUMMERIES, WINDOW_RANGE_SUMMERIES} from '@customer/config';
import {SeriesUtils} from '@visc/visc-template';
import {Subscription} from "rxjs/Subscription";
import {AutoUnsubscribe} from 'ngx-auto-unsubscribe';
import {DDosL4MonitorService} from '@common/ddosl4-services';
import {DeviceDetectorService} from "ngx-device-detector";
import * as moment from 'moment';

export const NetworkFields = [
    {'title': 'Input', 'field': 'input'},
    {'title': 'Blacklist', 'field': 'bl'},
    {'title': 'Whitelist', 'field': 'wl'},
    // {'title': 'Cleaned Output', 'field': 'clean'},
    {'title': 'Allowed Input', 'field': 'allowedInput'},
    {'title': 'Output', 'field': 'output'},
];

export const FpsField = [
    // {'title': 'Flow', 'field': 'Flow'},
    {title: 'All', field: 'all', tooltip: 'All'},
    {title: 'TCP', field: 'tcp', description: '5-tuple of combination: src IP, dst IP, src port, dst port, protocol'},
    {title: 'UDP', field: 'udp', description: '5-tuple of combination: src IP, dst IP, src port, dst port, protocol'},
    {title: 'ICMP', field: 'icmp', description: '3-tuple of combination: src IP, dst IP, protocol'},
];

class FiveLine {
    constructor(public date,
                public input,
                public bl,
                public wl,
                public clean,
                public output) {
    }
}

class NewFiveLine {
    constructor(public date,
                public input,
                public bl,
                public wl,
                public output,
                public allowedInput) {
    }
}

class FpsPoint {
    constructor(
      public date,
      public all,
      public tcp,
      public udp,
      public icmp,
    ) {}
}

@AutoUnsubscribe()
@Component({
    selector: 'app-net-chart',
    templateUrl: './net-chart.component.html',
    styleUrls: ['./net-chart.component.scss']
})
export class NetChartComponent extends DasboardBaseComponent implements OnInit {
    chartData = {
        'bps': [],
        'pps': [],
        'fps': [],
    };

    tabs = [
        {'title': 'bps', 'type': 'bps', 'metrics': NetworkFields},
        {'title': 'pps', 'type': 'pps', 'metrics': NetworkFields},
        {'title': 'fps', 'type': 'fps', 'metrics': FpsField, 'unit': 'flow'},
    ];

    cd: ChangeDetectorRef;

    spinning = false;
    maxRangeSummeries: number = MAX_RANGE_SUMMERIES;
    windowRangeSummeries: number = WINDOW_RANGE_SUMMERIES;
    isMobile: boolean;
    startDate: Date = new Date();
    endDate: Date = new Date();

    constructor(
        public router: Router,
        public activatedRoute: ActivatedRoute,
        public dialog: MatDialog,
        public permService: ClientPermService,
        public injector: Injector,
        public ddosMonService: DDosL4MonitorService,
        private deviceDetector: DeviceDetectorService
    ) {
        super(router, activatedRoute, dialog, permService, injector);
        this.isMobile = deviceDetector.isMobile();
        this.cd = this.injector.get(ChangeDetectorRef);
    }

    ngOnInit() {
        super.ngOnInit();
    }

    reload() {
        this.search();
    }

    search(event?) {
        if (event) {
            this.startDate = event.start;
            this.endDate = event.end;
        }

        let time_from = SeriesUtils.startDateToUTC(this.startDate);
        let time_to = SeriesUtils.endDateToUTC(this.endDate);

        let data = {
            from: moment(time_from).format('YYYY-MM-DD HH:mm'),
            to: moment(time_to).format('YYYY-MM-DD HH:mm'),
            ip_id: this.domainId
        };
        this.ddosMonService.getBandwidthMon(data).subscribe(resp => {
            if (resp.message) {
                this.parseNetworkData(resp.message, time_from, time_to);
            }
        });
        this.cd.detectChanges();
    }

    parseNetworkData(data, timeFrom, timeTo) {
        let bandwidth = data.ps || [];
        // let flowData = data.Flow || [];

        let bpsData = [];
        let ppsData = [];
        let fpsData = [];

        for (let band_ of bandwidth) {
            let bpsPoint = new NewFiveLine(
                band_['date'],
                band_['bps']['input'],
                band_['bps']['blacklist'],
                band_['bps']['whitelist'],
                band_['bps']['outgoing'],
                band_['bps']['totaloutput'],
            );
            let ppsPoint = new NewFiveLine(
                band_['date'],
                band_['pps']['input'],
                band_['pps']['blacklist'],
                band_['pps']['whitelist'],
                band_['pps']['outgoing'],
                band_['pps']['totaloutput'],
            );
            let fpsPoint = new FpsPoint(
                band_['date'],
                band_['fps']['all'],
                band_['fps']['tcp'],
                band_['fps']['udp'],
                band_['fps']['icmp'],
            );
            bpsData.push(bpsPoint);
            ppsData.push(ppsPoint);
            fpsData.push(fpsPoint);
        }

        // SET DATA BY DATE
        bpsData = SeriesUtils.fillMissingChartData(bpsData, timeFrom, timeTo, 'date', ['bl', 'allowedInput', 'input', 'output', 'wl']);
        ppsData = SeriesUtils.fillMissingChartData(ppsData, timeFrom, timeTo, 'date', ['bl', 'allowedInput', 'input', 'output', 'wl']);
        fpsData = SeriesUtils.fillMissingChartData(fpsData, timeFrom, timeTo, 'date', ['all', 'tcp', 'udp', 'icmp']);

        // // FILL EMPTY DATA
        // if (bpsData.length == 0)
        //     bpsData = SeriesUtils.fillEmptyChartData(timeFrom, timeTo, 'date', ['bl', 'clean', 'input', 'output', 'wl']);
        // if (ppsData.length == 0)
        //     ppsData = bpsData;
        // // if (flowData.length == 0) flowData = SeriesUtils.fillEmptyChartData(timeFrom, new Date(), 'date', ['Flow']);
        // if (fpsData.length == 0)
        //     fpsData = SeriesUtils.fillEmptyChartData(timeFrom, timeTo, 'date', ['all', 'tcp', 'udp', 'icmp']);

        this.chartData = {
            bps: bpsData,
            pps: ppsData,
            fps: fpsData,
        };
    }

    /**
     * Fill missing date bps.
     * @param start
     * @param end
     * @param data_chart
     */
    fillMissingDateBPS(start, end, data_chart) {
        let full_arr = [];
        let start_date = moment(start, "YYYY-MM-DD HH:mm").toDate();
        let end_date = moment(end, "YYYY-MM-DD HH:mm").toDate();

        let default_data = {};
        if (data_chart || data_chart[0]) {
            for (let k of Object.keys(data_chart[0])) {
                default_data[k] = 0;
            }
        }

        for (let t_ = start_date; t_ < end_date; t_.setMinutes(t_.getMinutes() + 1)) {
            let v = new Date();
            v = JSON.parse(JSON.stringify(t_));
            let str_date = moment(v).format("YYYY-MM-DD HH:mm");
            let v_ = JSON.parse(JSON.stringify(str_date));

            let index_ = check_key_exist(str_date, data_chart);
            if (index_ > -1) {
                full_arr.push(data_chart[index_]);
            } else {
                let def_data = JSON.parse(JSON.stringify(default_data));
                def_data['date'] = v_;
                full_arr.push(def_data);
            }
        }
        return full_arr;

        function check_key_exist(d, arr) {
            return arr.findIndex(x => x.date === d);
        }
    }

}
