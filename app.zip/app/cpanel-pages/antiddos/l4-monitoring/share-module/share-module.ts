import { NgModule } from '@angular/core';
import { COMMON_MODULES } from '@common/lazyload';

import { OneLineChartComponent } from './one-line-chart/one-line-chart.component';
import { TwoLineChartComponent } from './two-line-chart/two-line-chart.component';
import { TopPieChartComponent } from './top-pie-chart/top-pie-chart.component';
import { TopChartComponent } from './top-chart/top-chart.component';
import { MultipleLineChartComponent } from './multiple-line-chart/multiple-line-chart.component';
import { BandwidthChartComponent } from '../bandwidth-chart/bandwidth-chart.component';
import { TopLargestChartComponent } from './top-largest-chart/top-largest-chart.component';
// import { AlertDetailComponent } from '../alerts/alert-detail/alert-detail.component';
import {IPValidator} from './custom-validators';

@NgModule({
	imports: [
		...COMMON_MODULES,
	],
	declarations: [
		OneLineChartComponent,
		TwoLineChartComponent,
		TopPieChartComponent,
		TopChartComponent,
		MultipleLineChartComponent,
		BandwidthChartComponent,
		TopLargestChartComponent,
		// AlertDetailComponent
		IPValidator
	],
	exports: [
		OneLineChartComponent,
		TwoLineChartComponent,
		TopPieChartComponent,
		TopChartComponent,
		MultipleLineChartComponent,
		BandwidthChartComponent,
		TopLargestChartComponent,
		// AlertDetailComponent
		IPValidator
	]
})
export class ShareModule { }