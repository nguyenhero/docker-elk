export class TopChart {
  constructor(
	// public params: any,
    // public url: string,
	public topData: any,
  public name: string,
  public value: string,
	public field: string,
	public chart_id: string,
  public reload: boolean,
  public isSmall?: boolean
  ) {
    if(isSmall == undefined){
      isSmall = false;
    }
  }
}