import { Component, OnInit, Input, OnChanges, SimpleChange } from '@angular/core';

import { Http } from '@angular/http';
import { AmChartsService } from '@amcharts/amcharts3-angular';
import { TranslateService } from "@ngx-translate/core";

import { TopChart } from './topchart.model';

import { swalNotiSuccess } from '@common/utils';

@Component({
    selector: 'app-top-chart',
    templateUrl: './top-chart.component.html',
    styleUrls: ['./top-chart.component.scss']
})
export class TopChartComponent implements OnInit, OnChanges {
    @Input() topchart: TopChart;
    @Input() dynamic: string = 'off';
    @Input() labelLength: number = undefined;
    @Input() balloonCategory: string = 'off';
    @Input() balloonCategoryTitle: string;
    @Input() copyCategory: string = 'off';

    @Input() color: string;
    @Input() fixedColumnWidth: number;
    @Input() themeThin: boolean = false;

    @Input() balloonOnlyValue: boolean = false;
    @Input() valueTitle: string;
    @Input() integersOnly = true;

    get isDynamic() {
        return this.dynamic == 'on';
    }

    model = {};
    chartData: any;
    isEmpty: number = 0;
    chartName = "";
    isSmall: boolean = false;
    hideHeader;

    generateChartData() {
    }

    public chartOP: any;

    constructor(
        public amCharts: AmChartsService,
        public translateService: TranslateService,
        public http: Http) {
    }

    ngOnChanges(changes: { [propTopChart: string]: SimpleChange }): void {
        this.isEmpty = 0;
        this.isSmall = this.topchart ? this.topchart.isSmall : false;
        this.initChart();
    }

    ngOnInit() {
        this.initChart();
    }

    initChart() {
        if (this.topchart) {
            this.chartData = this.topchart.topData;
            this.chartName = this.topchart.chart_id;
        }

        if (!this.topchart || !this.topchart.topData) {
            this.isEmpty = 0;
        } else {
            if (!this.chartData.length || (this.chartData.length === 1 && !this.chartData[0]['reqs'])) {
                this.isEmpty = 1;
            } else {
                this.isEmpty = 2;
                setTimeout(() => {
                    this.callChart();
                }, 0);
            }
        }
    }

    callChart() {
        let chartData = this.chartData;
        // let chartData = this.chartData.map(x => {
        //     return {
        //         percent: 10 + '%',
        //         ...x,

        //     };
        // });
        let trans = this.translateService;
        let config = {
            "type": "serial",
            "categoryField": this.topchart.name,
            "rotate": true,
            "theme": "light",
            "fontSize": 12,
            "color": "#676A75",
            // "plotAreaFillAlphas": 1,
            // "plotAreaFillColors": "rgba(107, 108, 115, 0.1)",
            "plotAreaBorderAlpha": 1,
            "plotAreaBorderColor": "rgba(107, 108, 115, 0.1)",

            "categoryAxis": {
                "labelRotation": 45,
                "gridPosition": "start",
                "position": "left",
                "cursorTooltipEnabled": true,
                "tickLength": 0,
                "gridAlpha": 0,
                "axisAlpha": 0,
                "gridColor": "#FFFFFF",
                "axisColor": "#FFFFFF",
                "color": "#676A75",
            },
            "chartCursor": {
                "categoryBalloonEnabled": false,
                "enabled": true,
                "categoryBalloonColor": "#ffffff00",
                "cursorColor": "#b2b7c2",
                "fullWidth": true,
                "valueLineAlpha": 0,
                "cursorAlpha": 0.3,
                "categoryBalloonAlpha": 0,
            },
            "graphs": [
                {
                    "columnWidth": 0.5,
                    "fixedColumnWidth": (this.themeThin) ? 2 : this.fixedColumnWidth || 15,
                    "balloonFunction": function (graphDataItem) {
                        let value = graphDataItem.values.value;
                        let msg = "";
                        if (!this.balloonOnlyValue) {
                            if (graphDataItem.dataContext.hasOwnProperty('total_req'))
                                msg = "Requests: <span style='color:" + this.color + "'>" + value + "&nbsp;</span>";
                            else if (graphDataItem.dataContext.hasOwnProperty('conns'))
                                msg = "Connections: <span style='color:" + this.color + "'>" + value + "&nbsp;</span>";
                            else if (graphDataItem.dataContext.hasOwnProperty('reqs'))
                                msg = "Requests: <span style='color:" + this.color + "'>" + value + "&nbsp;</span>";
                            else if (graphDataItem.dataContext.hasOwnProperty('cnt'))
                                msg = trans.instant("NUM_ATTACKS") + ": <span style='color:" + this.color + "'>" + value + "&nbsp;</span>";
                            else
                                msg = trans.instant("Quantity") + ": <span style='color:" + this.color + "'>" + value + "&nbsp;</span><span>" + trans.instant('attack(s)');
                        } else {
                            msg = trans.instant("Quantity") + ": <span style='color:" + this.color + "'>" + value + "&nbsp;</span><span>" + trans.instant('attack(s)');
                        }

                        if (this.balloonCategory === 'on' && !!this.balloonCategoryTitle) {
                            let msgRange = trans.instant(this.balloonCategoryTitle) + ": " + graphDataItem.category;
                            return `<div class="ballon-box-top-chart" style="text-align: left; max-width: 350px"><span>${msgRange}</span><br><span>${msg}</span></div>`;
                        }
                        return `<div class="ballon-box-top-chart"><span>${msg}</span></div>`;
                    }.bind(this),
                    "fillAlphas": 1,
                    "id": "AmGraph-1",
                    "lineAlpha": 0,
                    "title": "Income",
                    "type": "column",
                    "labelText": "[[percent]]",
                    "valueField": this.topchart.value, //"conns",
                    "fillColors": this.color || "#c3c3c3",
                    "bulletColor": this.color || "#c3c3c3"
                }
            ],
            "guides": [],
            "valueAxes": [{
                "id": "ValueAxis-1",
                "axisColor": "#676A75",
                "dashLength": 2,
                "gridThickness": 2,
                "tickLength": 0,
                "color": "#676A75",
                "position": "bottom",
                "labelFunction": function (value) {
                    if (value >= 1000000000)
                        return (Math.round(value / 1000000000)) + "G";
                    else if (value >= 1000000)
                        return (Math.round(value / 1000000)) + "M";
                    else if (value >= 1000)
                        return "" + (Math.round(value / 1000)) + "k";
                    else
                        return value;
                },
                "title": this.valueTitle,
                "integersOnly": this.integersOnly,
            }],
            "allLabels": [],
            "balloon": {
                "animationDuration": 0,
                "borderAlpha": 0,
                "borderColor": "#000000",
                "borderThickness": 0,
                "color": "#FFFFFF",
                "cornerRadius": 1,
                "fillAlpha": 1,
                "fillColor": "#dadfe6",
                "horizontalPadding": 4,
                "pointerWidth": 6,
                "shadowAlpha": 0,
                "showBullet": true,
                "textAlign": " middle"
            },
            "titles": [],
            "dataProvider": chartData,
            "listeners": [{
                "event": "rendered",
                "method": addListener.bind(this)
            }]
        };
        if (this.labelLength) {
            config.categoryAxis['labelFunction'] = function (valueText) {
                if (valueText.length > this.labelLength)
                    return valueText.substring(0, this.labelLength) + '...';
                else
                    return valueText;
            }.bind(this);
        }
        let chart = this.amCharts.makeChart(this.topchart.chart_id, config);
        this.chartOP = chart;

        function addListener() {
            if (this.copyCategory != 'on') {
                return;
            }
            setTimeout(() => {
                let categoryAxis = chart.categoryAxis;
                categoryAxis.addListener("clickItem", handleClick);
                categoryAxis.addListener("rollOverItem", handleOver);
                categoryAxis.addListener("rollOutItem", handleOut);
            });
        }

        function handleClick(event) {
            let category = event.serialDataItem.category;
            const el = document.createElement('textarea');
            el.value = category;
            document.body.appendChild(el);
            el.select();
            document.execCommand('copy');
            document.body.removeChild(el);
            swalNotiSuccess('Thông báo', 'Sao chép thành công');
        }

        function handleOut(event) {
            event.target.setAttr("cursor", "default");
            event.target.setAttr("fill", "#000000");
        }

        function handleOver(event) {
            event.target.setAttr("cursor", "pointer");
            event.target.setAttr("fill", "#CC0000");
        }
    }
}
