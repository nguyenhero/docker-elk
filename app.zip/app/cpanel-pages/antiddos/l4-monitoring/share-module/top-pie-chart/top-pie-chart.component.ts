import {Component, Input, OnChanges, OnInit, SimpleChange} from '@angular/core';
import {TopPieChart} from './topPieChart.model';
import {AmChartsService} from '@amcharts/amcharts3-angular';
import {TranslateService} from "@ngx-translate/core";
import {DeviceDetectorService} from 'ngx-device-detector';

declare var AmCharts: any;

@Component({
    selector: 'app-top-pie-chart',
    templateUrl: './top-pie-chart.component.html',
    styleUrls: ['./top-pie-chart.component.scss']
})
export class TopPieChartComponent implements OnInit, OnChanges {
    @Input() toppieChart: TopPieChart;
    @Input() hideHeader = false;
    @Input() isColorField = false;
    @Input() themeDonut = false;
    @Input() themeLegendMarker = 'rect';
    @Input() showNoDataChart = false;
    @Input() heightChart: string;
    @Input() legendPosition: string;
    @Input() noBoxShadow = false;
    @Input() forceLegendPosition: string;

    themePanStyle;
    colors: string[] = [
        "#ed4036",
        "#f07821",
        "#6a8923",
        "#1f2b3b",
        "#f2ddaa"
    ];
    chartData: any;
    chartName = "";
    topPie;
    isEmpty = 0;
    isMobile: boolean;

    constructor(
        public amCharts: AmChartsService,
        public translateService: TranslateService,
        private deviceService: DeviceDetectorService) {
        this.isMobile = this.deviceService.isMobile();
    }

    ngOnChanges(changes: { [proptoppieChart: string]: SimpleChange }): void {
        this.isEmpty = 0;
        if (!this.toppieChart || !this.toppieChart.chartData) {
            this.isEmpty = 0;
        } else {
            this.chartData = this.toppieChart.chartData;
            this.chartName = this.toppieChart.chart_id;
            if (!this.chartData) {
                this.isEmpty = 1;
            } else {
                if (this.chartData.length == 0) {
                    this.isEmpty = 1;
                } else {
                    let S = 0;
                    for (let item of this.chartData) S += item.value;
                    if (S !== 0) {
                        this.isEmpty = 2;
                        this.makeChart();
                    } else this.isEmpty = 3;
                }
            }
        }
        if (this.isEmpty == 1 && this.showNoDataChart) {
            this.isEmpty = 3;
            this.makeChart();
        }
    }

    ngOnInit() {
        this.translateService.onLangChange.subscribe((event) => {
            this.makeChart();
        });
    }

    getNumberOfCategories() {
        let categories = {};
        for (let item of this.chartData) {
            categories[item.label] = true;
        }
        let noc = 0;
        for (let key in categories) noc++;
        return noc;
    }

    isXLargeWidth() {
        return window.innerWidth > 1700;
    }

    getLegendSetting() {
        let noc = this.getNumberOfCategories();
        if (noc === 4) noc = 2;
        else if (noc === 5) noc = 3;
        else noc = 40;
        let base = {
            "align": (this.isMobile || !this.isXLargeWidth()) ? "center" : "left",
            "theme": "custom",
            "position": (this.isMobile || !this.isXLargeWidth()) ? "bottom" : "right",
            "maxColumns": (this.isMobile || !this.isXLargeWidth()) ? noc : 1,
            "valueText": "",
            "autoMargins": false,
            "marginBottom": 0,
            "marginLeft": 0,
            "marginRight": this.isMobile ? 10 : 30,
            "marginTop": 0,
            "horizontalGap": 15,
            "markerLabelGap": 10,
            "verticalGap": 5,
            "fontSize": this.isMobile ? 11 : 14,
            "equalWidths": this.isMobile || !this.isXLargeWidth(),
            "markerBorderAlpha": 1 // important
        };

        let m = {
            'circle': {
                "markerType": "circle",
                "markerSize": 10,
                "markerBorderAlpha": 0
            },
            'rect': {
                "markerSize": 10,
                "markerType": "square"
            }
        };
        let updated = m[this.themeLegendMarker];
        for (let k of Object.keys(updated)) {
            base[k] = updated[k];
        }
        return base;
    }

    private getOrderOfSeverity(label) {
        label = label.toLowerCase();
        if (label === 'critical') return 0;
        else if (label === 'high') return 1;
        else if (label === 'medium') return 2;
        else if (label === 'low') return 3;
        else return 4;
    }

    translateLabelChart(data) {
        try {
            let d = data.map(r => {
                let colorIdx = this.getOrderOfSeverity(r.label);
                return {
                    label: this.translateService.instant(r.label).toUpperCase(),
                    value: r.value,
                    order: colorIdx,
                    color: this.colors[colorIdx]
                };
            });
            d.sort((a, b) => a.order - b.order);
            return d;
        } catch (e) {
            return data;
        }
    }

    makeChart() {
        setTimeout(() => this.callChart(), 20);
    }

    callChart() {
        let chartId = this.toppieChart.chart_id;
        let chartConfig: any = {
            "type": "pie",
            "startDuration": 0,
            "theme": "custom",
            "addClassNames": true,
            "fontSize": 14,
            "outlineColor": "",
            "innerRadius": this.themeDonut ? ((this.isMobile || this.isXLargeWidth()) ? 40 : 30) : 0,
            "legend": this.getLegendSetting(),
            "labelText": "",
            "labelsEnabled": false,
            "defs": {
                "filter": [{
                    "id": "shadow",
                    "width": "200%",
                    "height": "200%",
                    "feOffset": {
                        "result": "offOut",
                        "in": "SourceAlpha",
                        "dx": 10,
                        "dy": 10
                    },
                    "feGaussianBlur": {
                        "result": "blurOut",
                        "in": "offOut",
                        "stdDeviation": 10
                    },
                    "feFlood": {
                        "flood-color": "#ffffff",
                        "flood-opacity": 0.44,
                        "result": "flood",
                    },
                    "feComposite": {
                        "in": "blurOut",
                        "in2": "flood",
                        "operator": "xor",
                        "result": "blurAlpha"
                    },
                    "feBlend": {
                        "in": "SourceGraphic",
                        "in2": "blurAlpha",
                        "mode": "normal"
                    }
                }]
            },
            "dataProvider": this.isColorField ? this.translateLabelChart(this.chartData) : this.chartData,
            "valueField": "value",
            "titleField": "label",
            "listeners": [{
                "event": "rendered",
                "method": renderedEvent
            }]
        };
        if (this.isColorField) {
            chartConfig.colors = this.colors;
            chartConfig.colorField = 'color';
        }
        if (!this.isMobile) {
            chartConfig = {
                ...chartConfig,
                ...{
                    "autoMargins": false,
                    "marginTop": 45,
                    "marginLeft": 45,
                    "marginRight": 45,
                    "marginBottom": 45,
                }
            };
        } else if (this.legendPosition !== 'left') {
            chartConfig = {
                ...chartConfig,
                ...{
                    "autoMargins": false,
                    "innerRadius": "40%",
                    "marginTop": 15,
                    "marginLeft": 45,
                    "marginRight": 45,
                    "marginBottom": 15,
                }
            };
        }

        if (this.isEmpty === 3) {
            let chartConfigUpdate = {
                legend: undefined,
                outlineAlpha: 1,
                outlineColor: "",
                innerRadius: "100%",
                colors: ["#aab3b3"],
                dataProvider: [
                    {value: 1, label: ' '}
                ],
                balloon: {
                    "enabled": false
                },
                // allLabels: [
                //     {
                //         "align": "center",
                //         "id": "Label-1",
                //         "size": 12,
                //         "text": this.translateService.instant("No Attack"),
                //         "y": "46%"
                //     }
                // ],
            };
            chartConfig = {...chartConfig, ...chartConfigUpdate};
        }

        this.topPie = this.amCharts.makeChart(this.toppieChart.chart_id, chartConfig);

        function renderedEvent(event) {
            let element = document.getElementsByClassName("amcharts-pie-item");
            for (let idx = 0; idx < element.length; idx++) {
                let elm = element.item(idx);
                let parent = elm.parentElement;
                if (parent && !parent.classList.contains('amcharts-pie-item-all')) {
                    parent.classList.add('amcharts-pie-item-all');
                }
            }
        }

        this.topPie.addListener("rendered", renderedEvent);
    }
}
