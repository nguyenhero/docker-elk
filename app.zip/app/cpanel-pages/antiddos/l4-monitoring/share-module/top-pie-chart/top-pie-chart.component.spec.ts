import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopPieChartComponent } from './top-pie-chart.component';

describe('TopPieChartComponent', () => {
  let component: TopPieChartComponent;
  let fixture: ComponentFixture<TopPieChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopPieChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
