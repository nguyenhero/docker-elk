export class TopPieChart {
  constructor(
	public chartData: any,
    public name: string,
	public chart_id: string)
	{ }
}