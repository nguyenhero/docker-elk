import { Directive } from '@angular/core';
import { NG_VALIDATORS } from '@angular/forms';

export function validateIP(IPCtrl) {
    var split_ips;
    let res = null;
    if (!IPCtrl.value ||
        !(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/.test(IPCtrl.value))) {
				res = { 'invalidHAIP': true };
			}
	return res;
}

@Directive({
	selector: '[IP-input]',
	providers: [{ provide: NG_VALIDATORS, useValue: validateIP, multi: true }]
})
export class IPValidator { }