import { Component, Inject, OnInit, AfterViewInit, Input, OnChanges, SimpleChange } from '@angular/core';
import { OneLineChart } from './oneLineChart.model';

import { HttpClient } from "@angular/common/http";
import { AmChartsService } from '@amcharts/amcharts3-angular';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'app-one-line-chart',
    templateUrl: './one-line-chart.component.html',
    styleUrls: ['./one-line-chart.component.scss']
})
export class OneLineChartComponent implements OnInit, OnChanges {
    @Input() onelineChart: OneLineChart;
    @Input() offValueTitle = 'off';
    themePanStyle;

    chartData: any;
    chartName = "";
    public oneLine;

    isEmpty = 0;

    constructor(
        public translate: TranslateService,
        public amCharts: AmChartsService,
        public http: HttpClient) {
    }

    ngOnChanges(changes: { [proponelineChart: string]: SimpleChange }): void {
        this.isEmpty = 0;
        if (!this.onelineChart.chartData) {
            this.isEmpty = 0;
        } else {
            this.chartData = this.onelineChart.chartData;
            this.chartName = this.onelineChart.chart_id;
            if (!this.chartData) {
                this.isEmpty = 1;
            } else {
                if (this.chartData.length == 0) {
                    this.isEmpty = 1;
                } else {
                    this.isEmpty = 2;
                    setTimeout(() => {
                        this.callChart();
                    }, 0);
                }
            }
        }
    }

    ngOnInit() {
    }

    callChart() {
        let unit = this.onelineChart.axes ? this.translate.instant(this.onelineChart.axes) : undefined;
        let config = {
            type: 'serial',
            theme: 'light',
            dataProvider: this.chartData,
            labelsEnabled: false,
            // Style
            "fontSize": 12,
            "color": "#676A75",
            // "plotAreaBorderAlpha": 1,
            // "plotAreaBorderColor": "rgba(107, 108, 115, 0.1)",

            'graphs': [{
                'id': 'g1',
                balloonFunction: (graphDataItem, graph) => {
                    let value = graphDataItem.values.value;
                    if (!unit) {
                        return `<div class="ballon-box-one-line-chart" style="text-align: left; max-width: 350px">
                        <span class="l-value" style="color: #FF7B10">${value}&nbsp;</span>
                    </div>`;
                    }

                    return `<div class="ballon-box-one-line-chart" style="text-align: left; max-width: 350px">
                                <span class="l-value" style="color: #FF7B10">${value}&nbsp;</span>
                                <span class="l-unit">${unit}</span>
                            </div>`;
                },
                'bullet': 'round',
                'bulletSize': 8,
                'hideBulletsCount': 30,
                'lineColor': '#268AFF',
                'lineThickness': 1.5,
                'negativeLineColor': '#268AFF',
                'valueField': this.onelineChart.value,
                "fillAlphas": 0
            }],
            'chartCursor': {
                'categoryBalloonDateFormat': 'DD/MM',
                'cursorAlpha': 0,
                'valueLineEnabled': true,
                'valueLineBalloonEnabled': true,
                'valueLineAlpha': 0.5,
                'fullWidth': true
            },
            'dataDateFormat': 'YYYY-MM-DD HH:NN',
            'categoryField': 'date',
            'categoryAxis': {
                "dateFormats": [
                    {
                        "period": "hh",
                        "format": "JJ:NN"
                    },
                    {
                        "period": "DD",
                        "format": "DD/MM"
                    },
                    {
                        "period": "WW",
                        "format": "DD/MM"
                    },
                    {
                        "period": "MM",
                        "format": "MM"
                    },
                    {
                        "period": "YYYY",
                        "format": "YYYY"
                    }],
                'minPeriod': 'hh',
                'parseDates': true,
                'minorGridAlpha': 0.1,
                'minorGridEnabled': true,
                'equalSpacing': true,
                // Style
                "tickLength": 0,
                "gridAlpha": 0,
                "axisAlpha": 0,
                "gridColor": "#FFFFFF",
                "axisColor": "#FFFFFF",
                "color": "#676A75",
            },
            "balloon": {
                "animationDuration": 0,
                "borderAlpha": 0,
                "borderColor": "#000000",
                "borderThickness": 0,
                "color": "#FFFFFF",
                "fillAlpha": 1,
                "fillColor": "#dadfe6",
                "horizontalPadding": 4,
                "pointerWidth": 6,
                "shadowAlpha": 0,
                "showBullet": true,
                "textAlign": "middle"
            },
            "valueAxes": [{
                "title": this.onelineChart.axes,
                "integersOnly": true,
                "axisAlpha": 0.1,
                "gridAlpha": 0.2,

                // Style
                "axisColor": "#676A75",
                "dashLength": 2,
                "gridThickness": 2,
                "tickLength": 0,
                "color": "#676A75",
            }]
        };
        if (this.offValueTitle === 'off') {
            for (let v of config.valueAxes) {
                delete v['title'];
            }
        }
        this.oneLine = this.amCharts.makeChart(this.onelineChart.chart_id, config);
    }

}
