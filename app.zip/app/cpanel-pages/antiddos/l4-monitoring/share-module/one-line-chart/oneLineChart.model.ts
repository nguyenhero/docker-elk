export class OneLineChart {
  constructor(
    public chartData: any,
    //public url: string,
    public name: string,
    public value: string,
    public field: string,
    public chart_id: string,
    //public params: any,
    public axes: string) {
  }
}