export class MultipleLineChart {
    constructor(
        public chartData: any,
        public name: string, // date
        public field: any, // key to get data
        public chart_id: string, // NAME of Chart, UNIQUE with each Chart
        public legend_arr: any, // [(valueX + titleX)]
        public axes: string, // Don vi (reqs/s, bits/s)
        public no_line: number,
        public bullet: boolean = false,
        public smooth: boolean = true,
        public fill: boolean = true,
    ) { }
}
