import {
    Component,
    Inject,
    OnInit,
    AfterViewInit,
    Input,
    OnChanges,
    SimpleChange,
    ChangeDetectorRef,
    OnDestroy
} from '@angular/core';
import { AmChartsService } from '@amcharts/amcharts3-angular';
import {
    getFixedChartCategoryDateFormat,
    getChartDateFormat,
    translateZoomTextConfig,
    getMinHorizontalGap
} from '@common/theme/chart';
import { TranslateService } from "@ngx-translate/core";
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { DeviceDetectorService } from 'ngx-device-detector';
import { HttpClient } from "@angular/common/http";
import * as moment from 'moment';

@AutoUnsubscribe()
@Component({
    selector: 'app-multiple-line-chart',
    templateUrl: './multiple-line-chart.component.html',
    styleUrls: ['./multiple-line-chart.component.scss']
})
export class MultipleLineChartComponent implements OnInit, OnChanges, OnDestroy {
    @Input() position: string;
    @Input() positionAlign:string;
    @Input() hideLegend = false;
    @Input() legendDiv ;
    @Input() mullineChart: mulChart;
    @Input() hideHeader = false;
    @Input() balloonDateFormat: string;
    @Input() durationFormat: string;
    @Input() chartHeight: number = 300;
    @Input() colors = [
        '#268AFF', //waf
        '#FF7B10',
        '#9cc9e2',
        '#81C340',
        '#DD8439'
    ];

    model = {};
    chartData: any;
    chartName = "";
    isEmpty = 0;
    mulLine;

    determinateValue = 0;
    progressValue = 60;
    color = 'primary';
    graphSetting: any;
    sub01;

    private isDesktopDevice: boolean;
    private isMobile: boolean;

    constructor(
        public amCharts: AmChartsService,
        public cd: ChangeDetectorRef,
        public translate: TranslateService,
        public http: HttpClient,
        private deviceService: DeviceDetectorService) {
        this.isDesktopDevice = this.deviceService.isDesktop();
        this.isMobile = this.deviceService.isMobile();
    }

    ngOnInit() {
        this.sub01 = this.translate.onLangChange.subscribe((event) => {
            this.callChart();
        });
    }

    ngOnDestroy() {

    }

    ngOnChanges(changes: { [propMulLineChart: string]: SimpleChange }): void {
        this.isEmpty = 0;
        let categoryBalloonDateFormat = this.balloonDateFormat ||
            (this.durationFormat) ? getChartDateFormat(this.durationFormat) : 'HH:NN DD/MM/YYYY';
        if (this.mullineChart) {
            this.graphSetting = {
                type: 'serial',
                theme: 'light',
                // Style
                "fontSize": 12,
                "color": "#676A75",
                // "plotAreaBorderAlpha": 1,
                // "plotAreaBorderColor": "rgba(107, 108, 115, 0.1)",
                legend: {
                    "enabled": !this.hideLegend,
                    "divId": this.legendDiv,
                    "valueText": "",
                    "position": this.position || "bottom",
                    "horizontalGap": 0,
                    "markerLabelGap": 10,
                    "verticalGap": 5,
                    "markerSize": 10,
                    "markerType": "square",
                    "fontSize": this.isMobile ? 11 : 14,
                    "equalWidths": false,
                    'autoMargins': false,
                    'marginLeft': this.isMobile ? 16 : 0,
                    'marginRight': 20,
                    "marginBottom": this.isMobile ? 3 : 8,
                    "align": this.positionAlign || "center",
                    "spacing": this.isMobile ? 10 : 20
                },
                dataProvider: this.chartData,
                labelsEnabled: false,
                mouseWheelZoomEnabled: false,
                'graphs': [],
                'dataDateFormat': 'YYYY-MM-DD HH:NN',
                'categoryField': 'date',
                'categoryAxis': {
                    'minPeriod': 'mm',
                    'parseDates': true,
                    'equalSpacing': true, // do data deu nen de true
                    'gridThickness': 1,
                    "boldPeriodBeginning": true,
                    'dateFormats': getFixedChartCategoryDateFormat(),
                    "minHorizontalGap": getMinHorizontalGap(),
                    "startOnAxis": true,

                    // Style
                    "tickLength": 0,
                    "gridAlpha": 0,
                    "axisAlpha": 0,
                    "gridColor": "#FFFFFF",
                    "axisColor": "#FFFFFF",
                    "color": "#676A75",
                },
                "valueAxes": [{
                    "integersOnly": true,
                    "axisAlpha": 0,
                    "gridAlpha": 0.17,
                    "includeHidden": true,
                    // Style
                    "axisColor": "#676A75",
                    "dashLength": 2,
                    "gridThickness": 2,
                    "tickLength": 0,
                    "color": "#676A75",
                }],
                'chartCursor': {
                    'categoryBalloonDateFormat': categoryBalloonDateFormat,
                    'cursorAlpha': 0,
                    'valueLineEnabled': true,
                    'valueLineBalloonEnabled': true,
                    'valueLineAlpha': 0.5,
                    'fullWidth': true,
                    "cursorColor": "#272829",
                },
                "balloon": {
                    "animationDuration": 0,
                    "borderAlpha": 0,
                    "borderColor": "#000000",
                    "borderThickness": 0,
                    "color": "#FFFFFF",
                    "fillAlpha": 1,
                    "fillColor": "#dadfe6",
                    "horizontalPadding": 4,
                    "pointerWidth": 6,
                    "shadowAlpha": 0,
                    "showBullet": true,
                    "textAlign": "middle"
                },
                "responsive": {
                    "enabled": true
                }
            };
            this.graphSetting = translateZoomTextConfig(this.graphSetting, this.translate);
            if (this.mullineChart.customCategoryAxis) {
                for (let key of Object.keys(this.mullineChart.customCategoryAxis)) {
                    if (this.graphSetting.categoryAxis.hasOwnProperty(key)) {
                        this.graphSetting.categoryAxis[key] = this.mullineChart.customCategoryAxis[key];
                    }
                }
            }
        }

        if (!this.mullineChart || (!this.mullineChart.allowEmptyData && (!this.mullineChart.chartData || !this.mullineChart.chartData.length))) {
            this.isEmpty = 0;
        } else {
            this.chartData = [];
            for (let each_chart of this.mullineChart.chartData) {
                let new_a = {};
                for (let a_chart of this.mullineChart.field) {
                    new_a[a_chart] = each_chart.data[a_chart];
                }
                new_a['date'] = each_chart.date;
                this.chartData.push(new_a);
            }
            this.chartName = this.mullineChart.chart_id;
            if (!this.chartData) {
                this.isEmpty = 1;
            } else {
                if (this.chartData.length == 0) {
                    this.isEmpty = 1;
                } else {
                    this.isEmpty = 2;
                    setTimeout(() => {
                        this.callChart();
                    }, 20);
                }
            }
        }
        this.cd.detectChanges();
    }

    callChart() {
        if (this.mullineChart) {
            let graphs = [];
            let bullet = this.mullineChart.bullet;
            try {
                if (this.chartData.length == 1) bullet = true;
            } catch (e) {
            }
            for (let i = 0; i < this.mullineChart.no_line; i++) {
                let valueField = this.mullineChart.field[i];
                let unit = this.mullineChart.axes ? this.translate.instant(this.mullineChart.axes) : undefined;
                let title = this.translate.instant(this.mullineChart.legend_arr[i] ||
                    this.mullineChart.field[i]);
                let g: any = {
                    id: 'g' + i,
                    balloonFunction: (graphDataItem, graph) => {
                        let value = graphDataItem.values.value;
                        if (!unit) {
                            return `<div class="ballon-box-multi-chart" style="text-align: left; max-width: 350px">
                            <span class="l-title">${title}</span>:
                            <span class="l-value" style="color: ${this.colors[i]}">${value}&nbsp;</span>
                        </div>`;
                        }

                        return `<div class="ballon-box-multi-chart" style="text-align: left; max-width: 350px">
                                    <span class="l-title">${title}</span>:
                                    <span class="l-value" style="color: ${this.colors[i]}">${value}&nbsp;</span>
                                    <span class="l-unit">${unit}</span>
                                </div>`;
                    },
                    title,
                    useLineColorForBulletBorder: true,
                    // bullet: bullet ? "round" : "",
                    // bulletSize: 2,
                    // hideBulletsCount: 30,
                    lineColor: this.colors[i],
                    lineThickness: 1.5,
                    negativeLineColor: '#637bb6',
                    valueField: valueField,
                    fillAlphas: this.mullineChart.fill ? 1 : 0,
                    lineAlpha: 1,
                    // bulletAlpha: 1,
                    // bulletBorderAlpha: 1,
                };
                if (this.mullineChart.smooth) g.type = 'smoothedLine';

                graphs.push(g);
            }
            for (let item of graphs) {
                if (item.title === 'ddos') item.title = 'AntiDDoS L7';
                else if (item.title === 'waf') item.title = 'WAF';
            }
            this.graphSetting.graphs = graphs;
            this.graphSetting.dataProvider = this.chartData;
            this.mulLine = this.amCharts.makeChart(this.mullineChart.chart_id, this.graphSetting);
        }
    }

}

export class mulChart {
    constructor(
        public chartData: any,
        public name: string, // date
        public field: any, // key to get data
        public chart_id: string, // NAME of Chart, UNIQUE with each Chart
        public legend_arr: any, // [(valueX + titleX)]
        public axes: string, // Don vi (reqs/s, bits/s)
        public no_line: number,
        public bullet: boolean = false,
        public smooth: boolean = true,
        public fill: boolean = true,
        public allowEmptyData: boolean = false,
        public customCategoryAxis: any = null,
    ) {
    }
}
