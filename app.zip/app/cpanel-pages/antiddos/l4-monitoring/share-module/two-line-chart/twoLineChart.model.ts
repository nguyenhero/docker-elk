export class TwoLineChart {
  constructor(
    //public url: string,
	public chartData: any,
    public name: string,
    public value1: string, // IN or ALLOW
	public value2: string,	// OUT or DENY
	public field: string,
	public chart_id: string,
	//public params: any,
	public title1: string, // ==value1, value2
	public title2: string,
	public axes: string) {
  }
}