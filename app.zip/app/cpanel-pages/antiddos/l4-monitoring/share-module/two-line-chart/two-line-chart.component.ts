import { Component, Inject, OnInit, AfterViewInit, Input, OnChanges, SimpleChange } from '@angular/core';

import { TwoLineChart } from './twoLineChart.model';

import { Http, Response } from '@angular/http';
import { AmChartsService } from '@amcharts/amcharts3-angular';

//import {API} from '../api_global';

@Component({
	selector: 'app-two-line-chart',
	templateUrl: './two-line-chart.component.html',
	styleUrls: ['./two-line-chart.component.scss']
})
export class TwoLineChartComponent implements OnInit, OnChanges {
	@Input() twolineChart: TwoLineChart;

	//url = API.url + 'ws_api/event_monitoring/get_node_mon/';
	model = {};
	chartData: any;
	chartName = "";
	isEmpty: number = 0;

	public twoLine;

	determinateValue: number = 0;
	progressValue = 60;
	color = 'primary';

	constructor(public amCharts: AmChartsService,
		public http: Http) { }

	ngOnInit() {
		// this.isEmpty = 0;
	}

	ngOnChanges(changes: { [propTwoLineChart: string]: SimpleChange }): void {
		this.isEmpty = 0;
		// console.log('TwoLineChart change detected!');
		// console.log(this.twolineChart);
		if (!this.twolineChart || !this.twolineChart.chartData) {
			//this.chartData = [];
			this.isEmpty = 0;
		}
		else {
			this.chartData = this.twolineChart.chartData;
			this.chartName = this.twolineChart.chart_id;
			if (!this.chartData) {
				this.isEmpty = 1;
			}
			else {
				if (this.chartData.length == 0) {
					this.isEmpty = 1;
				}
				else {
					this.isEmpty = 2;
					setTimeout(()=>{
						this.callChart();
					},0);
				}
			}
		}


	}

	callChart() {
		// console.log(this.twolineChart.chart_id);
		this.twoLine = this.amCharts.makeChart(this.twolineChart.chart_id, {
			// pathToImages: 'assets/am_images/',
			type: 'serial',
			theme: 'light',
			legend: {
				"equalWidths": false,
				"position": "top",
				"valueAlign": "left",
				"valueWidth": 100
			},
			dataProvider: this.chartData,
			labelsEnabled: false,
			mouseWheelZoomEnabled: false,
			'graphs': [{
				'id': 'g1',
				// 'balloonText': '[[category]]<br><b><span style=\'font-size:14px;\'>[[this.twolineChart.value1]]</span></b>',
				"balloonFunction": function (graphDataItem, graph) {
					var value = graphDataItem.values.value;
					return "" + value;
				},
				'title': this.twolineChart.title1,
				'bullet': 'round',
				'bulletSize': 8,
				'hideBulletsCount': 30,
				'lineColor': '#43B4D4',
				'lineThickness': 1.5,
				'negativeLineColor': '#637bb6',
				//'type': 'smoothedLine',
				'valueField': this.twolineChart.value1//'value1'
			},
			{
				'id': 'g2',
				// 'balloonText': '<br><b><span style=\'font-size:14px;\'>[[this.twolineChart.value2]]</span></b>',
				"balloonFunction": function (graphDataItem, graph) {
					//var category = graphDataItem.dataContext.date;
					var value = graphDataItem.values.value;
					//return "OUT: " + value;
					return "" + value;
				},
				'title': this.twolineChart.title2,
				'bullet': 'round',
				'bulletSize': 8,
				'hideBulletsCount': 30,
				'lineColor': '#d1655d',
				'lineThickness': 1.5,
				'negativeLineColor': '#637bb6',
				//'type': 'smoothedLine',
				'valueField': this.twolineChart.value2//'value2'
			}
			],
			// 'chartScrollbar': {
			// 'graph': 'g1',
			// 'gridAlpha': 0,
			// 'color': '#888888',
			// 'scrollbarHeight': 55,
			// 'backgroundAlpha': 0,
			// 'selectedBackgroundAlpha': 0.1,
			// 'selectedBackgroundColor': '#888888',
			// 'graphFillAlpha': 0,
			// 'autoGridCount': true,
			// 'selectedGraphFillAlpha': 0,
			// 'graphLineAlpha': 0.2,
			// 'graphLineColor': '#c2c2c2',
			// 'selectedGraphLineColor': '#888888',
			// 'selectedGraphLineAlpha': 1

			// },
			'chartCursor': {
				'categoryBalloonDateFormat': 'YYYY-MM-DD HH:NN',
				'cursorAlpha': 0,
				'valueLineEnabled': true,
				'valueLineBalloonEnabled': true,
				'valueLineAlpha': 0.5,
				'fullWidth': true
			},
			'dataDateFormat': 'YYYY-MM-DD HH:NN',
			'categoryField': 'date',
			'categoryAxis': {
				'minPeriod': 'mm',
				'parseDates': true,
				'minorGridAlpha': 0.1,
				'minorGridEnabled': true,
				'equalSpacing': true
			},
			"valueAxes": [{
				//"inside": true,
				"title": this.twolineChart.axes,
				"integersOnly": true,
				"axisAlpha": 0.1,
				"gridAlpha": 0.2
			}]
		});

	}
}


