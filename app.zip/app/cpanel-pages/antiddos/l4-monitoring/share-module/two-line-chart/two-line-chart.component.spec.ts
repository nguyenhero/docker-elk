import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TwoLineChartComponent } from './two-line-chart.component';

describe('TwoLineChartComponent', () => {
  let component: TwoLineChartComponent;
  let fixture: ComponentFixture<TwoLineChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TwoLineChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TwoLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
