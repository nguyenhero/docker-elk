import { Component, Inject, OnInit, AfterViewInit, Input, OnChanges, SimpleChange } from '@angular/core';

import { TopLargestChart } from './topLargestChart.model';

import { AmChartsService } from '@amcharts/amcharts3-angular';

@Component({
	selector: 'app-top-largest-chart',
	templateUrl: './top-largest-chart.component.html',
	styleUrls: ['./top-largest-chart.component.scss']
})
export class TopLargestChartComponent implements OnInit {
	@Input() toplargestChart: TopLargestChart;
	chartData: any;
	chartName = "";
	public topLargest;

	isEmpty: number = 0;

	constructor(public amCharts: AmChartsService) { }

	ngOnChanges(changes: { [proptoplargestChart: string]: SimpleChange }): void {
		this.isEmpty = 0;
		if (!this.toplargestChart.chartData) {
			//this.chartData = [];
			this.isEmpty = 0;
		}
		else {
			// console.log(this.toplargestChart);
			this.chartData = this.toplargestChart.chartData;
			this.chartName = this.toplargestChart.chart_id;
			if (!this.chartData) {
				this.isEmpty = 1;
			}
			else {
				if (this.chartData.length == 0) {
					this.isEmpty = 1;
				}
				else {
					this.isEmpty = 2;
					setTimeout(() => {
						this.callChart();
					},
						0);
				}
			}
		}

		// console.log(this.isEmpty);
	}

	ngOnInit() {
		this.topLargest = 0;
	}

	callChart() {
		// console.log(this.chartData);
		this.topLargest = this.amCharts.makeChart(this.toplargestChart.chart_id, {
			"type": "serial",
			"theme": "light",
			"categoryField": "range",
			"rotate": true,
			"startDuration": 1,
			"categoryAxis": {
				"gridPosition": "start",
				"position": "left"
			},
			"legend": {
				"position": "bottom",
				"marginRight": 100,
				"autoMargins": false
			},
			"trendLines": [],
			"graphs": [
				{
					//"balloonText": "Bps:[[value]]",
					"balloonFunction": function (graphDataItem, graph) {
						let value = graphDataItem.values.value;
						if (value >= 1000000000)
							return "Bps: " + (Math.round(value / 1000000000)) + "G";
						else if (value >= 1000000)
							return "Bps: " + (Math.round(value / 1000000)) + "M";
						else if (value >= 1000)
							return "Bps: " + (Math.round(value / 1000)) + "k";
						else
							return "Bps: " + value;
					},
					"fillAlphas": 0.8,
					"id": "AmGraph-1",
					"lineAlpha": 0.2,
					"title": "Bps",
					"type": "column",
					"valueField": "bps"
				},
				{
					// "balloonText": "Pps:[[value]]",
					"balloonFunction": function (graphDataItem, graph) {
						let value = graphDataItem.values.value;
						if (value >= 1000000000)
							return "Pps: " + (Math.round(value / 1000000000)) + "G";
						else if (value >= 1000000)
							return "Pps: " + (Math.round(value / 1000000)) + "M";
						else if (value >= 1000)
							return "Pps: " + (Math.round(value / 1000)) + "k";
						else
							return "Pps: " + value;
					},
					"fillAlphas": 0.8,
					"id": "AmGraph-2",
					"lineAlpha": 0.2,
					"title": "Pps",
					"type": "column",
					"valueField": "pps"
				}
			],
			"guides": [],
			"valueAxes": [
				{
					"id": "ValueAxis-1",
					"position": "top",
					"axisAlpha": 0,
					"labelFunction": function (value) {
						if (value >= 1000000000)
							return (Math.round(value / 1000000000)) + "G";
						else if (value >= 1000000)
							return (Math.round(value / 1000000)) + "M";
						else if (value >= 1000)
							return "" + (Math.round(value / 1000)) + "k";
						else
							return parseInt(value, 10);
					}
				}
			],
			"allLabels": [],
			"balloon": {},
			"titles": [],
			"dataProvider": this.chartData
		});

	}
}
