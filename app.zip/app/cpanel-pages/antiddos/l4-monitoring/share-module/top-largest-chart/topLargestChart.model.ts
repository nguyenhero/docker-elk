export class TopLargestChart {
  constructor(
	public chartData: any,
    public name: string,
	public chart_id: string)
	{ }
}