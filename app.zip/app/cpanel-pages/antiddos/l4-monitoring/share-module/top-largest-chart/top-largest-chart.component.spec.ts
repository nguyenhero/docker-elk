import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopLargestChartComponent } from './top-largest-chart.component';

describe('TopLargestChartComponent', () => {
  let component: TopLargestChartComponent;
  let fixture: ComponentFixture<TopLargestChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopLargestChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopLargestChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
