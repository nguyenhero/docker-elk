export class Tab {
	constructor(
		public title: string,
		//public content: string,
		public type: string,
		public active: boolean=false
	) {	}
}