import { NgModule } from '@angular/core';
import { COMMON_MODULES } from '@common/lazyload';

import { UserMonitoringComponent } from './user-monitoring.component';
import { UserMonitoringRouter } from './user-monitoring.router';
import { MatTableModule } from '@angular/material/table';
import { ShareModule } from '../share-module/share-module';

import { AmChartsService } from '@amcharts/amcharts3-angular';


import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
// import { BandwidthChartComponent } from '../bandwidth-chart/bandwidth-chart.component';
import { SummaryComponent } from './summary/summary.component';
import { TopAttackComponent } from './top-attack/top-attack.component';
import { UserAlertComponent } from './user-alert/user-alert.component';
import { AlertDetailComponent } from './user-alert/alert-detail/alert-detail.component';
import { AclMitigationComponent } from './user-alert/alert-detail/acl-mitigation/acl-mitigation.component';
import { PcapSampleComponent } from './user-alert/alert-detail/pcap-sample/pcap-sample.component';
import { UserLogComponent } from './user-log/user-log.component';
import { OperationDialogComponent } from './user-log/operation-dialog/operation-dialog.component';

@NgModule({
  imports: [
    ...COMMON_MODULES,
    MatTableModule,
    UserMonitoringRouter,
    ShareModule
  ],
  declarations: [
    UserMonitoringComponent,
    // BandwidthChartComponent,
    SummaryComponent,
    TopAttackComponent,
    UserAlertComponent,
    AlertDetailComponent,
    AclMitigationComponent,
    PcapSampleComponent,
    UserLogComponent,
    OperationDialogComponent
  ],
  providers: [
    AmChartsService
  ],
  entryComponents: [
    AlertDetailComponent,
    OperationDialogComponent
  ],
  exports: [
    UserMonitoringComponent,
    SummaryComponent,
    TopAttackComponent,
    UserAlertComponent,
    AlertDetailComponent,
    AclMitigationComponent,
    PcapSampleComponent,
    UserLogComponent,
    OperationDialogComponent
  ]
})
export class UserMonitoringModule { }
