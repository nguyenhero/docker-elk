import { Component, OnInit, Input, OnChanges, SimpleChange } from '@angular/core';
import { Http, Response } from '@angular/http';
import { MatTableModule } from '@angular/material/table';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {
  @Input() largestIps: any;
  model: any = {};
  displayedColumns = ['name', 'desc'];
  dataSource: any;
  largest: any;
  usageChartData: any;
  // usageGraph: TwoLineChart;
  system_id = "5afcdb20fd00a3678e9547ed";
  ELEMENT_DATA: Element[];

  // ACLs
  whiteListIP: IP[] = [];
  whiteListIP_len: number = 0;
  blackListIP: IP[] = [];
  blackListIP_len: number = 0;
  inputIP: string;
  desc_white: string;
  desc_black: string;
  // reformat value
  largest_bps_re: any;
  largest_pps_re: any;

  constructor(public http: Http) { }

  ngOnInit() {
    this.search();
    this.whiteListIP_len = this.whiteListIP.length;
    this.blackListIP_len = this.blackListIP.length;
  }

  ngOnChanges(changes: { [propLargest: string]: SimpleChange }): void {
    // console.log(this.largestIps);
    this.initData();
  }

  initData() {
    if (this.largestIps) {
      this.largest = new largestDetail(
        this.largestIps['bps'],
        this.largestIps['pps'],
        this.largestIps['type'],
        '12.34.56.78');
        this.largest_bps_re = this.formatBigNumber(this.largestIps['bps']);
        this.largest_pps_re = this.formatBigNumber(this.largestIps['pps']);
      this.ELEMENT_DATA = [
        { name: 'IP Address', value: 0, desc: '88.8.88.8' },
        { name: 'Start Time', value: 4.0026, desc: 'Jul 6, 2018 16:18:58 PM' },
        { name: 'Lastest Attack', value: 0, desc: 'Jul 6, 2018 16:18:58 PM' },
        { name: 'Largest Attack', value: 6.941, desc: 'abcd' },
        // { name: 'Max bps', value: 14.0067, desc: this.largestIps['bps'] },
        // { name: 'Max pps', value: 15.9994, desc: 0 },
        // { name: 'Max Flow', value: 18.9984, desc: 0 }
        { name: 'Status', value: 6.941, desc: 'SAFE' }
      ];
      this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
    }
  }

  removeItem(IP_) {
    let index = this.whiteListIP.indexOf(IP_);
    this.whiteListIP.splice(index, 1);
    this.whiteListIP_len = this.whiteListIP.length;
    // console.log(index);
  }

  addIP(inputIP, desc) {
    this.whiteListIP.push(
      new IP(inputIP, desc)
    );
    this.whiteListIP_len = this.whiteListIP.length;
  }

  removeItem_black(IP_) {
    let index = this.blackListIP.indexOf(IP_);
    this.blackListIP.splice(index, 1);
    this.blackListIP_len = this.blackListIP.length;
    // console.log(index);
  }

  addIP_black(inputIP, desc) {
    this.blackListIP.push(
      new IP(inputIP, desc)
    );
    this.blackListIP_len = this.blackListIP.length;
  }

  update_acls() {
    // console.log(this.blackListIP);
    // console.log(this.whiteListIP);
    this.http.post('http://192.168.2.76/test/update_acls', {
      'system_id': this.system_id,
      'blackIP': this.blackListIP,
      'whiteIP': this.whiteListIP
    })
      .subscribe((res: Response) => {
        // console.log(res.json());
      });
  }

  search() {
    this.http.post('http://192.168.2.76/test/get_acls', {
      'system_id': this.system_id
    })
      .subscribe((res: Response) => {
        // console.log(res.json());
        this.blackListIP = res.json().message.blackIP;
        this.blackListIP_len = this.blackListIP.length;
        this.whiteListIP = res.json().message.whiteIP;
        this.whiteListIP_len = this.whiteListIP.length;
      });
  }

  formatBigNumber(value) {
    if (value >= 1000000000)
      return (Math.round(value / 1000000000)) + " G";
    else if (value >= 1000000)
      return (Math.round(value / 1000000)) + " M";
    else if (value >= 1000)
      return "" + (Math.round(value / 1000)) + " k";
    else
      return value + " ";
  }
}

export class largestDetail {
  constructor(
    public bps: number,
    public pps: number,
    public type: string,
    public dstIP: string) { }
}


export interface Element {
  name: string;
  value: number;
  desc: string;
}

export class IP {
  constructor(
    public ip: string,
    public desc: string) {
  }
}