import { Component, OnInit, Inject } from '@angular/core';
import { Http, Response, HttpModule } from '@angular/http';
import { MatTableModule } from '@angular/material/table';
import { MatTableDataSource } from '@angular/material';
import { FormGroup, FormControl } from '@angular/forms';

import {
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material';

@Component({
  selector: 'app-operation-dialog',
  templateUrl: './operation-dialog.component.html',
  styleUrls: ['./operation-dialog.component.scss']
})
export class OperationDialogComponent implements OnInit {
  username: string;
  status: string;
  type: string;
  srcip: string;
  time: string;
  message: string;
  severity: string;

  constructor(public dialogRef: MatDialogRef<OperationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    // console.log(this.data.model);
    this.username = this.data.model.user;
    this.status = this.data.model.status;
    this.type = this.data.model.type;
    this.srcip = this.data.model.sourceIp;
    this.time = this.data.model.timestamp;
    this.message = this.data.model.message;
    // this.severity = "HIGH";
  }

  close() {
    this.dialogRef.close({reload: true});
  }

}
