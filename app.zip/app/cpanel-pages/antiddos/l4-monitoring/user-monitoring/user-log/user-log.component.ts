import { Component, OnInit, ViewChild, Input, OnDestroy, Injector } from '@angular/core';
import { TableModels } from '@visc/visc-template';
import { TOOLTIP } from '@common/modules';
import { BaseComponent } from '@common/components';
import { Http, Response, HttpModule } from '@angular/http';

import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';

import { swalNotiSuccess, swalShowConfirm, swalShowError } from '@common/utils';
import { AlertDetailComponent } from '../user-alert/alert-detail/alert-detail.component';
import { OperationDialogComponent } from './operation-dialog/operation-dialog.component';

import { ClientPermService } from '@common/services';

import Field = TableModels.Field
import HiddenControl = TableModels.HiddenControl;

class Model {
  category: string;
}
@Component({
  selector: 'app-user-log',
  templateUrl: './user-log.component.html',
  styleUrls: ['./user-log.component.scss']
})
export class UserLogComponent extends BaseComponent {
  selectedTemp: any;
  system_id = "5afcdb20fd00a3678e9547ed";
  rows: any=[];

  FIELDS = [
    new Field('type', 'Type'),
    new Field('status', 'Status'),
    new Field('srcip', 'Src IP'),
    new Field('username', 'User'),
    new Field('message', 'Message'),
    new Field('time', 'Timestamp'),
    new Field('severity', 'Severity'),
    new Field('', 'Info', new HiddenControl(),
      {
        ref: this,
        type: 'actions',
        actions: [
          {
            icon: 'info_outline',
            click: row => this.viewDetail(row),
            tooltip: TOOLTIP.VIEW_DETAIL
          }
        ],
        minWidth: 50
      })
  ];
  model: Model = { category: undefined };
  config = {
    styles: {
      'width': '650px',
      'max-width': '100%',
    }
  };

  constructor(public router: Router,
    public activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    public http: Http,
    public permService: ClientPermService,
    public injector: Injector) {
    super(router, activatedRoute, dialog, permService, injector);

    this.tableData.externalPaging = false;
    this.tableData.externalSorting = false;
  }

  ngOnInit() {
    super.ngOnInit();
    this.searchData = undefined;
    this.search();
  }

  search() {
    this.http.post('http://192.168.2.76/test/get_logs',
      {
        'system_id': this.system_id
      })
      .subscribe((res: Response) => {
        let logs_arr = res.json().message;
        // console.log(res.json());
        this.tableData.rows = res.json().message;
        let row_tmp = [];
        let severity_arr = ['low', 'high', 'normal'];
        for (let a_row of logs_arr) {
          let sev = severity_arr[Math.floor(Math.random() * severity_arr.length)];
          let row = new Row(
            a_row.type,
            a_row.status,
            a_row.srcip,
            a_row.username,
            a_row.message,
            a_row.time,
            sev,
            a_row._id,
            a_row.refid
          );
          row_tmp.push(row);
        }
        this.rows = row_tmp;
      });
  }

  viewDetail(row) {
    // console.log('viewAttack Detail');
    let r_ = this.rows.find(x => x.id == row);

    if (r_.att_id !== -1) { //.refid
      let dialogRef = this.dialog.open(AlertDetailComponent,
        {
          width: '100%',
          height: '100%',
          data: { _id: r_.att_id } // .refid
        }); //row.refid 
      let sub00 = dialogRef.afterClosed().subscribe((result: any) => {
        if (result && result.reload) {
          this.search();
        }
      });
    }
    else {
      let dialogRef = this.dialog.open(OperationDialogComponent, {
        autoFocus: false,
        width: '500px',
        data: { model: r_ }
      });

      let sub00 = dialogRef.afterClosed().subscribe((result: any) => {
        if (result && result.reload) {
          this.search();
        }
      });
    }
  }

  // Use Fosec template Datatable
  columns = [
    { name: 'Type' },
    { name: 'Status' },
    { name: 'Source Ip' },
    { name: 'User' },
    { name: 'Message' },
    { name: 'Timestamp' },
    { name: 'Severity' },
    { name: 'Id' }
  ];

}

export class Row {
  constructor(
    public type: string,
    public status: string,
    public sourceIp: string,
    public user: string,
    public message: string,
    public timestamp: string,
    public severity: string,
    public id: string,
    public att_id: string
  ) {}
}
