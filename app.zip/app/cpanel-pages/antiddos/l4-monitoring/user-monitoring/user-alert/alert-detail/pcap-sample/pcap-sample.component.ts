import { Component, OnInit, ViewChild, Input, OnDestroy, OnChanges, SimpleChange, Injector } from '@angular/core';
import { TableModels } from '@visc/visc-template';
import { TOOLTIP } from '@common/modules';
import { BaseComponent } from '@common/components';
import { Http, Response, HttpModule, ResponseContentType } from '@angular/http';

import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { swalNotiSuccess, swalShowConfirm, swalShowError } from '@common/utils';

import { ClientPermService } from '@common/services';

import Field = TableModels.Field
import HiddenControl = TableModels.HiddenControl;

class Model {
	category: string;
}

@Component({
	selector: 'app-pcap-sample',
	templateUrl: './pcap-sample.component.html',
	styleUrls: ['./pcap-sample.component.scss']
})
export class PcapSampleComponent extends BaseComponent {
	@Input() pcap_input: any;

	pcap_list: any = [];

	rows: any = [];

	selectedTemp: any;
	FIELDS = [
		new Field('inbound', 'Inbound'),
		new Field('outbound', 'Outbound'),
		new Field('time', 'Time'),
		new Field('', 'Download', new HiddenControl(),
			{
				ref: this,
				type: 'actions',
				actions: [
					{
						icon: 'get_app',
						click: row => this.downloadPcapFile(row),
						tooltip: TOOLTIP.DOWNLOAD
					}
				],
				minWidth: 50
			})
	];
	model: Model = { category: undefined };
	config = {
		styles: {
			'width': '650px',
			'max-width': '100%',
		}
	};
	constructor(public router: Router,
		public activatedRoute: ActivatedRoute,
		public dialog: MatDialog,
		public http: Http,
		public permService: ClientPermService,
		public injector: Injector) {
		super(router, activatedRoute, dialog, permService, injector);
		this.tableData.externalPaging = false;
		this.tableData.externalSorting = false;
	}
	ngOnInit() {
		super.ngOnInit();
		this.searchData = undefined;
		this.getPcaplist();
	}

	ngOnChanges(changes: { [propPcap: string]: SimpleChange }): void {
		// // console.log(this.pcap_input);
		// if (this.pcap_input) {
		// 	let pcap_ = {};
		// 	let i = this.pcap_input;
		// 	pcap_['inbound'] = i['inbound']['filename'];
		// 	pcap_['outbound'] = i['outbound']['filename'];
		// 	pcap_['port'] = i['inbound']['port'];
		// 	pcap_['time'] = i['time'];
		// 	this.tableData.rows = [pcap_];

		// 	//
		// 	let fr = new Row(
		// 		i['inbound']['filename'],
		// 		i['outbound']['filename'],
		// 		pcap_['time'] = i['time'],
		// 		""
		// 	);
		// 	this.rows = [fr];
		// }
		// // console.log(this.tableData.rows);
	}

	getPcaplist() {
		this.http.get('http://192.168.2.76/test/get_pcap_file_list')
			.subscribe((res: Response) => {
				// console.log(res.json());
				this.pcap_list = res.json().message;
				// this.tableData.rows = this.pcap_list;
				this.rows = this.pcap_list;
			});
	}

	downloadPcapFile(pcap) {
		let url_pcap = "http://192.168.2.67/pcap/192.168.3.1/" + pcap.name;

		return this.http.get(url_pcap, {
			responseType: ResponseContentType.Blob
		})
			.map(res => {
				return {
					filename: pcap.name,
					data: res.blob()
				};
			})
			.subscribe(res => {
				// // console.log('start download pcap:', res);
				var url = window.URL.createObjectURL(res.data);
				var a = document.createElement('a');
				document.body.appendChild(a);
				a.setAttribute('style', 'display: none');
				a.href = url;
				a.download = res.filename;
				a.click();
				window.URL.revokeObjectURL(url);
				a.remove(); // remove the element
			}, error => {
				// console.log('download pcap error:', JSON.stringify(error));
			}, () => {
				// console.log('Completed pcap file download.')
			});
	}

	columns = [
		// { name: 'Inbound' },
		{ name: 'Name' },
		{ name: 'Timestamp' },
		{ name: 'Download' }
	];
}

export class Row {
	constructor(
		public name: string,
		// public outbound: string,
		public timestamp: string,
		public download: string
	) { }
}
