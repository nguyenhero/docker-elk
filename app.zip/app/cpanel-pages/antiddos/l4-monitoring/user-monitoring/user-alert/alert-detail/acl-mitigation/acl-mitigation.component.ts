import { Component, OnInit, ViewChild, Input, OnDestroy, OnChanges, SimpleChange, Injector } from '@angular/core';
import { TableModels } from '@visc/visc-template';
import { TOOLTIP } from '@common/modules';
import { BaseComponent } from '@common/components';
import { Http, Response, HttpModule } from '@angular/http';

import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { swalNotiSuccess, swalShowConfirm, swalShowError } from '@common/utils';

import { ClientPermService } from '@common/services';

import Field = TableModels.Field
import HiddenControl = TableModels.HiddenControl;

class Model {
	category: string;
}

@Component({
	selector: 'app-acl-mitigation',
	templateUrl: './acl-mitigation.component.html',
	styleUrls: [ './acl-mitigation.component.scss' ]
})
export class AclMitigationComponent extends BaseComponent {
	@Input() acl_input: any;
	selectedTemp: any;

	rows: any = [];

	FIELDS = [
		new Field('dstip', 'Destination IP'),
		new Field('proto', 'Protocol'),
		new Field('attack_type', 'Attack Type'),
		new Field('TargetBandwidth', 'Target Bandwidth'),
		new Field('TargetBandwidthRatio', 'Ratio'),
		new Field('time', 'Timestamp')
	]
	model: Model = { category: undefined };
	config = {
		styles: {
			'width': '650px',
			'max-width': '100%',
		}
	};
	constructor(public router: Router,
		public activatedRoute: ActivatedRoute,
		public dialog: MatDialog,
		public http: Http,
		public permService: ClientPermService,
		public injector: Injector) {
		super(router, activatedRoute, dialog, permService, injector);

		this.tableData.externalPaging = false;
		this.tableData.externalSorting = false;
	}

	ngOnInit() {
		super.ngOnInit();
		this.searchData = undefined;
	}

	ngOnChanges(changes: { [ propACLs: string ]: SimpleChange }): void {
		this.tableData.rows = this.acl_input;
		let acls = this.acl_input;
		let row_tmp = [];
		if (acls) {
			for (let acl of acls) {
				let a_acl = new Row(
					acl.dstip,
					acl.proto,
					acl.attack_type,
					acl.TargetBandwidth,
					acl.TargetBandwidthRatio,
					acl.time,
					""
				);
				row_tmp.push(a_acl);
			}
		}
		this.rows = row_tmp;
	}

	columns = [
		{ name: 'Destination IP' },
		{ name: 'Protocol' },
		{ name: 'Attack Type' },
		{ name: 'Target Bandwidth' },
		{ name: 'Ratio' },
		{ name: 'Timestamp' },
		{ name: 'Id' }
	];
}

export class Row {
	constructor(
		public destinationIp: string,
		public protocol: string,
		public attackType: string,
		public targetBandwidth: string,
		public ratio: string,
		public timestamp: string,
		public id: string
	) { }
}
