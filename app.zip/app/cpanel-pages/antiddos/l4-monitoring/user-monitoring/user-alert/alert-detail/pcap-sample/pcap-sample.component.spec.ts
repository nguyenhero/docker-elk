import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PcapSampleComponent } from './pcap-sample.component';

describe('PcapSampleComponent', () => {
  let component: PcapSampleComponent;
  let fixture: ComponentFixture<PcapSampleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PcapSampleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PcapSampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
