import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AclMitigationComponent } from './acl-mitigation.component';

describe('AclMitigationComponent', () => {
  let component: AclMitigationComponent;
  let fixture: ComponentFixture<AclMitigationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AclMitigationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AclMitigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
