import {Component, OnInit, Inject, Input, OnDestroy} from '@angular/core';
import { Http, Response, HttpModule } from '@angular/http';
import { MatTableModule } from '@angular/material/table';
import { MatTableDataSource } from '@angular/material';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material';

import { TopChart } from '../../../share-module/top-chart/topchart.model';

import { Tab } from '../../../tab-based/tab.model';
import { OneLineChart } from '../../../share-module/one-line-chart/oneLineChart.model';

import {NewFiveLine} from '../../../bandwidth-chart/bandwidth-chart.component';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";

@AutoUnsubscribe()
@Component({
  selector: 'app-alert-detail',
  templateUrl: './alert-detail.component.html',
  styleUrls: ['./alert-detail.component.scss']
})
export class AlertDetailComponent implements OnInit, OnDestroy {
  displayedColumns = ['name', 'desc'];
  //dataSource = new MatTableDataSource(ATTACK_DATA);
  dataSource: any;
  ATTACK_DATA: AttackInfo[];
  topData: any;
  pcap_input: any;
  acl_input: any;

  system_id = "5afcdb20fd00a3678e9547ed";

  top5Chart: TopChart;
  //
  tabs: any;
  flowTab: any;
  infoTabs: any;
  selectedIndex: number = 0;
  selected_tab: any;
  flowData: any=[];
  flowChart: OneLineChart;

  bps_event: any=[];
  pps_event: any=[];

  constructor(public dialogRef: MatDialogRef<AlertDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public http: Http
  ) {}

  ngOnInit() {
    //// console.log();
    this.initDataTop();
    this.flowChart = new OneLineChart(
      this.flowData,
      'date',
      'value',
      'value',
      'FLOW',
      'flows/s'
    );
    this.tabs = [
      new Tab('bps', 'BANDWIDTH_BPS '),
      new Tab('pps', 'BANDWIDTH_PPS ')
    ];
    this.flowTab = new Tab('flow', 'FLOW_');
    this.selected_tab = this.tabs[0];
  }

  ngOnDestroy() {

  }

  closeDialog() {
    this.dialogRef.close({ reload: true });
  }

  onSelectChange(event) {
    // console.log('Tab Index: ' + event.index);
    this.selectedIndex = event.index;
    this.selected_tab = this.tabs[this.selectedIndex];

    if (this.selectedIndex == 2) {
      // this.initDataTop();
      this.flowChart = new OneLineChart(
        this.flowData,
        'date',
        'value',
        'value',
        'FLOW',
        'flows/s'
      );
    }
  }

  initDataTop() {
    // console.log(this.data);
    this.http.post('http://192.168.2.76/test/get_alert_id', {
      '_id': this.data._id
    })
      .subscribe((res: Response) => {
        let event_data = res.json().message;
        // console.log(event_data);
        this.pcap_input = event_data.pcap;
        this.pcap_input['time'] = event_data.startTime;
        this.topData = event_data['topIP'];

        // this.acl_input = event_data.acl_mitigation;

        this.top5Chart = new TopChart(
          this.topData,
          'ip',
          'bps',
          'top_ip',
          'IP',
          true,
          true
        );
        this.ATTACK_DATA = [
          { name: 'IP Address', desc: event_data['dstip'] },
          { name: 'Start Time', desc: event_data['startTime'] },
          { name: 'End Time', desc: event_data['endTime'] },
          { name: 'Attack Types', desc: event_data['attack_type'] }
        ];
        this.dataSource = new MatTableDataSource(this.ATTACK_DATA);

        this.http.post('http://192.168.2.76/test/get_acls_mitigate',
          {
            'system_id': this.system_id,
            'dstIP': event_data.dstip,
            'proto': event_data.acl_mitigation[0].proto,
            'attack_type': event_data.attack_type
          })
          .subscribe((res: Response) => {
            // console.log(res.json().message);
            this.acl_input = res.json().message;
          });

        this.http.post('http://192.168.2.76/test/get_bandwidth_monitoring',
          {
            'system_id': this.system_id,
            'from': event_data['startTime'],
            'to': event_data['endTime']
          })
          .subscribe((res: Response) => {
            this.bps_event = [];
            this.pps_event = [];
            this.flowData = [];
            let bandwidth = res.json().message;
            for (let band_ of bandwidth) {
              let a_bps = new NewFiveLine(
                band_['date'],
                band_['bps']['input'],
                band_['bps']['blacklist'],
                band_['bps']['whitelist'],
                band_['bps']['outgoing'],
                band_['bps']['totaloutput'],
              );
              let a_pps = new NewFiveLine(
                band_['date'],
                band_['pps']['input'],
                band_['pps']['blacklist'],
                band_['pps']['whitelist'],
                band_['pps']['outgoing'],
                band_['pps']['totaloutput'],
              );
              let a_flow = new flow(
                band_['date'],
                band_['flow']
              );
              this.bps_event.push(a_bps);
              this.pps_event.push(a_pps);
              this.flowData.push(a_flow);
            }
          });

      });
  }
}

export interface AttackInfo {
  name: string;
  desc: string;
}


export class flow {
	constructor(
		public date: string,
		public value: number
	) {}
}