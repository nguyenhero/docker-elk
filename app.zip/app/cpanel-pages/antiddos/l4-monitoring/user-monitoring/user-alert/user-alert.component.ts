import { Component, OnInit, ViewChild, Input, OnDestroy, Injector, OnChanges, SimpleChange } from '@angular/core';
import { TableModels } from '@visc/visc-template';
import { TOOLTIP } from '@common/modules';
import { BaseComponent } from '@common/components';
import { Http, Response, HttpModule } from '@angular/http';

import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { swalNotiSuccess, swalShowConfirm, swalShowError } from '@common/utils';
import { AlertDetailComponent } from './alert-detail/alert-detail.component';

import { ClientPermService } from '@common/services';

import Field = TableModels.Field
import HiddenControl = TableModels.HiddenControl;

class Model {
  category: string;
}
@Component({
  selector: 'app-user-alert',
  templateUrl: './user-alert.component.html',
  styleUrls: ['./user-alert.component.scss']
})
export class UserAlertComponent extends BaseComponent {
  @Input() isAlert: any;
  selectedTemp: any;
  system_id = "5afcdb20fd00a3678e9547ed";
  rows: any=[];
  value;

  FIELDS = [
    new Field('start', 'Start Time'),
    new Field('end', 'End Time'),
    new Field('type', 'Attack Type'),
    new Field('src', 'Source IP'),
    new Field('dst', 'Destination IP'),
    new Field('inbound_bps', 'Inbound BPS'),
    new Field('inbound_pps', 'Inbound PPS'),
    new Field('severity', 'Severity'),
    new Field('', 'Info', new HiddenControl(),
      {
        ref: this,
        type: 'actions',
        actions: [
          {
            icon: 'info_outline',
            click: row => this.viewDetail(row),
            tooltip: TOOLTIP.VIEW_DETAIL
          }
        ],
        minWidth: 50
      })
  ];
  model: Model = { category: undefined };
  config = {
    styles: {
      'width': '650px',
      'max-width': '100%',
    }
  };

  constructor(public router: Router,
    public activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    public http: Http,
		public permService: ClientPermService,
		public injector: Injector) {
    super(router, activatedRoute, dialog, permService, injector);

    this.tableData.externalPaging = false;
    this.tableData.externalSorting = false;
  }

  ngOnInit() {
    super.ngOnInit();
    this.searchData = undefined; 
  }

  ngOnChanges(changes: { [propBandwidthChart: string]: SimpleChange }): void {
    this.search();
  }

  viewDetail(row) {
    // console.log('viewDetail');
    // console.log(row);
    //this.openDialog(AlertDetailComponent, { _id: row._id });
    let dialogRef = this.dialog.open(AlertDetailComponent, {
      autoFocus: false,
      width: '100%',
      height: '100%',
      maxHeight: '100%',
      data: {_id: row} //row._id
    });

    let sub00 = dialogRef.afterClosed().subscribe((result: any) => {
      if (result && result.reload) {
        this.search();
      }
    });
  }

  search() {
    this.http.post('http://192.168.2.76/test/get_alert_detail',
      {
        'system_id': this.system_id
      })
      .subscribe((res: Response) => {
        let alert_arr = res.json().message;
        // console.log(alert_arr);
        this.tableData.rows = alert_arr;
        let row_tmp = [];
        let severity_arr = ['low', 'high', 'normal'];
        for (let a_row of alert_arr) {
          let sev = severity_arr[Math.floor(Math.random() * severity_arr.length)];
          let row = new Row(
            a_row.start,
            a_row.end,
            a_row.type,
            a_row.src,
            a_row.dst,
            a_row.inbound_bps,
            a_row.inbound_pps,
            sev,
            a_row._id
          );
          row_tmp.push(row);
        }
        this.rows = row_tmp;
      });
  }

  // reload() {
  //   super.reload();
  //   // console.log('user alert reload???');
  //   this.search();
  // }

  // Use Fosec template Datatable
  columns = [
    { name: 'Start Time' },
    { name: 'End Time' },
    { name: 'Attack Type' },
    { name: 'Source IP' },
    { name: 'Destination IP' },
    { name: 'Inbound BPS' },
    { name: 'Inbound PPS' },
    { name: 'Severity' },
    { name: 'Info' },
    { name: 'Id' }
  ];
}

export class Row {
  constructor(
    public startTime: string,
    public endTime: string,
    public attackType: string,
    public sourceIp: string,
    public destinationIp: string,
    public inboundBps: number,
    public inboundPps: number,
    public severity: string,
    public id: string
  ) {}
}