import {Routes, RouterModule} from '@angular/router';

import { UserMonitoringComponent } from './user-monitoring.component';

const USER_MONITORING_ROUTER: Routes = [
  {
    path: '',
    component: UserMonitoringComponent
  }
];

export const UserMonitoringRouter = RouterModule.forChild(USER_MONITORING_ROUTER);