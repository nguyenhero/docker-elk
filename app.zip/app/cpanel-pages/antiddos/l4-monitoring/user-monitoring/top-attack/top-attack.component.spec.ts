import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopAttackComponent } from './top-attack.component';

describe('TopAttackComponent', () => {
  let component: TopAttackComponent;
  let fixture: ComponentFixture<TopAttackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopAttackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopAttackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
