import { Component, OnInit, Input, OnChanges, SimpleChange } from '@angular/core';
import { Http, Response } from '@angular/http';
import * as moment from 'moment';
import { TopLargestChart } from '../../share-module/top-largest-chart/topLargestChart.model';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';

import { TopPieChart } from '../../share-module/top-pie-chart/topPieChart.model';
import { OneLineChart } from '../../share-module/one-line-chart/oneLineChart.model';

@Component({
  selector: 'app-top-attack',
  templateUrl: './top-attack.component.html',
  styleUrls: ['./top-attack.component.scss']
})
export class TopAttackComponent implements OnInit {
  @Input() ips: any;
  @Input() isTop: any;

  topAttackType_data: AttackType[] = [];
  topLargest_data: any;
  topLargest_chart: TopLargestChart;
  top_largest: any;
  no_attack_data: any;
  no_attack_chart: OneLineChart;

  // date
	date_from: any;
	date_to: any;
	dateStart: Date;
	dateEnd: Date;
	minDate: Date;
	maxDate: Date;

  // system_id = "5afcdb20fd00a3678e9547ed";

  topAttackType_chart: any;
  colors: string[] = ["#FF0F00", "#FF6600", "#FF9E01", "#FCD202", "#F8FF01", "#B0DE09", "#04D215", "#0D8ECF", "#0D52D1", "#2A0CD0", "#8A0CCF", "#CD0D74", "#754DEB", "#DDDDDD", "#999999", "#333333", "#000000", "#57032A", "#CA9726", "#990000", "#4B0C25"];
  constructor(public http: Http) { }

  ngOnInit() { 
    this.topLargest_chart = new TopLargestChart(
      [],
      'Top Largest Attack',
      'Top Largest Attack'
    );
    this.topAttackType_chart = new TopPieChart(
      [],
      'Attack Type',
      'Attack Type'
    );
    this.no_attack_chart = new OneLineChart(
      [],
      'date',
      'value',
      'value',
      'No of Attack',
      'attacks'
    );
  }

  ngOnChanges(changes: { [propTOP: string]: SimpleChange }): void {
    // console.log(this.ips);
    this.getInitDate();
    this.initData();
  }

  initData() {
    this.no_attack_data = NO_OF_ATTACK;
    this.no_attack_chart = new OneLineChart(
      this.no_attack_data,
      'date',
      'value',
      'value',
      'No of Attack',
      'attacks'
    );
    if (this.ips) {
      this.http.post('http://192.168.2.76/test/get_IPs_type',
        {
          'ips': this.ips,
          'from': this.date_from,
          'to': this.date_to
        })
        .subscribe((res: Response) => {
          let att_type = res.json().message;
          let type_arr = Object.keys(att_type);
          // // console.log(res.json().message.top_largest);
          let topAttackType_unsort = [];
          for (let at of type_arr) {
            if (at != 'top_largest') {
              let a_att = new AttackType(
                at,
                att_type[at],
                this.colors[Math.floor(Math.random() * 20) + 1]
              );
              topAttackType_unsort.push(a_att);
            }
            topAttackType_unsort.sort((a, b) => b.value - a.value);
            if (topAttackType_unsort.length > 5)
              this.topAttackType_data = topAttackType_unsort.slice(0, 5);
            else
              this.topAttackType_data = topAttackType_unsort;
          }

          this.top_largest = res.json().message['top_largest'];
          if (this.sum_value(this.top_largest) == 0) {
            this.topLargest_data = [];
          }
          else {
            this.topLargest_data = [
              {
                "range": '<100Mb',
                "bps": this.top_largest ? this.top_largest['range1'] : 0,
                "pps": 0
              },
              {
                "range": '100Mb<1Gb',
                "bps": this.top_largest ? this.top_largest['range2'] : 0,
                "pps": 0
              },
              {
                "range": '1Gb<10Gb',
                "bps": this.top_largest ? this.top_largest['range3'] : 0,
                "pps": 0
              },
              {
                "range": '10Gb<100Gb',
                "bps": this.top_largest ? this.top_largest['range4'] : 0,
                "pps": 0
              }
            ];
          }

          this.topLargest_chart = new TopLargestChart(
            this.topLargest_data,
            'Top Largest Attack',
            'Top Largest Attack'
          );
          this.topAttackType_chart = new TopPieChart(
            this.topAttackType_data,
            'Attack Type',
            'Attack Type'
          );
        });
    }
  }
  sum_value(obj_in) {
		let summed = 0;
		for (let key in obj_in) {
			summed += obj_in[key];
		}
		return summed;
  }
  changefromDate(event: MatDatepickerInputEvent<Date>) {
		this.date_from = moment(event.value).format("YYYY-MM-DD HH:mm");
	};

	changetoDate(event: MatDatepickerInputEvent<Date>) {
		this.date_to = moment(event.value).format("YYYY-MM-DD HH:mm");
	};


	getInitDate() {
		this.date_to = moment().format("YYYY-MM-DD HH:mm");
		this.date_from = moment().subtract(1, 'd').format("YYYY-MM-DD HH:mm");

		let endDate = new Date();
		let startDate = new Date();
		let mindate = new Date();
		this.maxDate = new Date();
		this.dateEnd = endDate;
		this.dateStart = new Date(startDate.setHours(startDate.getHours() - 24));
		let m = new Date(mindate.setHours(mindate.getHours() - 168));
		this.minDate = new Date(m.getFullYear(), m.getMonth(), m.getDate());
	}

	filter_by_date() {
		// console.log('From: ' + this.date_from);
    // console.log('To: ' + this.date_to);
    this.initData();
	}

}

export class AttackType {
  constructor(
    public label: string,
    public value: number,
    public color: any
  ) { }
}

const NO_OF_ATTACK = [{"date":"2018-06-06 00:23","value":217},{"date":"2018-06-06 00:24","value":873},{"date":"2018-06-06 00:25","value":971},{"date":"2018-06-06 00:26","value":532},{"date":"2018-06-06 00:27","value":268},{"date":"2018-06-06 00:28","value":568},{"date":"2018-06-06 00:29","value":39},{"date":"2018-06-06 00:30","value":982},{"date":"2018-06-06 00:31","value":73},{"date":"2018-06-06 00:32","value":208},{"date":"2018-06-06 00:33","value":43},{"date":"2018-06-06 00:34","value":71},{"date":"2018-06-06 00:35","value":8},{"date":"2018-06-06 00:36","value":937},{"date":"2018-06-06 00:37","value":47},{"date":"2018-06-06 00:38","value":120},{"date":"2018-06-06 00:39","value":379},{"date":"2018-06-06 00:40","value":116},{"date":"2018-06-06 00:41","value":760},{"date":"2018-06-06 00:42","value":815},{"date":"2018-06-06 00:43","value":722},{"date":"2018-06-06 00:44","value":478},{"date":"2018-06-06 00:45","value":749},{"date":"2018-06-06 00:46","value":330},{"date":"2018-06-06 00:47","value":6},{"date":"2018-06-06 00:48","value":806},{"date":"2018-06-06 00:49","value":204},{"date":"2018-06-06 00:50","value":809},{"date":"2018-06-06 00:51","value":466},{"date":"2018-06-06 00:52","value":344},{"date":"2018-06-06 00:53","value":867},{"date":"2018-06-06 00:54","value":961},{"date":"2018-06-06 00:55","value":468},{"date":"2018-06-06 00:56","value":946},{"date":"2018-06-06 00:57","value":690},{"date":"2018-06-06 00:58","value":434},{"date":"2018-06-06 00:59","value":157},{"date":"2018-06-06 01:00","value":530},{"date":"2018-06-06 01:01","value":959},{"date":"2018-06-06 01:02","value":752},{"date":"2018-06-06 01:03","value":200},{"date":"2018-06-06 01:04","value":179},{"date":"2018-06-06 01:05","value":99},{"date":"2018-06-06 01:06","value":157},{"date":"2018-06-06 01:07","value":516},{"date":"2018-06-06 01:08","value":28},{"date":"2018-06-06 01:09","value":199},{"date":"2018-06-06 01:10","value":561},{"date":"2018-06-06 01:11","value":845},{"date":"2018-06-06 01:12","value":643},{"date":"2018-06-06 01:13","value":55},{"date":"2018-06-06 01:14","value":973},{"date":"2018-06-06 01:15","value":304},{"date":"2018-06-06 01:16","value":92},{"date":"2018-06-06 01:17","value":837},{"date":"2018-06-06 01:18","value":10},{"date":"2018-06-06 01:19","value":443},{"date":"2018-06-06 01:20","value":361},{"date":"2018-06-06 01:21","value":12},{"date":"2018-06-06 01:22","value":522},{"date":"2018-06-06 01:23","value":448},{"date":"2018-06-06 01:24","value":583},{"date":"2018-06-06 01:25","value":498},{"date":"2018-06-06 01:26","value":36},{"date":"2018-06-06 01:27","value":662},{"date":"2018-06-06 01:28","value":255},{"date":"2018-06-06 01:29","value":348},{"date":"2018-06-06 01:30","value":872},{"date":"2018-06-06 01:31","value":629},{"date":"2018-06-06 01:32","value":244},{"date":"2018-06-06 01:33","value":547},{"date":"2018-06-06 01:34","value":157},{"date":"2018-06-06 01:35","value":18},{"date":"2018-06-06 01:36","value":47},{"date":"2018-06-06 01:37","value":138},{"date":"2018-06-06 01:38","value":456},{"date":"2018-06-06 01:39","value":896},{"date":"2018-06-06 01:40","value":700},{"date":"2018-06-06 01:41","value":694},{"date":"2018-06-06 01:42","value":180},{"date":"2018-06-06 01:43","value":373},{"date":"2018-06-06 01:44","value":88},{"date":"2018-06-06 01:45","value":729},{"date":"2018-06-06 01:46","value":733},{"date":"2018-06-06 01:47","value":678},{"date":"2018-06-06 01:48","value":773},{"date":"2018-06-06 01:49","value":991},{"date":"2018-06-06 01:50","value":706},{"date":"2018-06-06 01:51","value":748},{"date":"2018-06-06 01:52","value":37},{"date":"2018-06-06 01:53","value":559},{"date":"2018-06-06 01:54","value":18},{"date":"2018-06-06 01:55","value":344},{"date":"2018-06-06 01:56","value":952},{"date":"2018-06-06 01:57","value":511},{"date":"2018-06-06 01:58","value":211},{"date":"2018-06-06 01:59","value":273},{"date":"2018-06-06 02:00","value":337},{"date":"2018-06-06 02:01","value":565},{"date":"2018-06-06 02:02","value":771},{"date":"2018-06-06 02:03","value":242},{"date":"2018-06-06 02:04","value":456},{"date":"2018-06-06 02:05","value":511},{"date":"2018-06-06 02:06","value":931},{"date":"2018-06-06 02:07","value":251},{"date":"2018-06-06 02:08","value":450},{"date":"2018-06-06 02:09","value":955},{"date":"2018-06-06 02:10","value":763},{"date":"2018-06-06 02:11","value":307},{"date":"2018-06-06 02:12","value":454},{"date":"2018-06-06 02:13","value":298},{"date":"2018-06-06 02:14","value":333},{"date":"2018-06-06 02:15","value":996},{"date":"2018-06-06 02:16","value":41},{"date":"2018-06-06 02:17","value":688},{"date":"2018-06-06 02:18","value":830},{"date":"2018-06-06 02:19","value":37},{"date":"2018-06-06 02:20","value":432},{"date":"2018-06-06 02:21","value":871},{"date":"2018-06-06 02:22","value":655}];