import { Component, OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';
import * as moment from 'moment';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';


import { MatTableModule } from '@angular/material/table';
import { MatTableDataSource } from '@angular/material';

import { Tab } from '../tab-based/tab.model';
import { OneLineChart } from '../share-module/one-line-chart/oneLineChart.model';

import { NewFiveLine } from '../bandwidth-chart/bandwidth-chart.component';

@Component({
	selector: 'app-user-monitoring',
	templateUrl: './user-monitoring.component.html',
	styleUrls: [ './user-monitoring.component.scss' ]
})
export class UserMonitoringComponent implements OnInit {
	loaded: boolean = false;

	tabs: any;
	flowTab: any;
	infoTabs: any;
	selectedIndex: number = 0;
	selectedIndex2: number = 0;
	selected_tab: any;
	flowData: flow[] = [];
	flowChart: OneLineChart;
	chartName;

	IPS_list: any;
	ip_sel: any;
	IPS: any;

	expression = true;

	largestIps: any;
	// date
	date_from: any;
	date_to: any;
	dateStart: Date;
	dateEnd: Date;
	minDate: Date;
	maxDate: Date;

	username: string;
	user_id = "5b164e5dfd00a33b7ddc85f7";

	system_id = "5afcdb20fd00a3678e9547ed";
	bps_: NewFiveLine[] = [];
	pps_: NewFiveLine[] = [];

	get hasWebsite() {
		return this.IPS_list && this.IPS_list.length > 0;
	}

	constructor(public http: Http) { }

	ngOnInit() {
		this.flowChart = new OneLineChart(
			this.flowData,
			'date',
			'value',
			'value',
			'FLOW',
			'flows/s'
		);
		this.getInitDate();
		this.initData();
		this.tabs = [
			new Tab('bps', 'BANDWIDTH_BPS'),
			new Tab('pps', 'BANDWIDTH_PPS')
		];
		this.flowTab = new Tab('flow', 'FLOW');
		this.selected_tab = this.tabs[ 0 ];

		this.infoTabs = [
			new Tab('Summary', 'SUMMARY'),
			new Tab('Top Attacks', 'TOP'),
			new Tab('Attack Map', 'MAP'),
			new Tab('Alerts', 'ALERT'),
			new Tab('Logs', 'LOG')
		];
	}

	onSelectChange(event) {
		// console.log('Tab Index: ' + event.index);
		this.selectedIndex = event.index;
		this.selected_tab = this.tabs[ this.selectedIndex ];

		if (this.selectedIndex == 2) {
			this.flowChart = new OneLineChart(
				this.flowData,
				'date',
				'value',
				'value',
				'FLOW',
				'flows/s'
			);
		}
	}

	changIPs(event) {
		let ips = [];
		if (event.hasOwnProperty('value')) {
			ips = event.value;
			this.IPS = ips;
		}
		else
			ips = event;
		this.http.post('http://192.168.2.76/test/get_ip_bw', {
			'system_id': "",
			'ips': ips,
			'from': this.date_from,
			'to': this.date_to
		})
			.subscribe((res: Response) => {
				this.largestIps = res.json().message.largest_att;
				this.bps_ = [];
				this.pps_ = [];
				this.flowData = [];
				let bandwidth = res.json().message.bw;
				for (let band_ of bandwidth) {
					let a_bps = new NewFiveLine(
						band_[ 'date' ],
						band_[ 'bps' ][ 'input' ],
						band_[ 'bps' ][ 'blacklist' ],
						band_[ 'bps' ][ 'whitelist' ],
						band_[ 'bps' ][ 'outgoing' ],
						band_[ 'bps' ][ 'totaloutput' ],
					);
					let a_pps = new NewFiveLine(
						band_[ 'date' ],
						band_[ 'pps' ][ 'input' ],
						band_[ 'pps' ][ 'blacklist' ],
						band_[ 'pps' ][ 'whitelist' ],
						band_[ 'pps' ][ 'outgoing' ],
						band_[ 'pps' ][ 'totaloutput' ],
					);
					let a_flow = new flow(
						band_[ 'date' ],
						band_[ 'flow' ]
					);
					this.bps_.push(a_bps);
					this.pps_.push(a_pps);
					this.flowData.push(a_flow);
				}
				this.flowChart = new OneLineChart(
					this.flowData,
					'date',
					'value',
					'value',
					'FLOW',
					'flows/s'
				);
			});
	}

	isTop = false;
	isAlert = false;
	onInfoChange(event) {
		if (event.index == 1) {
			this.isTop = !this.isTop;
		}
		if (event.index == 3) {
			this.isAlert = !this.isAlert;
		}

		/* remove dispatch resize */
		window.dispatchEvent(new Event('resize'));
	}

	initData() {
		this.http.post('http://192.168.2.76/test/get_user_info',
			{
				'user_id': this.user_id
			})
			.subscribe((res: Response) => {
				this.loaded = true;

				this.IPS_list = res.json().message.iprange;
				this.username = res.json().message.username;
				this.ip_sel = [ this.IPS_list[ 0 ] ];
				this.IPS = this.ip_sel;
				this.changIPs(this.ip_sel);
			});
	}
	changefromDate(event: MatDatepickerInputEvent<Date>) {
		this.date_from = moment(event.value).format("YYYY-MM-DD HH:mm");
	};

	changetoDate(event: MatDatepickerInputEvent<Date>) {
		this.date_to = moment(event.value).format("YYYY-MM-DD HH:mm");
	};


	getInitDate() {
		this.date_to = moment().format("YYYY-MM-DD HH:mm");
		this.date_from = moment().subtract(1, 'd').format("YYYY-MM-DD HH:mm");

		let endDate = new Date();
		let startDate = new Date();
		let mindate = new Date();
		this.maxDate = new Date();
		this.dateEnd = endDate;
		this.dateStart = new Date(startDate.setHours(startDate.getHours() - 24));
		let m = new Date(mindate.setHours(mindate.getHours() - 168));
		this.minDate = new Date(m.getFullYear(), m.getMonth(), m.getDate());
	}

	filter_by_date() {
		// console.log('From: ' + this.date_from);
		// console.log('To: ' + this.date_to);
		// console.log(this.IPS);
		this.changIPs({ 'value': this.IPS });
	}
}

export class flow {
	constructor(
		public date: string,
		public value: number
	) { }
}