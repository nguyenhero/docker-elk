import { Component, OnInit, Input, OnChanges, SimpleChange } from '@angular/core';

import { Http, Response } from '@angular/http';
import { AmChartsService } from '@amcharts/amcharts3-angular';
import * as moment from "moment";
import {formatBigNumber2} from "@common/utils/utils";
import {TranslateService} from "@ngx-translate/core";

declare let $: any;

@Component({
  selector: 'app-bandwidth-chart',
  templateUrl: './bandwidth-chart.component.html',
  styleUrls: [ './bandwidth-chart.component.scss' ]
})
export class BandwidthChartComponent implements OnInit {
  @Input() tab: any;
  @Input() selected: any;
  @Input() bps_: any;
  @Input() pps_: any;
  @Input() position: string;

  // system_id = "5afcdb20fd00a3678e9547ed";
  chartDataReq: any;
  bandwidth: any;
  type_cur: string;
  // bps_: fiveLine[]=[];
  // pps_: fiveLine[]=[];
  isEmpty: number = 0;

  constructor(
      public amCharts: AmChartsService,
      public http: Http,
      public translate: TranslateService,
  ) { }

  ngOnInit() { }

  ngOnChanges(changes: { [ propBandwidthChart: string ]: SimpleChange }): void {
    // console.log(this.selected);
    if (this.tab == this.selected) {
      // console.log('changes TAB' + this.tab.type);
      this.chartDataReq = (this.tab.type == 'BANDWIDTH_BPS') ? this.bps_ : this.pps_;
      this.type_cur = (this.tab.type == 'BANDWIDTH_BPS') ? "bits/s" : "pkts/s";

      // // console.log(this.chartDataReq);
      if (!this.chartDataReq || !this.chartDataReq.length) {
        this.isEmpty = 1;
      }
      else {
        this.isEmpty = 2;
        setTimeout(() => {
          this.callChart();
        });
      }
    }
  }


  callChart() {
    let graphs = [];
    let lines = ['input', 'blacklist', 'whitelist', 'allowedInput', 'output'];
    let linesMap = {
      'input': 'Input',
      'blacklist': 'Blacklist',
      'whitelist': 'Whitelist',
      'allowedInput': 'Allowed Input',
      'output': 'Output',
    };
    let colors = {
        input: '#9c9c96',
        bl: '#cc4748',
        blacklist: '#cc4748',
        wl: '#6a8923',
        whitelist: '#6a8923',
        warn: '#fdd400',
        output: '#22a8af',
        cc: '#9c9c96',
        cp: '#22a8af',
        cd: '#cc4748',
        clean: '#1c3a97',
        allowedInput: '#1c3a97',
    };
    for (let k of lines) {
      let v = linesMap[k];
      graphs.push({
          'id': `g${k}`,
          "useLineColorForBulletBorder": true,
          "type": "line",
          'title': this.translate.instant(v),
          'bullet': 'round',
          "bulletSize": 12,
          "bulletBorderAlpha": 1,
          "bulletColor": "#fff",
          'hideBulletsCount': 30,
          'lineThickness': 3,
          'lineColor': colors[k],
          'valueField': k,
          "fillAlphas": 0.1,
          'balloonFunction': (item, graph) => {
              let d = item.dataContext['date'];
              d = moment(d).format('YYYY-MM-DD HH:mm:ss');
              let timeText = this.translate.instant('Time');
              let html = `<div class="waf-realtime_ballon"><table><tr><th colspan="2" class="p-0">${timeText}: ${d}</th></tr>`;

              for (let field of lines) {
                  let value = item.dataContext[field] || 0;

                  html += `<tr><td class="p-0 text-left">${this.translate.instant(linesMap[field])} </td><td class="p-0 text-left">: ${formatBigNumber2(value)}</td></tr>`;
              }
              html += '</table></div>';
              return html;
          }
      });
    }
    this.bandwidth = this.amCharts.makeChart(this.tab.type, {
      type: 'serial',
      theme: 'light',
      "addClassNames": true,
      "autoMargins": false,
      "marginTop": 20,
      "marginRight": this.position === 'right' ? 100 : 30,
      "marginLeft": this.position === 'right' ? 150 : 70,
      "marginBottom": 30,
      "fontSize": 14,
      "balloon": {
        "adjustBorderColor": true,
        "color": "#000000",
        "cornerRadius": 3,
        "borderThickness": 1
      },
      "legend": {
        "enabled": true,
        "valueText": "",
        "position": this.position || "bottom",
        "horizontalGap": 5,
        "verticalGap": 14,
        "markerSize": 13,
        "autoMargins": false,
      },
      dataProvider: this.chartDataReq,
      labelsEnabled: false,
      mouseWheelZoomEnabled: false,
      graphs,
      // 'graphs': [ {
      //   'id': 'g1',
      //   "type": "line",
      //   "useLineColorForBulletBorder": true,
      //   "balloonFunction": function (graphDataItem, graph) {
      //     let value = graphDataItem.values.value;
      //     if (value >= 1000000000)
      //       return ((value / 1000000000.0).toFixed(2)) + "G";
      //     else if (value >= 1000000)
      //       return ((value / 1000000.0).toFixed(2)) + "M";
      //     else if (value >= 1000)
      //       return "" + ((value / 1000.0).toFixed(2)) + "k";
      //     else
      //       return value;
      //   },
      //   'title': 'Input',
      //   'bullet': 'round',
      //   "bulletSize": 12,
      //   "bulletBorderAlpha": 1,
      //   "bulletColor": "#fff",
      //   'hideBulletsCount': 30,
      //   'lineColor': '#9c9c96',
      //   'lineThickness': 3,
      //   'valueField': 'input',
      //   "fillAlphas": 0
      // },
      // {
      //   'id': 'g2',
      //   "useLineColorForBulletBorder": true,
      //   "type": "line",
      //   "balloonFunction": function (graphDataItem, graph) {
      //     let value = graphDataItem.values.value;
      //     if (value >= 1000000000)
      //       return ((value / 1000000000.0).toFixed(2)) + "G";
      //     else if (value >= 1000000)
      //       return ((value / 1000000.0).toFixed(2)) + "M";
      //     else if (value >= 1000)
      //       return "" + ((value / 1000.0).toFixed(2)) + "k";
      //     else
      //       return value;
      //   },
      //   'title': 'Blacklist',
      //   'bullet': 'round',
      //   "bulletSize": 12,
      //   "bulletBorderAlpha": 1,
      //   "bulletColor": "#fff",
      //   'hideBulletsCount': 30,
      //   'lineColor': '#cc4748',
      //   'lineThickness': 3,
      //   'valueField': 'blacklist',
      //   "fillAlphas": 0
      // },
      // {
      //   'id': 'g3',
      //   "useLineColorForBulletBorder": true,
      //   "type": "line",
      //   "balloonFunction": function (graphDataItem, graph) {
      //     let value = graphDataItem.values.value;
      //     if (value >= 1000000000)
      //       return ((value / 1000000000.0).toFixed(2)) + "G";
      //     else if (value >= 1000000)
      //       return ((value / 1000000.0).toFixed(2)) + "M";
      //     else if (value >= 1000)
      //       return "" + ((value / 1000.0).toFixed(2)) + "k";
      //     else
      //       return value;
      //   },
      //   'title': 'Whitelist',
      //   'bullet': 'round',
      //   "bulletSize": 12,
      //   "bulletBorderAlpha": 1,
      //   "bulletColor": "#fff",
      //   'hideBulletsCount': 30,
      //   'lineColor': '#6a8923',
      //   'lineThickness': 3,
      //   'valueField': 'whitelist',
      //   "fillAlphas": 0
      // },
      // {
      //   'id': 'g4',
      //   "useLineColorForBulletBorder": true,
      //   "type": "line",
      //   "balloonFunction": function (graphDataItem, graph) {
      //     let value = graphDataItem.values.value;
      //     if (value >= 1000000000)
      //       return ((value / 1000000000.0).toFixed(2)) + "G";
      //     else if (value >= 1000000)
      //       return ((value / 1000000.0).toFixed(2)) + "M";
      //     else if (value >= 1000)
      //       return "" + ((value / 1000.0).toFixed(2)) + "k";
      //     else
      //       return value;
      //   },
      //   'title': 'Allowed Input',
      //   'bullet': 'round',
      //   "bulletSize": 12,
      //   "bulletBorderAlpha": 1,
      //   "bulletColor": "#fff",
      //   'hideBulletsCount': 30,
      //   'lineColor': '#1c3a97',
      //   'lineThickness': 3,
      //   'valueField': 'allowedInput',
      //   "fillAlphas": 0
      // },
      // {
      //   'id': 'g5',
      //   "useLineColorForBulletBorder": true,
      //   "type": "line",
      //   "balloonFunction": function (graphDataItem, graph) {
      //     let value = graphDataItem.values.value;
      //     if (value >= 1000000000)
      //       return ((value / 1000000000.0).toFixed(2)) + "G";
      //     else if (value >= 1000000)
      //       return ((value / 1000000.0).toFixed(2)) + "M";
      //     else if (value >= 1000)
      //       return "" + ((value / 1000.0).toFixed(2)) + "k";
      //     else
      //       return value;
      //   },
      //   'title': 'Output',
      //   'bullet': 'round',
      //   "bulletSize": 12,
      //   "bulletBorderAlpha": 1,
      //   "bulletColor": "#fff",
      //   'hideBulletsCount': 30,
      //   'lineColor': '#22a8af',
      //   "lineThickness": 3,
      //   'valueField': 'output',
      //   "fillAlphas": 0
      // }
      // ],
      // 'chartCursor': {
      //   'categoryBalloonDateFormat': 'YYYY-MM-DD HH:NN',
      //   'cursorAlpha': 0,
      //   'valueLineEnabled': true,
      //   'valueLineBalloonEnabled': true,
      //   'valueLineAlpha': 0.5,
      //   'fullWidth': true,
      //   "cursorColor": "#272829",
      //
      // },
      'chartCursor': {
          "oneBalloonOnly": true,
          'categoryBalloonDateFormat': 'YYYY-MM-DD HH:NN',
          'cursorAlpha': 0,
          'valueLineEnabled': false,
          'valueLineBalloonEnabled': true,
          'valueLineAlpha': 0.5,
          "cursorColor": "#272829",
          "bulletsEnabled": true
      },
      'dataDateFormat': 'YYYY-MM-DD HH:NN',
      'categoryField': 'date',
      'categoryAxis': {
        'minPeriod': 'mm',
        'parseDates': true,
        'equalSpacing': true,
        "axisAlpha": 0,
        "gridAlpha": 0.17,
        "gridColor": "#909090",
        'gridThickness': 1,
      },
      "valueAxes": [ {
        "title": this.type_cur,
        "integersOnly": false,
        "axisAlpha": 0,
        "position": "left",
        "gridAlpha": 0.17,
        "gridColor": "#909090",
        'gridThickness': 1,
        "labelFunction": function (value) {
          if (value >= 1000000000)
            return ((value / 1000000000.0).toFixed(2)) + "G";
          else if (value >= 1000000)
            return ((value / 1000000.0).toFixed(2)) + "M";
          else if (value >= 1000)
            return "" + ((value / 1000.0).toFixed(2)) + "k";
          else
            return parseInt(value, 10);
        }
      } ]
    });

    setTimeout(function () {
      let lines = $('.amcharts-graph-smoothedLine');
      lines.each(function () {
        let firstBullet = $(this).find('.amcharts-graph-bullet').eq(0);
        let color = firstBullet.attr('stroke');
        firstBullet.attr('fill', color);
      })
    }, 0);
  }
}

// export class fiveLine {
//   constructor(
//     public date: string,
//     public input: number,
//     public blacklist: number,
//     public whitelist: number,
//     public cleaned: number,
//     public total: number
//   ) { }
// }

export class NewFiveLine {
    constructor(
        public date,
        public input,
        public blacklist,
        public whitelist,
        public output,
        public allowedInput) {
    }
}