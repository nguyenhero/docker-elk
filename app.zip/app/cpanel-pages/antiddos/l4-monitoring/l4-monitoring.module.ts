import { NgModule } from '@angular/core';
import { COMMON_MODULES } from '@common/lazyload';
import { MatTableModule } from '@angular/material/table';

// import { BandwidthChartComponent } from './bandwidth-chart/bandwidth-chart.component';
// import { TwoLineChartComponent } from './two-line-chart/two-line-chart.component';
// import { OneLineChartComponent } from './one-line-chart/one-line-chart.component';
import { ShareModule } from './share-module/share-module';

import { AmChartsService } from '@amcharts/amcharts3-angular';
// import { SummaryComponent } from './summary/summary.component';
// import { ResourceMonitoringComponent } from './resource-monitoring/resource-monitoring.component';
// import { AttackMonitoringComponent } from './attack-monitoring/attack-monitoring.component';
// import { TopLargestChartComponent } from './share-module/top-largest-chart/top-largest-chart.component';
//import { TopPieChartComponent } from './share-module/top-pie-chart/top-pie-chart.component';

import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
// import { AclsComponent } from './acls/acls.component';
// import { AlertsComponent } from './alerts/alerts.component';
// import { AlertDetailComponent } from './alerts/alert-detail/alert-detail.component';
// import { AclMitigationComponent } from './alerts/alert-detail/acl-mitigation/acl-mitigation.component';
// import { PcapSampleComponent } from './alerts/alert-detail/pcap-sample/pcap-sample.component';
// import { CoreGraphComponent } from './core-graph/core-graph.component';
// import { PieChartComponent } from './core-graph/pie-chart.component';
// import { DataService } from './core-graph/data.service';
// import { NetDataService } from './core-graph/net-graph/net-data.service';
// import { NetGraphComponent } from './core-graph/net-graph/net-graph.component';
// import { LogsComponent } from './logs/logs.component';
// import { OperationDialogComponent } from './logs/operation-dialog/operation-dialog.component';

// import { IPValidator } from './acls/custom-validators';
// import { UserMonitoringComponent } from './user-monitoring/user-monitoring.component';
// import { MultipleLineChartComponent } from './share-module/multiple-line-chart/multiple-line-chart.component';


@NgModule({
	imports: [
		...COMMON_MODULES,
		MatTableModule,
		ShareModule,
		MatDatepickerModule,
		MatNativeDateModule,
	],
	declarations: [
	],
	providers: [
		AmChartsService,
		// DataService,
		// NetDataService
	],
	entryComponents: [
		// AlertDetailComponent,
		// OperationDialogComponent
	]
})
export class L4MonitoringModule { }
