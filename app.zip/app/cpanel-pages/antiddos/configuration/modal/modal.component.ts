import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {
  editMode: boolean = false;
  title: string = "Thêm IP";

  new: any = {
    'active': true,
  };

  constructor(
    public dialogRef: MatDialogRef<ModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  ngOnInit() {
  }

  close(){
    this.dialogRef.close();
  }

  changeType($event){
    this.new.type = $event.value;
  }

  save(){
    this.dialogRef.close({result: {
      data: this.new
    }})
  }

}

@Component({
  selector: 'app-edit-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalEditComponent extends ModalComponent implements OnInit {
  editMode: boolean = true;
  title: string = "Sửa IP";

  constructor(
    public dialogRef: MatDialogRef<ModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { 
    super(dialogRef, data);

    this.new = {...data.model};
  }
}

