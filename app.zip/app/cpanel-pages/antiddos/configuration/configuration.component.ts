import {Component, OnInit, Injector} from '@angular/core';

import {swalNotiSuccess, swalShowConfirm, swalShowError, swalConfirmDelete, swalInput} from '@common/utils';

import {BaseComponent} from '@common/components';
import {Router, ActivatedRoute} from '@angular/router';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {ClientPermService} from '@common/services';
import {Field, HiddenControl} from '@common/models';
import {TranslateService} from "@ngx-translate/core";

import {
    CsUnitService,
    CustomerServiceService
} from '@common/swagger-services';

import {
    WEBPROTECTION_ALIAS,
    WAF_ALIAS,
    DDOSL4_ALIAS,
    DDOSL7_ALIAS,
    WAF_SERVICE_NAME,
    MAX_CERT_KEY_SIZE,
    AntiDDOSL4_SERVICE_NAME
} from '@customer/config';

import {
    ModalComponent,
    ModalEditComponent
} from './modal/modal.component';

@Component({
    selector: 'app-antiddos-configuration',
    templateUrl: './configuration.component.html',
    styleUrls: ['./configuration.component.scss']
})
export class ConfigurationComponent extends BaseComponent implements OnInit {
    service: any;
    selectedRows: any[];

    FIELDS = [
        new Field('ip', 'IP/Subnet', new HiddenControl(), {
        }),
        new Field('active', 'Status', new HiddenControl(), {
            type: 'yesno',
            render: x => (x === true) ? 'actived' : 'deactived',
        })
    ];

    get customer_service() {
        return {
            'name': `${this.service.service_name}, ${this.service.package_name}`,
            '_id': this.service._id,
            'services': ["ddosl4"]
        };
    }

    constructor(
        public router: Router,
        public activatedRoute: ActivatedRoute,
        public dialog: MatDialog,
        public permService: ClientPermService,
        public injector: Injector,
        public csUnitService: CsUnitService,
        public trans: TranslateService,
        public customerServiceService: CustomerServiceService
    ) {
        super(router, activatedRoute, dialog, permService, injector);

        this.tableData.externalPaging = this.tableData.externalSorting = false;
        this.tableData.page.size = 5;

        this.onIpChecked = this.onIpChecked.bind(this);
        this.addIP = this.addIP.bind(this);
        this.onDeleteIPsMulti = this.onDeleteIPsMulti.bind(this);
    }

    onIpChecked(event) {
        // console.log("on ip checked: ", event)
        this.selectedRows = event.selected;
        this.selectedRows = [...this.selectedRows];
        this.detectChanges();
    }

  ngOnInit() {
    super.ngOnInit();
    this.page.pageNumber = 0;
    this.page.size = 5;
    // get service
    let u = undefined;
    let service_name = [ AntiDDOSL4_SERVICE_NAME ];
    this.sub02 = this.customerServiceService.getCustomerServiceList(u, u, u, u, u, u, service_name)
      .subscribe(resp => {
        try {
          this.service = resp.data.rows[ 0 ];
        } catch (e) { }

                this.refresh();
            });
    }

    refresh() {
        this.getAllIP();
    }

    addIP() {
        let customer_service = this.customer_service;

        this.openDialog(ModalComponent, {model: {}}, (result) => {
            if (result && result.data) {
                let data = result.data;
                let d = {
                    'customer_service_id': customer_service._id,
                    'services': customer_service.services,
                    'identity': data.ip,
                    'desc': data.desc,
                    'active': data.active
                };

                this.sub04 = this.csUnitService.postCustomerServiceUnitList(
                    d
                ).subscribe(resp => {
                    swalNotiSuccess('Thêm IP', 'Thêm thành công IP');
                    this.refresh();
                });
            }
        });
    }

    onDeleteIPsMulti() {
        if (this.selectedRows) {
            let names = this.selectedRows.map(it => it.identity);
            let names_str = names.join(', ');
            swalShowConfirm(this.trans.instant('Delete'), this.trans.instant("Bạn có chắc muốn xóa IP {{names}}", {'names': names_str}), () => {
                let _ids = this.selectedRows.map(it => it._id);
                this.sub05 = this.csUnitService.postCustomerServiceUnitDeleteMulti(
                    {'_ids': _ids}
                ).subscribe(resp => {
                    this.selectedRows = [];
                    this.tableData.selected = [];
                    this.tableData = {...this.tableData};
                    swalNotiSuccess('Thông báo', `Xóa IP thành công`);
                    this.refresh();
                });
            });
        }
    }

    editIP(row) {
        let customer_service = this.customer_service;

        let data = {...row};
        this.openDialog(ModalEditComponent, {model: data}, (result) => {
            if (result && result.data) {
                let d = result.data;
                let putData = {
                    'identity': d.ip,
                    'desc': d.desc,
                    'active': d.active
                };
                this.sub03 = this.csUnitService.putCustomerServiceUnitItem(
                    row._id,
                    putData
                ).subscribe(resp => {
                    swalNotiSuccess('Sửa IP', 'Sửa thành công IP');
                    this.refresh();
                });
            }
        });
    }

    deleteIP(row) {
        // swalShowConfirm('Thông báo', 'Bạn có muốn xóa IP không', () => {
        //   swalNotiSuccess('Xóa IP', 'Xóa thành công IP');
        // })
        // let validate = row.ip;
        let validate = 'DELETE';
        swalConfirmDelete('Confirm', `Nhập chuỗi '${validate}' để xóa IP`, validate)
            .then(resp => {
                if (!resp.value) {
                    return;
                }
                this.sub05 = this.csUnitService.deleteCustomerServiceUnitItem(
                    row._id
                ).subscribe(res => {
                    swalNotiSuccess('Thông báo', `Xóa IP thành công`);
                    this.refresh();
                });
            });
    }

    openDialog(component, model = {}, cb?) {
        const dialogRef = this.dialog.open(component, {
            autoFocus: false,
            width: '500px',
            maxWidth: '100%',
            height: 'auto',
            maxHeight: '100%',
            data: model
        });
        this.sub01 = dialogRef.afterClosed().subscribe((result: any) => {
            if (result) {
                cb(result.result);
            }
        });
    }

    _parseRow(r) {
        r.ip = r.identity;
        return r;
    }

    getAllIP() {
        const u = undefined;
        let customer_service = this.customer_service;
        this.sub01 = this.csUnitService.getCustomerServiceUnitList(300, 0, customer_service.services, customer_service._id)
            .subscribe(resp => {
                let websites = resp.data.rows;
                this.tableData.rows = (websites || []).map(x => this._parseRow(x));
                this.tableData = {...this.tableData};
                this.detectChanges();
            });
    }

}
