import {NgModule} from '@angular/core';
import {COMMON_MODULES} from '@common/lazyload';

import {ShareModule} from '../antiddos/l4-monitoring/share-module/share-module';

import {AntiddosManageComponent} from './antiddos-manage/antiddos-manage.component';
import {NetChartComponent} from './net-chart/net-chart.component';

import {PriceUtilsModule} from '../price/price-utils.module';
import {ServiceAlertShareModule} from '../service-alert/service-alert.share.module';
import {EventsSharedModule} from '../events/event.shared.module';

import {antiddosManageRouter} from './antiddos-routing.module';
import {ServiceManageUtilModule} from '../waf/service-manage-utils.module';
// import { EventsComponent } from './events/events.component';
import {DDoSLogsComponent} from './ddos-logs/waf-logs.component';
import {AlertsComponent} from './alerts/alerts.component';
import {AclsComponent} from './acls/acls.component';
import {
  AclsModalComponent,
  AclsModalEditComponent
} from './acls-modal/acls-modal.component';
import {AttackMonitoringComponent} from './attack-monitoring/attack-monitoring.component';

//import { DDosL4MonitorService } from '@common/ddosl4-services';
import {ServiceSummaryComponentNewComponent} from './service-summary-new/service-summary-new.component';
// import { DDosL4MonitorService } from '@common/ddosl4-services';

// const DDOSL4_SERVICES = [
//   DDosL4MonitorService
// ]

import {DDosL4ApiModule} from '@common/ddosl4-services/ddosl4.api.module';
import {QuickConfigModule} from "../quick-config/quick-config.module";
import { ExportModalComponent } from './antiddos-manage/export-modal/export-modal.component';

@NgModule({
  imports: [
    ...COMMON_MODULES,
    ShareModule,
    antiddosManageRouter,
    PriceUtilsModule,
    ServiceManageUtilModule,
    ServiceAlertShareModule,
    EventsSharedModule,
    DDosL4ApiModule,
    QuickConfigModule,
  ],
  declarations: [
    AntiddosManageComponent,
    NetChartComponent,
    // EventsComponent,
    DDoSLogsComponent,
    AlertsComponent,
    AclsComponent,
    AclsModalComponent,
    AclsModalEditComponent,
    AttackMonitoringComponent,
    ServiceSummaryComponentNewComponent,
    ExportModalComponent
  ],
  entryComponents: [
    AclsModalComponent,
    AclsModalEditComponent,
    ExportModalComponent
  ],
  providers: [
    // ...DDOSL4_SERVICES,
  ],
})
export class AntiddosModule {
}
