import { NgModule } from '@angular/core';
import { COMMON_MODULES } from '@common/lazyload';

import {
    ConfigurationComponent
} from './configuration/configuration.component';

import {
    ModalComponent,
    ModalEditComponent
} from './configuration/modal/modal.component';

@NgModule({
    imports: [
      ...COMMON_MODULES,
    ],
    declarations: [
        ConfigurationComponent,
        ModalComponent,
        ModalEditComponent
    ],
    entryComponents: [
        ModalComponent,
        ModalEditComponent
    ],
    exports: [
        ConfigurationComponent
    ]
  })
  export class AntiddosConfigurationModule { }