import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material';

@Component({
  selector: 'app-acls-modal',
  templateUrl: './acls-modal.component.html',
  styleUrls: ['./acls-modal.component.scss']
})
export class AclsModalComponent implements OnInit {
  editMode: boolean = false;
  title: string = "Thêm ACL";

  aclTypes: any[] = [
    {'name': 'Whitelist', value: 0},
    {'name': 'Blacklist', value: 1},
  ]

  new: any = {
    'type': 'wl',
    'active': true,
  };

  constructor(
    public dialogRef: MatDialogRef<AclsModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  ngOnInit() {
  }

  close(){
    this.dialogRef.close();
  }

  changeType($event){
    this.new.type = $event.value;
  }

  save(){
    this.dialogRef.close({result: {
      data: this.new
    }})
  }

}

@Component({
  selector: 'app-acls-edit-modal',
  templateUrl: './acls-modal.component.html',
  styleUrls: ['./acls-modal.component.scss']
})
export class AclsModalEditComponent extends AclsModalComponent implements OnInit {
  editMode: boolean = true;
  title: string = "Sửa ACL";

  constructor(
    public dialogRef: MatDialogRef<AclsModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { 
    super(dialogRef, data);

    this.new = {...data.model};
  }
}
