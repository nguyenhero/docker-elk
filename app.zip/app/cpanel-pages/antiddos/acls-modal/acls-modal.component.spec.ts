import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AclsModalComponent } from './acls-modal.component';

describe('AclsModalComponent', () => {
  let component: AclsModalComponent;
  let fixture: ComponentFixture<AclsModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AclsModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AclsModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
