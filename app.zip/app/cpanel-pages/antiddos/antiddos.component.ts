import {Component, OnDestroy, OnInit} from '@angular/core';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe";

@AutoUnsubscribe()
@Component({
  selector: 'app-antiddos',
  templateUrl: './antiddos.component.html',
  styleUrls: ['./antiddos.component.scss']
})
export class AntiddosComponent implements OnInit, OnDestroy {

  constructor() {
  }

  ngOnInit() {
  }

  ngOnDestroy() {

  }

}
