import { Component, OnInit, ViewChild, Input, OnDestroy, Injector, OnChanges, SimpleChange } from '@angular/core';
import { TableModels } from '@visc/visc-template';
import { TOOLTIP } from '@common/modules';
import { BaseComponent } from '@common/components';
import { Http, Response, HttpModule } from '@angular/http';

import { } from '@common/swagger-services-waf';

import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { CustomerLogService } from '@common/swagger-services';
import { DDOS_ID } from '@customer/config';
import { Field } from '@common/models';

import { swalNotiSuccess, swalShowConfirm, swalShowError } from '@common/utils';
import { ClientPermService } from '@common/services';
import { DasboardTabPanelComponent } from '@common/components';

import { Subscription } from "rxjs/Subscription";
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';

class Data {
    count: number = 0;
    pageNumber: number = 0;
    rows: any[] = [];
}
@AutoUnsubscribe()
@Component({
    selector: 'app-ddos-logs',
    templateUrl: './waf-logs.component.html',
    styleUrls: [ './waf-logs.component.scss' ]
})

export class DDoSLogsComponent extends DasboardTabPanelComponent implements OnInit {
    @Input() viewing: boolean;
    @Input() title: string = 'Events';

    serviceId = DDOS_ID;
}