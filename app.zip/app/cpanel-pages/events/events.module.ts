import { NgModule } from '@angular/core';
import { COMMON_MODULES } from '@common/lazyload';

import { EventsSharedModule } from './event.shared.module';
// import { EventsComponent } from './events/events.component';
import { EventsLayoutComponent } from './events-layout.component';
import {eventsRouter} from './events.router';

@NgModule({
    declarations: [
        // EventsComponent,
        EventsLayoutComponent
    ],
    imports: [
        ...COMMON_MODULES,
        EventsSharedModule,
        eventsRouter
    ],
    entryComponents: [
    ],
    providers: [],
})

export class EventsModule {
}