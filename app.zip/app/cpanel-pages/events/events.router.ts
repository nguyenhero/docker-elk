import { Routes, RouterModule } from '@angular/router';
import { EventsLayoutComponent } from './events-layout.component';

const ROUTER: Routes = [
    {
        path: '',
        component: EventsLayoutComponent
    },
];

export const eventsRouter = RouterModule.forChild(ROUTER);