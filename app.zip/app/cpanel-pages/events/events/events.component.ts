import {Component, OnInit, Input, Injector, ChangeDetectorRef} from '@angular/core';

import {SeriesUtils} from '@visc/visc-template';
import {Router, ActivatedRoute} from '@angular/router';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {CustomerLogService} from '@common/swagger-services';
import {Field} from '@common/models';
import {ClientPermService} from '@common/services';
import {DasboardTabPanelComponent} from '@common/components';
import {deepCopy} from '@common/utils/utils';
import {utc2local} from '@common/utils';
import {TranslateService} from "@ngx-translate/core";
import {compareStrLower} from '@common/models';

import {Subscription} from "rxjs/Subscription";
import {AutoUnsubscribe} from 'ngx-auto-unsubscribe';
import {Page} from "@common/page";
import {ITableData} from "@common/components";

class Data {
    count = 0;
    pageNumber = 0;
    rows: any[] = [];
}

const TYPE_VI = {
    'Đơn hàng': 1,
    'Gói dịch vụ': 2,
    'Tài khoản': 3,
    'Vận hành': 4
};

@AutoUnsubscribe()
@Component({
    selector: 'app-events',
    templateUrl: './events.component.html',
    styleUrls: ['./events.component.scss']
})
export class EventsComponent extends DasboardTabPanelComponent implements OnInit {
    @Input() viewing: boolean;
    @Input() allLog = true;
    @Input() serviceId: string;
    @Input() timeFrom: Date;
    @Input() logType: string;
    @Input() headerTitle: string;
    data: Data = new Data();
    searchControls: any[];
    sorts: any = [];
    model: any = {};
    searchModel: any = {};
    onSearch: any;
    lang: any;
    sortProp: any;
    sortDir: any;
    TYPES: any[] = [];
    columns = [
        {name: 'Time', value: 'time'},
        {name: 'Type', value: 'type'},
        {name: 'Content', value: 'content'}
    ];
    private sub20: Subscription;
    private sub21: Subscription;
    private sub22: Subscription;
    private sub23: Subscription;
    limit = 10;

    FIELDS = [
        new Field('time', 'Time', {}, {
            width: 160,
            minWidth: 160
        }),
        new Field('type', 'Type', {}, {
            type: 'eventtype',
            width: 150,
            minWidth: 150,
            sortable: false
        }),
        new Field('content', 'Content', {}, {
            popoverEnabled: true,
            width: 300,
            minWidth: 210,
            title: true
        }),
    ];
    tableData: ITableData = {
        page: new Page(),
        setPage: (e) => this.setPage(e),
        columns: this.FIELDS,
        rows: [],
        count: 0,
        externalPaging: true,
        externalSorting: true,
        sorts: [],
        onSort: (e) => this.onSort(e),
        select: {
            type: undefined,
            onSelect: function (event) {
            },
        },
        selected: []
    };

    constructor(
        public router: Router,
        public activatedRoute: ActivatedRoute,
        public dialog: MatDialog,
        public permService: ClientPermService,
        public injector: Injector,
        public customerLogService: CustomerLogService,
        public translateService: TranslateService
    ) {
        super(router, activatedRoute, dialog, permService, injector);
        this.cd = injector.get(ChangeDetectorRef);
        this.onSearch = this._reload.bind(this);
        this.sub23 = this.translateService.onLangChange.subscribe((event: any) => {
            this.lang = this.translateService.currentLang;
        });
        this.lang = this.translateService.currentLang;
    }

    ngOnInit() {
        super.ngOnInit();
        this._initSearchControl();
        this._translateOptions();
        this._getDefaultSearchModel();
        this._reload();
    }

    onSort($event) {
        this.sortDir = $event.newValue;
        this.sortProp = $event.column.prop;
        this.sorts = [
            {dir: this.sortDir, prop: this.sortProp}
        ];
        this.searchModel = deepCopy(this.model);
        this._refreshData(true);
    }

    setPage(pageInfo) {
        this.data.pageNumber = pageInfo.offset;
        this._refreshData(false);
    }

    _getDefaultSearchModel() {
        const fields = ['timeFrom'];
        for (let sf of fields) {
            if (this[sf]) {
                this.model[sf] = this[sf];
            }
        }
        this.model = {...this.model};
        this.cd.detectChanges();
    }

    _translateOptions() {
        // Translate label to sort options
        let types = this.TYPES.map(x => {
            return {
                transLabel: this.translateService.instant(x.label),
                label: x.label,
                value: x.value
            };
        });
        if (this.translateService.currentLang == "vi") {
            types = types.sort((a, b) => (TYPE_VI[a.transLabel] || 0) - (TYPE_VI[b.transLabel] || 0));
        } else {
            types = types.sort((a, b) => compareStrLower(a.transLabel, b.transLabel));
        }
        this._initSearchControl(types);
        this.cd.detectChanges();
    }

    _translateData() {
        if (!this.tableData) return;
        this.tableData.rows = (this.tableData.rows || []).map(x => x.clone());
        this.tableData = {...this.tableData};
        this.cd.detectChanges();
    }

    _initSearchControl(types?) {
        const maxEndDate = new Date();
        this.searchControls = [
            new Field('timeFrom', 'Start Time', {
                w_search_inp: '48.6%',
                type: "date",
                max: maxEndDate,
            }),
            new Field('timeTo', 'End Time', {
                w_search_inp: '48.6%',
                type: "date",
                max: maxEndDate,
            }),
            new Field('type', 'Type', {
                w_search_inp: '48.6%',
                type: 'select',
                options: types || this.TYPES
            }),
            new Field('search', 'Content', {
                w_search_inp: '48.6%',
            }),
        ];
    }

    _reload() {
        this.searchModel = deepCopy(this.model);
        this._refreshData(true);
    }

    _refreshData(resetPage?) {
        // neu la log cua tung website thi phai co gia tri domainId moi duoc tim kiem
        if (!this.allLog && !this.domainId) {
            return;
        }
        if (resetPage) {
            this.data.pageNumber = 0;
        }
        let u = undefined;
        let m = this.searchModel;
        let timeFrom;
        let timeTo;
        if (m.timeFrom == 'Invalid Date') {
            timeFrom = 'Invalid Date';
        } else {
            timeFrom = SeriesUtils.startDateToUTC(m.timeFrom);
        }
        if (m.timeTo == 'Invalid Date') {
            timeTo = 'Invalid Date';
        } else {
            timeTo = SeriesUtils.endDateToUTC(m.timeTo);
        }

        if (timeFrom == 'Invalid Date' || timeTo == 'Invalid Date') {
            this.tableData.rows = [];
            this.tableData.count = 0;
            this.tableData = {...this.tableData};
            this.cd.detectChanges();
            return;
        }
        let lang = this.translateService.currentLang;

        this.sub20 = this.customerLogService.getCustomerLog(
            this.sortDir || undefined,
            this.sortProp || undefined,
            this.limit,
            this.data.pageNumber,
            this.serviceId,
            m.search || undefined,
            this.domainId || undefined,
            timeFrom || undefined,
            timeTo || undefined,
            this.logType || undefined,
            m.type || undefined,
            lang || undefined
        ).subscribe(resp => {
            this.tableData.rows = resp.data.map(x => new Row(this, utc2local(x.time), x.type, x.content, x.content_vi));
            this.tableData.count = resp.count;
            this.tableData = {...this.tableData};
            this.cd.detectChanges();
        });
    }
}

export class Row {
    get content() {
        if (this.obj && this.obj.lang == 'vi') {
            return this.content_vi;
        }
        return this.content_en;
    }

    clone() {
        return new Row(
            this.obj,
            this.time,
            this.type,
            this.content_en,
            this.content_vi
        );
    }

    constructor(
        public obj: any,
        public time: string,
        public type: string,
        public content_en: string,
        public content_vi: string,
    ) {
    }
}

@AutoUnsubscribe()
@Component({
    selector: 'app-events-log',
    templateUrl: './events.component.html',
    styleUrls: ['./events.component.scss']
})
export class LogEventsComponent extends EventsComponent {
    @Input() timeTo: Date;
    @Input() type: string;
    @Input() search: string;
    @Input() logType = "log";
    TYPES = [
        {value: 'account', label: 'event-type-account'},
        {value: 'operation', label: 'event-type-operation'},
        {value: 'service', label: 'event-type-service'},
        {value: 'order', label: 'event-type-order'},
    ];

    _getDefaultSearchModel() {
        const fields = ['timeFrom', 'timeTo', 'type', 'search'];
        for (let sf of fields) {
            if (this[sf]) {
                this.model[sf] = this[sf];
            }
        }
        this.model = {...this.model};
        this.cd.detectChanges();
    }
}

@AutoUnsubscribe()
@Component({
    selector: 'app-events-warning',
    templateUrl: './events.component.html',
    styleUrls: ['./events.component.scss']
})
export class WarningEventsComponent extends EventsComponent {
    @Input() timeTo: Date;
    @Input() type: string;
    @Input() search: string;
    @Input() logType = "warning-only";
    TYPES = [
        {value: 'service', label: 'event-type-service'},
        {value: 'order', label: 'event-type-order'},
    ];

    _getDefaultSearchModel() {
        const fields = ['timeFrom', 'timeTo', 'type', 'search'];
        for (let sf of fields) {
            if (this[sf]) {
                this.model[sf] = this[sf];
            }
        }
        this.model = {...this.model};
        this.cd.detectChanges();
    }
}

@AutoUnsubscribe()
@Component({
    selector: 'app-events-service',
    templateUrl: './events.component.html',
    styleUrls: ['./events.component.scss']
})
export class ServiceEventsComponent extends EventsComponent {
    @Input() logType = "log";
    @Input() title: string;
    TYPES = [
        {value: 'operation', label: 'event-type-operation'},
    ];
}
