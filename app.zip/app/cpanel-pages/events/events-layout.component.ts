import {Component, OnInit, Injector} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';

import * as moment from 'moment';

import {Subscription} from "rxjs/Subscription";
import {AutoUnsubscribe} from 'ngx-auto-unsubscribe';
import {HeaderSidebarService} from "@customer/header-sidebar.service";

@AutoUnsubscribe()
@Component({
    selector: 'app-events-layout',
    templateUrl: './events-layout.component.html',
    styleUrls: ['./events-layout.component.scss']
})
export class EventsLayoutComponent implements OnInit {
    sub01: Subscription;
    fromThisMonth: boolean = false;

    eventTime;
    eventType;
    eventContent;

    get eventStartTime() {
        if (this.fromThisMonth) {
            return moment().startOf('month').toDate();
        }
        if (this.eventTime) {
            return moment(this.eventTime, 'YYYY-MM-DD').toDate();
        }
        return null;
    }

    get eventEndTime() {
        if (this.eventTime) {
            return moment(this.eventTime, 'YYYY-MM-DD').toDate();
        }
        return null;
    }

    constructor(
        public router: Router,
        public activatedRoute: ActivatedRoute,
        public injector: Injector,
        private _headerSidebar: HeaderSidebarService,
    ) {
        this._headerSidebar.title = '';
    }

    ngOnInit() {
        this.sub01 = this.activatedRoute.queryParams.subscribe(params => {
            // console.log(params);
            if (params.thisMonth) {
                this.fromThisMonth = Boolean(params.thisMonth);
            }

            let paramKeys = ['eventTime', 'eventType', 'eventContent'];
            for (let key of paramKeys) {
                if (params[key]) {
                    this[key] = params[key];
                }
            }
        });
    }

}
