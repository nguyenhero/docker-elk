import { NgModule } from '@angular/core';
import { COMMON_MODULES } from '@common/lazyload';
import { 
    EventsComponent,
    LogEventsComponent,
    WarningEventsComponent,
    ServiceEventsComponent
} from './events/events.component';

@NgModule({
    declarations: [
        EventsComponent,
        LogEventsComponent,
        WarningEventsComponent,
        ServiceEventsComponent
    ],
    imports: [
        ...COMMON_MODULES,
    ],
    entryComponents: [
    ],
    providers: [],
    exports: [
        EventsComponent,
        LogEventsComponent,
        WarningEventsComponent,
        ServiceEventsComponent
    ]
})

export class EventsSharedModule {
}