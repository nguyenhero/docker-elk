import {NgModule} from '@angular/core';
import {COMMON_MODULES} from '@common/lazyload';
import {sslRouter} from './ssl.router';
import { SslComponent } from './ssl.component';
const MODALS = [];
@NgModule({
    declarations: [
        SslComponent
    ],
    imports: [
        ...COMMON_MODULES,
        sslRouter,
    ],
    entryComponents: [
        ...MODALS,
    ],
    providers: [],
})
export class SslModule {
}
