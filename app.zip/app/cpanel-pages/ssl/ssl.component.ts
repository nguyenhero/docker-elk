import { TranslateService } from '@ngx-translate/core';
import { swalShowError, swalNotiSuccess } from '@common/utils';
import {
    ChangeDetectionStrategy,
    Component,
    OnDestroy,
    OnInit,
    ChangeDetectorRef,
} from '@angular/core';
import { AutoUnsubscribe } from 'ngx-auto-unsubscribe';
import { SslService } from '../../common/swagger-services/api/api';
import { GlobalService } from '../../common/services/global.service';
@AutoUnsubscribe()
@Component({
    selector: 'app-ssl',
    templateUrl: './ssl.component.html',
    styleUrls: ['./ssl.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SslComponent implements OnInit, OnDestroy {
    preSslMode = "1";
    sslMode = "1";
    isEnabeTLS13 = false;
    currentVersion = "1.0";
    listVersion = [
        {
            'name': "TLS 1.0 (default)",
            'label': "TLS 1.0 (default)",
            '_id': "1.0",
            'value': "1.0",
        },
        {
            'name': "TLS 1.1",
            'label': "TLS 1.1",
            '_id': "1.1",
            'value': "1.1",
        },
        {
            'name': "TLS 1.2",
            'label': "TLS 1.2",
            '_id': "1.2",
            'value': "1.2",
        },
        {
            'name': "TLS 1.3",
            'label': "TLS 1.3",
            '_id': "1.3",
            'value': "1.3",
        },
    ];


    certFileReader: any;
    certFile: any;
    certFileContent: any;
    certFileName = "";
    certFileMaxSize = 300; // KB
    certFileExtensions = ['crt', 'pem'];
    certFileExtensionsList = this.certFileExtensions.join(', ');

    keyFileReader: any;
    keyFile: any;
    keyFileContent: any;
    keyFileName = "";
    keyFileMaxSize = 300; // KB
    keyFileExtensions = ['crt', 'pem'];
    keyFileExtensionsList = this.keyFileExtensions.join(', ');

    currentId;
    currentDomain;
    isFirstLoad = true;
    constructor(
        private translate: TranslateService,
        private cd: ChangeDetectorRef,
        public globalService: GlobalService,
        public sslService: SslService
    ) {
        this.globalService.notifyObservable$.subscribe(resp => {
            if (resp && resp.selected_domain) {
                this.loadCurrentConfig(resp.selected_domain.identity);
            }
        });
    }
    ngOnInit() {
        let CLOUDRITY_CONST = JSON.parse(this.globalService.getItem("CLOUDRITY_CONST"));
        if (CLOUDRITY_CONST && CLOUDRITY_CONST.selected_domain) {
            this.loadCurrentConfig(CLOUDRITY_CONST.selected_domain.identity);
        }
    }

    loadCurrentConfig(domain) {
        this.sslService.getSslItem(domain).subscribe(resp => {
            if (resp.data) {
                this.certFileName = resp.data.cert_file;
                this.certFileContent = resp.data.cert;
                this.keyFileName = resp.data.key_file;
                this.keyFileContent = resp.data.key;
                this.currentId = resp.data._id;
                this.isEnabeTLS13 = resp.data.enable_tls_13;
                this.currentVersion = resp.data.tls_version_min;
                this.sslMode = resp.data.type;
            } else {
                // set default
                this.certFileName = "";
                this.certFileContent = "";
                this.keyFileName = "";
                this.keyFileContent = "";
                this.currentId = null;
                this.isEnabeTLS13 = false;
                this.currentVersion = "1.0";
                this.sslMode = '1';
            }
            this.currentDomain = domain;
            this.isFirstLoad = false;
            this.cd.detectChanges();
        },
            err => {
                console.log("get error", err);
                return;
            });
    }
    ngOnDestroy() {
    }
    certFileChanged(event?) {
        this.certFile = event.target.files[0];
        if (this.certFile == undefined) {
            this.certFileName = "";
            return;
        }
        if (this.certFile.size > 1024 * 1024 * this.certFileMaxSize / 1000) {
            this.certFile = undefined;
            this.certFileName = "";
            swalShowError(this.translate.instant('Error'), this.translate.instant('Certificate file exceeds {{size}}KB', { size: this.certFileMaxSize }));
            return;
        }

        // Check valid file types
        for (let ext of this.certFileExtensions) {
            if (this.certFile.name.endsWith('.' + ext)) {
                this.certFileReader = new FileReader();
                this.certFileName = this.certFile.name;
                this.certFileReader.readAsText(this.certFile);
                this.updateConfig();
                return;
            }
        }

        swalShowError(this.translate.instant('Error'), this.translate.instant('Invalid file type'));
        this.certFile = undefined;
        this.certFileName = "";
    }
    uploadCertFile() {
        document.getElementById('input-cert-file').click();
    }
    keyFileChanged(event?) {
        this.keyFile = event.target.files[0];
        if (this.keyFile == undefined) {
            this.keyFileName = "";
            return;
        }
        if (this.keyFile.size > 1024 * 1024 * this.keyFileMaxSize / 1000) {
            this.keyFile = undefined;
            this.keyFileName = "";
            swalShowError(this.translate.instant('Error'), this.translate.instant('Certificate file exceeds {{size}}KB', { size: this.keyFileMaxSize }));
            return;
        }

        // Check valid file types
        for (let ext of this.keyFileExtensions) {
            if (this.keyFile.name.endsWith('.' + ext)) {
                this.keyFileReader = new FileReader();
                this.keyFileName = this.keyFile.name;
                this.keyFileReader.readAsText(this.keyFile);
                this.updateConfig();
                return;
            }
        }

        swalShowError(this.translate.instant('Error'), this.translate.instant('Invalid file type'));
        this.keyFile = undefined;
        this.keyFileName = "";
    }
    uploadKeyFile() {
        document.getElementById('input-key-file').click();

    }
    changeVersion(e) {
        this.currentVersion = e;
        this.updateConfig();
    }
    changeTLS13() {
        this.updateConfig();
    }
    updateConfig() {
        if (this.isFirstLoad) {
            return;
        }
        if (!this.currentDomain) {
            return;
        }
        if (!this.currentId) {
            const payload = {
                type: this.sslMode,
                cert_content: this.certFileReader ? this.certFileReader.result : this.certFileContent,
                cert_name: this.certFileName,
                key_content: this.keyFileReader ? this.keyFileReader.result : this.keyFileContent,
                key_name: this.keyFileName,
                domain_name: this.currentDomain,
                enable_tls_13: this.isEnabeTLS13,
                tls_version_min: this.currentVersion,
            };
            this.sslService.postSslList(payload
            ).subscribe(resp => {
                if (resp.data) {
                    this.currentId = resp.data;
                    swalNotiSuccess('Thông báo', 'Cập nhật thành công');
                }
            },
                err => {
                    console.log("get error", err);
                    return;
                });
        } else {
            const payload = {
                type: this.sslMode,
                cert_content: this.certFileReader ? this.certFileReader.result : this.certFileContent,
                cert_name: this.certFileName,
                key_content: this.keyFileReader ? this.keyFileReader.result : this.keyFileContent,
                key_name: this.keyFileName,
                domain_name: this.currentDomain,
                enable_tls_13: this.isEnabeTLS13,
                tls_version_min: this.currentVersion,
            };
            this.sslService.putSslItem(this.currentId, payload
            ).subscribe(resp => {
                if (resp.data) {
                    this.currentId = resp.data;
                    swalNotiSuccess('Thông báo', 'Cập nhật thành công');
                }
            },
                err => {
                    console.log("get error", err);
                    return;
                });
        }
    }
}
