import {Routes, RouterModule} from '@angular/router';
import { SslComponent } from './ssl.component';

const ROUTER: Routes = [
  {
    path: '',
    component: SslComponent
  }
];

export const sslRouter = RouterModule.forChild(ROUTER);
