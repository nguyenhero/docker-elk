import { NgModule } from '@angular/core';
import {FlexLayoutModule} from '@angular/flex-layout';
import {FormsModule} from '@angular/forms';

import {
  MatSidenavModule,
  MatCardModule,
  MatMenuModule,
  MatCheckboxModule,
  MatIconModule,
  MatButtonModule,
  MatToolbarModule,
  MatTabsModule,
  MatListModule,
  MatSlideToggleModule,
  MatSelectModule,
  MatProgressBarModule,
  MatInputModule,
  MatDialogModule,
  MatChipsModule,
  MatProgressSpinnerModule,
  MatAutocompleteModule,
  MatGridListModule,
  MatRadioModule,
  MatStepperModule,
  MatTooltipModule, MatExpansionModule, MatIconRegistry,
} from '@angular/material';
import {CommonModule} from '@angular/common';
import {PerfectScrollbarModule} from "ngx-perfect-scrollbar";
import {TranslateModule} from '@ngx-translate/core';
import {BrowserModule, DomSanitizer} from '@angular/platform-browser';
// import {FooterComponent} from '@common/footer/footer.component';

@NgModule({
  declarations: [
    // FooterComponent,
  ],
  imports: [
    CommonModule,

    // MatSidenavModule,
    MatCardModule,
    MatMenuModule,
    MatCheckboxModule,
    MatRadioModule,
    MatIconModule,
    MatButtonModule,
    MatToolbarModule,
    MatTabsModule,
    MatListModule,
    MatSlideToggleModule,
    MatSelectModule,
    // MatProgressBarModule,
    MatAutocompleteModule,
    MatGridListModule,
    MatInputModule,
    // MatDialogModule,
    MatChipsModule,
    // MatProgressSpinnerModule,
    MatTooltipModule,
    MatStepperModule,
    MatExpansionModule,

    FormsModule,
    FlexLayoutModule,
    PerfectScrollbarModule,
    TranslateModule,
  ],
  exports: [
    CommonModule,

    // MatSidenavModule,
    MatCardModule,
    MatMenuModule,
    MatCheckboxModule,
    MatRadioModule,
    MatIconModule,
    MatButtonModule,
    // MatToolbarModule,
    MatTabsModule,
    MatListModule,
    MatSlideToggleModule,
    MatSelectModule,
    // MatProgressBarModule,
    MatAutocompleteModule,
    MatGridListModule,
    MatInputModule,
    // MatDialogModule,
    MatChipsModule,
    // MatProgressSpinnerModule,
    MatTooltipModule,
    MatStepperModule,
    MatExpansionModule,

    FormsModule,
    FlexLayoutModule,
    PerfectScrollbarModule,
    TranslateModule,
   ],
  providers: [
  ]
})
export class SharedAnonymousModule {

  constructor(iconRegistry: MatIconRegistry, sanitizer: DomSanitizer,){
    iconRegistry.addSvgIcon(
      'cp-circle', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/circle.svg'));
        iconRegistry.addSvgIcon(
      'cp-caret-left', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/caret-left.svg'));
    iconRegistry.addSvgIcon(
      'cp-caret-right', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/caret-right.svg'));

    iconRegistry.addSvgIcon(
      'cp-facebook', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/facebook.svg'));
    iconRegistry.addSvgIcon(
      'cp-twitter', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/twitter.svg'));
    iconRegistry.addSvgIcon(
      'cp-googleplay', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/googleplay.svg'));
    iconRegistry.addSvgIcon(
      'cp-youtube', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/youtube.svg'));
    iconRegistry.addSvgIcon(
      'cp-linkedin', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/linkedin.svg'));
    iconRegistry.addSvgIcon(
      'cp-circle', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/circle.svg'));
    iconRegistry.addSvgIcon(
      'cp-shield', sanitizer.bypassSecurityTrustResourceUrl('/customer/assets/images/shield.svg'));
  }

}
