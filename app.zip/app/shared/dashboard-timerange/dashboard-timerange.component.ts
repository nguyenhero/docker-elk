import { Component, OnInit, Input, Output, EventEmitter, SimpleChange, ViewChild } from '@angular/core';
import { TimeRangeComponent } from '@visc/visc-template';

import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';
import * as moment from 'moment'
import { AppDateAdapter, APP_DATE_FORMATS } from '../../../../../../libs/fosec-template-customer/src/common/my-date-adapter';
const TRANS_TO_LOCALE = {
  'vi': 'vi',
  'en': 'en'
}

@Component({
  selector: 'app-dashboard-timerange',
  templateUrl: './dashboard-timerange.component.html',
  styleUrls: ['./dashboard-timerange.component.scss'],
  providers: [
    {provide: MAT_DATE_LOCALE, useValue: 'en-GB'},
    {provide: DateAdapter, useClass: AppDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS},
  ]
})
export class DashboardTimerangeComponent extends TimeRangeComponent implements OnInit {
 
  @Input() mode: string = 'horizontal';

  get isVertical(){
    return this.mode === 'vertical';
  }
  @Input() disabled: boolean = false;
  @Input() searchButton: boolean = false;
  @Output() onChange: EventEmitter<any> = new EventEmitter();

  @Input() startDate: Date;
  @Input() endDate: Date;

  @Input() maxRange: number = 60;
  @Input() windowRange: number = 60;
  @Input() openPosition: string = 'left'; // left, center, right
  @Input() isAutoSearch: boolean = true;
  @Input() isHideIcon: boolean = false;
  @Input() maxDate : any= moment(new Date())
  @Input() minDate : any;
  dateRange: any;
  locale: any = {
    displayFormat: 'DD/MM/YYYY',
    separator: '      -      ',
    applyLabel: 'OK',
  };

  constructor(
    protected adapter: DateAdapter<any>,
    private trans: TranslateService,
  ){
    super(adapter, trans);
    this.adapter.setLocale(TRANS_TO_LOCALE[this.trans.currentLang]);
    this.trans.onLangChange.subscribe((event: LangChangeEvent) => {
      this.adapter.setLocale(TRANS_TO_LOCALE[this.trans.currentLang]);
    });
  }

  ngOnInit() {
    if(this.minDate) {
      this.minDate = moment(this.minDate)
    }
    if(this.maxDate) {
      this.maxDate = moment(this.maxDate);
      if(this.endDate > this.maxDate) {
        this.endDate = this.maxDate;
      }
    }
    this.dateRange = { startDate: this.startDate, endDate: this.endDate };
  }

  ngOnChanges(changes: SimpleChange) {
    if((changes['startDate'] && typeof changes['startDate'].previousValue !== 'undefined') || (changes['endDate'] && typeof changes['endDate'].previousValue !== 'undefined')) {
      this.startDate = changes['startDate'].currentValue;
      this.endDate = changes['endDate'].currentValue;
      this.dateRange = { startDate: this.startDate, endDate: this.endDate };
    }
  }
  chosenDate(e){
    setTimeout(() => {
      try {
        document.getElementById("dummy").click();
      } catch (error) {
        
      }
    }, 500);
  }
  changeDateRange = (dataRangeData = { startDate: this.startDate, endDate: this.endDate }) => {
    
    const { startDate, endDate } = dataRangeData;
    if (this.isAutoSearch && startDate && endDate) {
      this.startDate = startDate;
      this.endDate = dataRangeData.endDate;
      this.changeDateAll();
      return;
    }
    if (startDate) {
      this.startDate = startDate;
      this.changeStart();
    }
    if (endDate) {
      this.endDate = dataRangeData.endDate;
      this.changeEnd();
    }
  }

  openCalendar() {

  }
}
