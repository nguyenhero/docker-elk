import {Injectable} from '@angular/core';
import {_} from '@common/utils';

import {ClientPermService} from "@common/services";
import {PublicService} from "@common/swagger-services";

export interface BadgeItem {
  type: string;
  value: string;
}

export interface ChildrenItems {
  state: string;
  name: string;
  type?: string;
}

export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
  badge?: BadgeItem[];
  children?: ChildrenItems[];
  permission?: string[];
}

const MENUITEMS = [
  {
    state: 'home',
    name: _('Trang chủ'),
    type: 'link',
    icon: 'home',
    location: ['']
  }, {
    state: 'services',
    name: _('Dịch vụ'),
    type: 'link',
    icon: 'security',
    location: ['']
  }, {
    state: 'services-intro',
    name: 'Dịch vụ',
    type: 'link',
    icon: 'security',
    location: ['']
  },
  {
    state: 'news',
    name: _('Tin tức'),
    type: 'link',
    icon: 'bookmark',
    location: ['top']
  },
  {
    state: 'login',
    name: _('Đăng nhập'),
    type: 'link',
    icon: 'account_box',
    location: ['']
  },
  {
    state: 'dashboard',
    name: 'Dashboard',
    type: 'link',
    icon: 'cp-meter',
    location: ['left', 'top']
  },
  {
    type: 'divider', location: ['left']
  },
  {
    state: 'manage-services',
    name: _('Quản lý dịch vụ'),
    type: 'sub',
    icon: 'cp-service',
    location: ['left'],
    required_service: '__any',
    children: [
      {
        state: 'waf',
        name: 'Web Protection',
        type: 'link',
        icon: 'security',
        location: ['left'],
        required_service: 'wp'
      },
      {
        state: 'web-analytics',
        name: _('Website Analytics'),
        type: 'sub',
        icon: 'trending_up',
        location: ['left'],
        required_service: 'wa',
        children: [
          {
            state: 'realtime',
            name: _('Real-time'),
            type: 'link',
            icon: 'security',
            location: ['left'],
            required_service: 'wa'
          },
          {
            state: 'user-info',
            name: _('Wa_User info'),
            type: 'link',
            icon: 'security',
            location: ['left'],
            required_service: 'wa'
          },
          {
            state: 'all-page',
            name: _('All Page'),
            type: 'link',
            icon: 'security',
            location: ['left'],
            required_service: 'wa'
          },
          {
            state: 'entry-page',
            name: _('Entry Page'),
            type: 'link',
            icon: 'security',
            location: ['left'],
            required_service: 'wa'
          },
          {
            state: 'exit-page',
            name: _('Exit Page'),
            type: 'link',
            icon: 'security',
            location: ['left'],
            required_service: 'wa'
          },
        ]
      },
      {
        state: 'antiddos',
        name: _('DDoS Protection'),
        type: 'link',
        icon: 'call_split',
        location: ['left'],
        required_service: 'ddosl4'
      },
      {
        state: 'dns',
        name: 'DNS',
        type: 'link',
        icon: 'dashboard',
        location: ['left'],
        required_service: '__any'
      },
    ]
  },
  {
    type: 'divider', location: ['left'], dependsOn: 'manage-services',
  },
  {
    state: 'configure-services',
    name: 'Cấu hình dịch vụ',
    type: 'link',
    icon: 'cp-gear',
    location: ['left'],
    required_service: '__any'
  },
  {
    type: 'divider', location: ['left'], dependsOn: 'configure-services',
  },
  {
    state: 'helpdesk',
    name: 'Hỗ trợ',
    type: 'link',
    icon: 'cp-ticket',
    badge: [
      {type: 'red', value: '15'}
    ],
    location: ['left']
  }
];


const USER_PROFILE_MENUS = [
  {
    state: 'profile',
    name: _('Tài khoản của tôi'),
    type: 'link',
    icon: 'cp-person',
    location: ['left']
  },
  {
    type: 'divider', location: ['left']
  },
  // {
  //   state: 'notifications',
  //   name: _('Thông báo'),
  //   type: 'link',
  //   icon: 'cp-message',
  //   location: ['left']
  // },
  // {
  //   type: 'divider', location: ['left']
  // },
  {
    state: 'orders',
    name: _('Quản lý đơn hàng'),
    type: 'link',
    icon: 'cp-order',
    location: ['left']
  },
  {
    type: 'divider', location: ['left']
  },
  // {
  //   state: 'settings',
  //   name: _('Cài đặt'),
  //   type: 'link',
  //   icon: 'cp-settings',
  //   location: ['left']
  // },
  // {
  //   type: 'divider', location: ['left']
  // },
  {
    state: 'promotion',
    name: _('Mã giảm giá'),
    type: 'link',
    icon: 'cp-promotion',
    location: ['left']
  },
  {
    type: 'divider', location: ['left']
  },
  // {
  //   state: 'policy',
  //   name: _('Chính sách'),
  //   type: 'link',
  //   icon: 'cp-policy',
  //   location: ['left']
  // },
  // {
  //   type: 'divider', location: ['left']
  // },
  // {
  //   state: 'help',
  //   name: _('Trợ giúp'),
  //   type: 'link',
  //   icon: 'cp-help',
  //   location: ['left']
  // }
];

@Injectable()
export class MenuItems {

  items;
  useritems;

  constructor(
      private permService: ClientPermService,
      private publicService: PublicService,
  ) {
    this.items = MENUITEMS;
    this.useritems = USER_PROFILE_MENUS;
  }

  getAll(): Menu[] {
    return this.items;
  }

  getTopMenu(): Menu[] {
    if ('loggedIn' in window && window['loggedIn']) {
      return this.items.filter((element, index, array) => element.location.indexOf('top') > -1 && element.state != 'login');
    } else {
      return this.items.filter((element, index, array) => element.location.indexOf('top') > -1 && element.state != 'dashboard');
    }
  }

  getLeftMenu(): Menu[] {
    let checkService = function (el) {
      return !el.required_service
        || (el.required_service === '__any' && this.permService.current_user.services && this.permService.current_user.services.length > 0)
        || this.permService.current_user.services.indexOf(el.required_service) >= 0;
    }.bind(this);

    let items = this.items.filter((element, index, array) => element.location.indexOf('left') > -1 && checkService(element));
    // filter children
    items = items.map(it => {
      if (it.children) {
        it.children = it.children.filter((element, index, array) => checkService(element));
      }
      return it;
    });
    // Remove redundant dividers
    items = items.filter((element) =>
        element.type !== 'divider'
        || !element.hasOwnProperty('dependsOn')
        || items.findIndex(item => element.dependsOn === item.state) >= 0);

    return items;
  }

  getUserProfileMenu(): Menu[] {
    return this.useritems;
  }

  add(menu: Menu) {
    this.items.push(menu);
  }

  updateBadge(state, value) {
    this.items.map(item => {
      if (item.state === state) {
        if (value === 0) {
          delete item.badge;
        } else {
          item.badge = [{type: 'red', value: value}];
        }
      }
      return item;
    });
  }
}
