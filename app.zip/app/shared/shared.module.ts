import {NgModule} from '@angular/core';
import {FlexLayoutModule} from '@angular/flex-layout';
import {StarRatingModule} from 'angular-star-rating';
import {MenuItems} from './menu-items/menu-items';
import {AccordionAnchorDirective, AccordionLinkDirective, AccordionDirective} from './accordion';
import {ToggleFullscreenDirective} from './fullscreen/toggle-fullscreen.directive';
import {FormsModule} from '@angular/forms';

import {DashboardTimerangeComponent} from './dashboard-timerange/dashboard-timerange.component';
import {PopoverModule} from '@fosec/fosec-template-customer';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';

import {
  MatSidenavModule,
  MatCardModule,
  MatMenuModule,
  MatCheckboxModule,
  MatIconModule,
  MatButtonModule,
  MatToolbarModule,
  MatTabsModule,
  MatListModule,
  MatSlideToggleModule,
  MatSelectModule,
  MatProgressBarModule,
  MatInputModule,
  MatDialogModule,
  MatChipsModule,
  MatProgressSpinnerModule,
  MatAutocompleteModule,
  MatGridListModule,
  MatRadioModule,
  MatStepperModule,
  MatTooltipModule, MatExpansionModule,
  MatDatepickerModule,
} from '@angular/material';
import {FosecTemplateCustomerModule} from '@fosec/fosec-template-customer';
import {CommonModule} from '@angular/common';
import {PerfectScrollbarModule} from "ngx-perfect-scrollbar";
import {TranslateModule} from '@ngx-translate/core';

import {ClickOutsideModule} from 'ng-click-outside';

@NgModule({
  declarations: [
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
    ToggleFullscreenDirective,
    DashboardTimerangeComponent,
  ],
  imports: [
    CommonModule,
    StarRatingModule,
    ClickOutsideModule,
    // material module: need both in import and export
    MatSidenavModule,
    MatCardModule,
    MatMenuModule,
    MatCheckboxModule,
    MatRadioModule,
    MatIconModule,
    MatButtonModule,
    MatToolbarModule,
    MatTabsModule,
    MatListModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatProgressBarModule,
    MatAutocompleteModule,
    MatGridListModule,
    MatInputModule,
    MatDialogModule,
    MatChipsModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatStepperModule,
    MatExpansionModule,

    FosecTemplateCustomerModule,
    FormsModule,
    FlexLayoutModule,
    PerfectScrollbarModule,
    TranslateModule,
    NgxDaterangepickerMd.forRoot(),
    MatDatepickerModule,
    PopoverModule,
    //user define
  ],
  entryComponents: [],
  exports: [
    FormsModule,
    ClickOutsideModule,
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
    ToggleFullscreenDirective,

    DashboardTimerangeComponent,

    //material
    MatSidenavModule,
    MatCardModule,
    MatMenuModule,
    MatCheckboxModule,
    MatRadioModule,
    MatIconModule,
    MatButtonModule,
    MatToolbarModule,
    MatTabsModule,
    MatListModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatProgressBarModule,
    MatAutocompleteModule,
    MatGridListModule,
    MatInputModule,
    MatDialogModule,
    MatChipsModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatStepperModule,
    MatExpansionModule,

    //user defined
  ],
  providers: [
    MenuItems,
    // {provide: DateAdapter, useClass: MyDateAdapter},
    // {provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS},
  ]
})
export class SharedModule {
}
