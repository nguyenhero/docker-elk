import {
  Directive, HostBinding, Inject, Input, OnInit, OnDestroy
} from '@angular/core';

import { AccordionDirective } from './accordion.directive';
import {Router} from '@angular/router';

@Directive({
  selector: '[appAccordionLink]'
})
export class AccordionLinkDirective implements OnInit, OnDestroy {

  @Input() public group: any;
  @Input() public type: string;

  @HostBinding('class.open')
  @Input()
  get open(): boolean {
    if (this.type == 'sub') {
      return true;
    } else {
      return this._open;
    }
  }

  set open(value: boolean) {
    if (this.type == 'sub') {
      this._open = true;
    } else {
      this._open = value;
    }

    // if (value) {
    //   // this.nav.closeOtherLinks(this);
    // }
  }

  protected _open: boolean;
  protected nav: AccordionDirective;

  constructor(@Inject(AccordionDirective) nav: AccordionDirective, private router: Router) {
    this.nav = nav;
    this.router = router;

    if (this.type == 'sub') {
      this._open = true;
    }
  }

  ngOnInit(): any {
    this.nav.addLink(this);
  }

  ngOnDestroy(): any {
    this.nav.removeGroup(this);
  }

  toggle(): any {
    // // console.log(this.nav.router.routerState.snapshot.url);

    // always open for submenu
    if (this.type == 'sub') {
      this.open = true;
    }

    // // check if not 2nd clicked on same element
    if (!this.open) {
      this.open = !this.open;
    } else if (this.router.url != this.nav.router.routerState.snapshot.url) {
      this.open = !this.open;
    }
  }
}
